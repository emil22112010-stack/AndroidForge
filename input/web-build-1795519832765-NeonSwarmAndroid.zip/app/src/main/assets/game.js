(() => {
'use strict';

const TAU = Math.PI * 2;
const $ = id => document.getElementById(id);
const cv = $('c');
const ctx = cv.getContext('2d');
let W = 360, H = 640, dpr = 1, Z = 1, topPad = 14;
let G = null;
let bgT = 0;

// ================= Данные =================
const WEAPONS = {
  pulse: { name: 'Импульс', icon: '⚡', desc: 'Стреляет по ближайшим врагам. С 4 уровня пробивает насквозь.' },
  orbit: { name: 'Клинки', icon: '🌀', desc: 'Вращаются вокруг вас и рубят всех, кто подошёл.' },
  nova:  { name: 'Нова', icon: '💥', desc: 'Взрыв вокруг вас отбрасывает толпу.' },
  chain: { name: 'Молния', icon: '🔗', desc: 'Разряд перескакивает с врага на врага.' },
  laser: { name: 'Луч', icon: '📏', desc: 'Прошивает всех на линии. С 3 уровня бьёт несколькими лучами.' },
};
const PASSIVES = {
  dmg:   { name: 'Мощь', icon: '🔥', desc: '+15% к урону.' },
  rate:  { name: 'Темп', icon: '⏱️', desc: '+12% к скорострельности.' },
  spd:   { name: 'Рывок', icon: '👟', desc: '+8% к скорости движения.' },
  hp:    { name: 'Корпус', icon: '❤️', desc: '+20 к максимуму HP и лечение.' },
  mag:   { name: 'Магнит', icon: '🧲', desc: '+30% к радиусу подбора.' },
  armor: { name: 'Щит', icon: '🛡️', desc: '−1 к получаемому урону.' },
  regen: { name: 'Ремонт', icon: '💚', desc: '+0,4 HP в секунду.' },
  xp:    { name: 'Опыт', icon: '⭐', desc: '+12% к получаемому опыту.' },
};
const HEROES = [
  { name: 'Искра',  icon: '⚡', start: 'pulse', cost: 0,   desc: 'Универсал. Стартует с Импульсом.', spd: 1,   dmg: 1,    hp: 0 },
  { name: 'Орбита', icon: '🌀', start: 'orbit', cost: 200, desc: 'Быстрее на 10%. Стартует с Клинками.', spd: 1.1, dmg: 1,    hp: 0 },
  { name: 'Гром',   icon: '🔗', start: 'chain', cost: 450, desc: '+25 HP. Стартует с Молнией.', spd: 1,   dmg: 1,    hp: 25 },
  { name: 'Лучик',  icon: '📏', start: 'laser', cost: 800, desc: '+15% урона. Стартует с Лучом.', spd: 1,   dmg: 1.15, hp: 0 },
];
const META = [
  { k: 'hp',  name: 'Прочность',   icon: '❤️', desc: '+15 HP за уровень',        max: 5, cost: [30, 60, 110, 180, 280] },
  { k: 'dmg', name: 'Сила',        icon: '🔥', desc: '+8% урона за уровень',     max: 5, cost: [40, 80, 140, 220, 340] },
  { k: 'spd', name: 'Скорость',    icon: '👟', desc: '+4% скорости за уровень',  max: 5, cost: [30, 60, 100, 160, 240] },
  { k: 'xp',  name: 'Обучение',    icon: '⭐', desc: '+8% опыта за уровень',     max: 5, cost: [40, 80, 140, 220, 340] },
  { k: 'mag', name: 'Магнит',      icon: '🧲', desc: '+15% радиуса подбора',     max: 5, cost: [25, 50, 90, 140, 200] },
  { k: 'rev', name: 'Второй шанс', icon: '✨', desc: 'Воскрешение с 50% HP',     max: 2, cost: [300, 700] },
];
const ET = {
  grunt:    { hp: 12, sp: 52,  r: 10, dmg: 8,  xp: 1, col: '#ff4d6d', sides: 0 },
  runner:   { hp: 7,  sp: 100, r: 8,  dmg: 6,  xp: 1, col: '#ffb703', sides: 3 },
  tank:     { hp: 70, sp: 36,  r: 17, dmg: 15, xp: 5, col: '#9b5de5', sides: 6 },
  shooter:  { hp: 22, sp: 46,  r: 10, dmg: 8,  xp: 2, col: '#00f5d4', sides: 4 },
  splitter: { hp: 34, sp: 48,  r: 13, dmg: 9,  xp: 2, col: '#f15bb5', sides: 8 },
  mini:     { hp: 7,  sp: 80,  r: 6,  dmg: 5,  xp: 1, col: '#f15bb5', sides: 0 },
};
const BOSS_TIMES = [180, 360, 540, 720];
const BOSS_NAMES = ['Страж', 'Жнец', 'Колосс', 'Сердце роя'];

// ================= Сохранение =================
const SKEY = 'neonswarm_v1';
const defSave = () => ({ cores: 0, meta: { hp: 0, dmg: 0, spd: 0, xp: 0, mag: 0, rev: 0 }, heroes: [true, false, false, false], hero: 0, bestT: 0, bestK: 0, wins: 0, sound: true });
let S = (() => {
  try {
    const d = JSON.parse(localStorage.getItem(SKEY));
    if (d && d.meta) {
      const base = defSave();
      return Object.assign(base, d, { meta: Object.assign(base.meta, d.meta) });
    }
  } catch (e) {}
  return defSave();
})();
function persist() { try { localStorage.setItem(SKEY, JSON.stringify(S)); } catch (e) {} }

// ================= Звук =================
let actx = null;
function initAudio() {
  try {
    if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
    else if (actx.state === 'suspended') actx.resume();
  } catch (e) {}
}
function tone(f, d, type, v, slide, delay) {
  if (!S.sound || !actx) return;
  try {
    const t0 = actx.currentTime + (delay || 0);
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(f, t0);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, f * slide), t0 + d);
    g.gain.setValueAtTime(v || 0.08, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    o.connect(g); g.connect(actx.destination);
    o.start(t0); o.stop(t0 + d + 0.02);
  } catch (e) {}
}
const sfxLast = {};
function sfx(name, arg) {
  const now = performance.now();
  const gap = { shoot: 90, hit: 60, gem: 40, zap: 120 }[name] || 0;
  if (gap && sfxLast[name] && now - sfxLast[name] < gap) return;
  sfxLast[name] = now;
  switch (name) {
    case 'shoot': tone(780, 0.05, 'square', 0.018, 0.5); break;
    case 'hit':   tone(180, 0.04, 'square', 0.02, 0.6); break;
    case 'gem':   tone(620 + Math.min(arg || 0, 12) * 45, 0.07, 'sine', 0.05); break;
    case 'zap':   tone(300, 0.1, 'sawtooth', 0.03, 2.2); break;
    case 'nova':  tone(140, 0.28, 'sine', 0.12, 0.35); break;
    case 'hurt':  tone(120, 0.18, 'sawtooth', 0.09, 0.5); break;
    case 'level': [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.16, 'triangle', 0.07, 0, i * 0.07)); break;
    case 'boss':  tone(70, 0.7, 'sawtooth', 0.12, 0.6); tone(105, 0.7, 'square', 0.05, 0.6, 0.15); break;
    case 'bosskill': [392, 523, 659, 784, 1047].forEach((f, i) => tone(f, 0.22, 'triangle', 0.08, 0, i * 0.08)); break;
    case 'die':   [330, 262, 196, 130].forEach((f, i) => tone(f, 0.3, 'sawtooth', 0.08, 0.8, i * 0.14)); break;
    case 'win':   [523, 659, 784, 1047, 1319, 1568].forEach((f, i) => tone(f, 0.3, 'triangle', 0.08, 0, i * 0.1)); break;
    case 'click': tone(500, 0.04, 'sine', 0.05); break;
  }
}
function buzz(ms) { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) {} }

// простая процедурная музыка
let musicTimer = null, mStep = 0;
const ROOTS = [55, 55, 43.65, 49];
const PENTA = [0, 3, 5, 7, 10, 12, 15];
function musicTick() {
  if (!S.sound || !actx || !G || G.state !== 'run') return;
  const bar = Math.floor(mStep / 16) % 4, root = ROOTS[bar], s = mStep % 16;
  if (s % 4 === 0) tone(root, 0.3, 'sawtooth', 0.045);
  if (s === 0 || s === 8) tone(90, 0.12, 'sine', 0.1, 0.35);
  const chance = 0.35 + Math.min(0.5, G.t / 900);
  if (s % 2 === 1 && Math.random() < chance) {
    const n = PENTA[Math.floor(Math.random() * PENTA.length)];
    tone(root * 4 * Math.pow(2, n / 12), 0.14, 'triangle', 0.02);
  }
  mStep++;
}
function musicStart() { if (!musicTimer) musicTimer = setInterval(musicTick, 140); }
function musicStop() { if (musicTimer) { clearInterval(musicTimer); musicTimer = null; } }

// ================= Экран и ввод =================
function resize() {
  dpr = Math.min(window.devicePixelRatio || 1, 2.5);
  W = window.innerWidth; H = window.innerHeight;
  cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
  cv.style.width = W + 'px'; cv.style.height = H + 'px';
  Z = Math.max(0.6, Math.min(1.4, Math.min(W, H) / 520));
  try { topPad = Math.max(12, parseFloat(getComputedStyle($('inset')).paddingTop) || 0) + 4; } catch (e) { topPad = 16; }
}
const viewW = () => W / Z;
const viewH = () => H / Z;

const stick = { a: false, id: null, ox: 0, oy: 0, x: 0, y: 0, dx: 0, dy: 0 };
const keys = new Set();

cv.addEventListener('pointerdown', e => {
  initAudio();
  if (!G || G.state !== 'run' || stick.a) return;
  stick.a = true; stick.id = e.pointerId;
  stick.ox = stick.x = e.clientX; stick.oy = stick.y = e.clientY;
  stick.dx = stick.dy = 0;
  try { cv.setPointerCapture(e.pointerId); } catch (err) {}
  if (e.preventDefault) e.preventDefault();
});
cv.addEventListener('pointermove', e => {
  if (!stick.a || e.pointerId !== stick.id) return;
  stick.x = e.clientX; stick.y = e.clientY;
  let dx = stick.x - stick.ox, dy = stick.y - stick.oy;
  const len = Math.hypot(dx, dy), R = 56;
  if (len > R) { // плавающий джойстик: база тянется за пальцем
    stick.ox += dx / len * (len - R); stick.oy += dy / len * (len - R);
    dx = stick.x - stick.ox; dy = stick.y - stick.oy;
  }
  const l = Math.hypot(dx, dy);
  if (l < 6) { stick.dx = stick.dy = 0; }
  else { const k = Math.min(1, l / R); stick.dx = dx / l * k; stick.dy = dy / l * k; }
  if (e.preventDefault) e.preventDefault();
});
function stickEnd(e) {
  if (e.pointerId !== stick.id) return;
  stick.a = false; stick.dx = stick.dy = 0;
}
cv.addEventListener('pointerup', stickEnd);
cv.addEventListener('pointercancel', stickEnd);

window.addEventListener('keydown', e => {
  const k = (e.key || '').toLowerCase();
  if (k === 'escape') { window.__back(); return; }
  keys.add(k);
});
window.addEventListener('keyup', e => keys.delete((e.key || '').toLowerCase()));
document.addEventListener('pointerdown', initAudio);
document.addEventListener('contextmenu', e => e.preventDefault());
window.addEventListener('resize', resize);
document.addEventListener('visibilitychange', () => { if (document.hidden) pauseGame(); });

// ================= Расчёт характеристик =================
const dmgMul = () => (1 + 0.15 * G.ps.dmg) * (1 + 0.08 * S.meta.dmg) * HEROES[S.hero].dmg;
const spdMul = () => (1 + 0.08 * G.ps.spd) * (1 + 0.04 * S.meta.spd) * HEROES[S.hero].spd;
const magR   = () => 70 * (1 + 0.3 * G.ps.mag) * (1 + 0.15 * S.meta.mag);
const cdMul  = () => 1 / (1 + 0.12 * G.ps.rate);
const xpMul  = () => (1 + 0.12 * G.ps.xp) * (1 + 0.08 * S.meta.xp);
const xpNeed = l => Math.floor(5 + l * 4 + l * l * 0.6);
const hpMul  = t => 1 + (t / 60) * 0.3 + Math.pow(t / 60, 2) * 0.025;

// ================= Старт забега =================
function startRun() {
  const h = HEROES[S.hero], m = S.meta;
  const maxHp = 100 + m.hp * 15 + h.hp;
  G = {
    t: 0, state: 'run',
    p: { x: 0, y: 0, r: 11, hp: maxHp, maxHp, inv: 0, face: -Math.PI / 2, revives: m.rev, flash: 0 },
    w: { pulse: 0, orbit: 0, nova: 0, chain: 0, laser: 0 },
    cd: { pulse: 0, nova: 1, chain: 0.5, laser: 1 },
    ps: { dmg: 0, rate: 0, spd: 0, hp: 0, mag: 0, armor: 0, regen: 0, xp: 0 },
    en: [], bu: [], eb: [], gm: [], pt: [], tx: [], fx: [],
    xp: 0, lvl: 1, xpNext: xpNeed(1), pending: 0, choices: [],
    kills: 0, spawnAcc: 0, nextBoss: 0, boss: null, shake: 0, orbAng: 0, nid: 1,
    streak: 0, gemT: -9, banner: null, bonus: 0, winT: 0,
  };
  G.w[h.start] = 1;
  stick.a = false; stick.dx = stick.dy = 0;
  showScreen(null);
  $('pauseBtn').classList.remove('hidden');
  say('Выживи 12 минут', '#5ee7ff');
  musicStart();
}

function say(text, col, life) { G.banner = { text, col: col || '#fff', life: life || 2.2, max: life || 2.2 }; }

// ================= Спавн =================
function pickType(t) {
  const pool = [['grunt', 10]];
  if (t > 25)  pool.push(['runner', 4 + Math.min(6, t / 40)]);
  if (t > 80)  pool.push(['shooter', 2 + t / 90]);
  if (t > 110) pool.push(['tank', 2 + t / 100]);
  if (t > 170) pool.push(['splitter', 2 + t / 120]);
  let sum = 0; for (const a of pool) sum += a[1];
  let r = Math.random() * sum;
  for (const a of pool) { r -= a[1]; if (r <= 0) return a[0]; }
  return 'grunt';
}

function ringPos() {
  const a = Math.random() * TAU, d = Math.max(viewW(), viewH()) / 2 + 40;
  return [G.p.x + Math.cos(a) * d, G.p.y + Math.sin(a) * d];
}

function spawnEnemy(type, x, y, forceElite) {
  const g = G, d = ET[type], t = g.t;
  if (x === undefined) { const q = ringPos(); x = q[0]; y = q[1]; }
  const elite = !!forceElite || (t > 150 && type !== 'mini' && Math.random() < 0.035);
  const hm = hpMul(t) * (elite ? 5 : 1);
  g.en.push({
    id: g.nid++, type, x, y, kx: 0, ky: 0,
    r: d.r * (elite ? 1.35 : 1), hp: d.hp * hm, maxHp: d.hp * hm,
    sp: d.sp * (elite ? 0.9 : 1) * (0.9 + Math.random() * 0.2),
    dmg: d.dmg * (1 + t / 720 * 0.8), xp: d.xp * (elite ? 4 : 1),
    col: d.col, sides: d.sides, elite, flash: 0, shoot: 1 + Math.random() * 2,
    ph: Math.random() * TAU, oh: -9, boss: false, dead: false,
  });
}

function spawnBoss(i) {
  const g = G, fin = i === 3, q = ringPos();
  const hp = fin ? 20000 : [1500, 4000, 8500][i];
  const b = {
    id: g.nid++, type: 'boss', x: q[0], y: q[1], kx: 0, ky: 0,
    r: fin ? 46 : 30 + i * 5, hp, maxHp: hp, sp: fin ? 56 : 42 + i * 3, dmg: 20, xp: 0,
    col: fin ? '#ff2e63' : ['#ff9f1c', '#2ec4b6', '#e71d36'][i],
    sides: fin ? 10 : 6 + i * 2, elite: false, boss: true, idx: i, flash: 0,
    ph: 0, oh: -9, dead: false, atk: 2.5, chargeT: 6, cstate: 0, cdx: 0, cdy: 0, cTimer: 0, adds: 5, name: BOSS_NAMES[i],
  };
  g.en.push(b); g.boss = b;
  say('БОСС: ' + b.name, '#ff4d6d', 3);
  g.shake = 12;
  sfx('boss'); buzz(120);
}

// ================= Урон и смерть =================
function addText(x, y, s, col) {
  if (G.tx.length > 36) return;
  G.tx.push({ x: x + (Math.random() - 0.5) * 10, y, s: String(s), col: col || '#fff', life: 0.7, max: 0.7 });
}

function burst(x, y, col, n, spd) {
  const g = G;
  for (let i = 0; i < n && g.pt.length < 260; i++) {
    const a = Math.random() * TAU, v = (spd || 120) * (0.3 + Math.random());
    g.pt.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: 0.35 + Math.random() * 0.35, max: 0.7, col, size: 2 + Math.random() * 3 });
  }
}

function hit(e, dmg, kx, ky) {
  if (e.dead) return;
  e.hp -= dmg; e.flash = 0.07;
  if (kx || ky) { if (!e.boss) { e.kx += kx; e.ky += ky; } }
  addText(e.x, e.y - e.r, Math.max(1, Math.round(dmg)));
  sfx('hit');
  if (e.hp <= 0) kill(e);
}

function dropGem(x, y, v) {
  const g = G;
  if (g.gm.length > 320) { addXp(g.gm.shift().v); }
  g.gm.push({ x: x + (Math.random() - 0.5) * 10, y: y + (Math.random() - 0.5) * 10, v, pull: false, kind: 0 });
}
function dropHeart(x, y) { G.gm.push({ x, y, v: 0, pull: false, kind: 1 }); }

function kill(e) {
  const g = G;
  if (e.dead) return;
  e.dead = true; g.kills++;
  burst(e.x, e.y, e.col, e.boss ? 40 : 7, e.boss ? 260 : 130);
  if (e.boss) {
    for (let i = 0; i < 5; i++) dropGem(e.x, e.y, 20);
    dropHeart(e.x, e.y);
    g.boss = null; g.shake = 18;
    if (e.idx === 3) { winSequence(); return; }
    say('Босс повержен!', '#ffd166', 2.6);
    sfx('bosskill'); buzz(150);
    return;
  }
  dropGem(e.x, e.y, e.xp);
  if (Math.random() < (e.elite ? 0.3 : 0.012)) dropHeart(e.x, e.y);
  if (e.type === 'splitter') for (let i = 0; i < 3; i++) spawnEnemy('mini', e.x + (Math.random() - 0.5) * 24, e.y + (Math.random() - 0.5) * 24);
}

function hurt(raw) {
  const g = G, p = g.p;
  const d = Math.max(1, Math.round(raw - g.ps.armor));
  p.hp -= d; p.inv = 0.55; p.flash = 0.18;
  g.shake = Math.max(g.shake, 7);
  addText(p.x, p.y - 18, '-' + d, '#ff6b81');
  sfx('hurt'); buzz(25);
  if (p.hp <= 0) {
    if (p.revives > 0) {
      p.revives--; p.hp = p.maxHp * 0.5; p.inv = 2.5;
      for (const e of g.en) {
        const dx = e.x - p.x, dy = e.y - p.y, dist = Math.hypot(dx, dy) || 1;
        if (dist < 320 && !e.boss) { e.kx += dx / dist * 700; e.ky += dy / dist * 700; }
      }
      g.eb.length = 0;
      g.fx.push({ k: 'ring', x: p.x, y: p.y, r1: 320, life: 0.5, max: 0.5, col: '#ffd166' });
      say('Второй шанс!', '#ffd166');
      sfx('level');
    } else {
      p.hp = 0; die();
    }
  }
}

function die() {
  const g = G;
  if (g.state === 'dead') return;
  g.state = 'dead'; g.winT = 1.3;
  burst(g.p.x, g.p.y, '#5ee7ff', 40, 260);
  g.shake = 14;
  sfx('die'); buzz(200);
}

function winSequence() {
  const g = G;
  g.state = 'win'; g.winT = 2.8;
  for (const e of g.en) if (!e.dead) { e.dead = true; burst(e.x, e.y, e.col, 3, 160); dropGem(e.x, e.y, e.xp || 1); }
  g.eb.length = 0;
  say('ПОБЕДА!', '#ffd166', 3);
  sfx('win'); buzz(250);
}

// ================= Опыт и уровни =================
function addXp(v) {
  const g = G;
  g.xp += v * xpMul();
  while (g.xp >= g.xpNext) { g.xp -= g.xpNext; g.lvl++; g.xpNext = xpNeed(g.lvl); g.pending++; }
}

function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }

function openLevelUp() {
  const g = G;
  g.state = 'levelup'; stick.a = false; stick.dx = stick.dy = 0;
  const pool = [];
  for (const k in WEAPONS) if (g.w[k] < 5) pool.push({ t: 'w', k });
  for (const k in PASSIVES) if (g.ps[k] < 5) pool.push({ t: 'p', k });
  shuffle(pool);
  let ch = pool.slice(0, 3);
  const owned = Object.keys(g.w).filter(k => g.w[k] > 0).length;
  if (owned < 3 && ch.length && !ch.some(c => c.t === 'w')) {
    const wo = pool.find(c => c.t === 'w');
    if (wo) { if (ch.length < 3) ch.push(wo); else ch[2] = wo; }
  }
  if (!ch.length) ch = [{ t: 'heal' }, { t: 'gold' }];
  g.choices = ch;
  $('cards').innerHTML = ch.map((c, i) => {
    let ic, name, sub = '', desc;
    if (c.t === 'w') { const d = WEAPONS[c.k], lv = g.w[c.k]; ic = d.icon; name = d.name; sub = lv ? `Уровень ${lv} → ${lv + 1}` : 'Новое оружие'; desc = d.desc; }
    else if (c.t === 'p') { const d = PASSIVES[c.k], lv = g.ps[c.k]; ic = d.icon; name = d.name; sub = lv ? `Уровень ${lv} → ${lv + 1}` : 'Новое улучшение'; desc = d.desc; }
    else if (c.t === 'heal') { ic = '🔧'; name = 'Ремонт'; desc = 'Восстановить 40% HP.'; }
    else { ic = '◈'; name = 'Трофеи'; desc = '+25 ядер после забега.'; }
    return `<button class="card ${c.t}" data-i="${i}"><span class="ic">${ic}</span><span class="tx"><b>${name}</b><i>${sub}</i><em>${desc}</em></span></button>`;
  }).join('');
  showScreen('levelup');
  sfx('level');
}

function pickChoice(i) {
  const g = G;
  if (!g || g.state !== 'levelup') return;
  const c = g.choices[i];
  if (!c) return;
  if (c.t === 'w') g.w[c.k]++;
  else if (c.t === 'p') {
    g.ps[c.k]++;
    if (c.k === 'hp') { g.p.maxHp += 20; g.p.hp += 20; }
  } else if (c.t === 'heal') g.p.hp = Math.min(g.p.maxHp, g.p.hp + g.p.maxHp * 0.4);
  else g.bonus += 25;
  sfx('click');
  g.pending--;
  if (g.pending > 0) openLevelUp();
  else { g.state = 'run'; showScreen(null); }
}

// ================= Оружие =================
function nearest(x, y, maxD, n) {
  const arr = [], m2 = maxD * maxD;
  for (const e of G.en) {
    if (e.dead) continue;
    const dx = e.x - x, dy = e.y - y, d = dx * dx + dy * dy;
    if (d < m2) arr.push([d, e]);
  }
  arr.sort((a, b) => a[0] - b[0]);
  return arr.slice(0, n).map(a => a[1]);
}

function orbPos(i, n, R) {
  const a = G.orbAng + i * TAU / n;
  return [G.p.x + Math.cos(a) * R, G.p.y + Math.sin(a) * R];
}
const orbCount = L => [2, 3, 3, 4, 5][L - 1];
const orbRadius = L => 62 + 5 * L;

function weapons(dt) {
  const g = G, p = g.p, w = g.w, cdm = cdMul(), dm = dmgMul();

  // Импульс
  if (w.pulse > 0) {
    g.cd.pulse -= dt;
    if (g.cd.pulse <= 0) {
      const L = w.pulse, n = [1, 2, 2, 3, 4][L - 1];
      const tg = nearest(p.x, p.y, 480, n);
      if (tg.length) {
        g.cd.pulse = (0.95 - 0.11 * L) * cdm;
        for (let i = 0; i < n; i++) {
          const e = tg[i % tg.length];
          let a = Math.atan2(e.y - p.y, e.x - p.x);
          if (tg.length < n) a += (i - (n - 1) / 2) * 0.16;
          g.bu.push({ x: p.x, y: p.y, vx: Math.cos(a) * 430, vy: Math.sin(a) * 430, r: 5, dmg: (10 + 5 * L) * dm, pierce: L >= 4 ? 1 : 0, life: 1.2, hit: [] });
        }
        sfx('shoot');
      } else g.cd.pulse = 0.1;
    }
  }

  // Клинки
  if (w.orbit > 0) {
    const L = w.orbit, n = orbCount(L), R = orbRadius(L), od = (7 + 3 * L) * dm;
    g.orbAng += (2.6 + 0.25 * L) * dt;
    for (let i = 0; i < n; i++) {
      const o = orbPos(i, n, R);
      for (const e of g.en) {
        if (e.dead) continue;
        const dx = e.x - o[0], dy = e.y - o[1], rr = e.r + 9;
        if (dx * dx + dy * dy < rr * rr && g.t - e.oh > 0.4) { e.oh = g.t; hit(e, od, dx * 8, dy * 8); }
      }
    }
  }

  // Нова
  if (w.nova > 0) {
    g.cd.nova -= dt;
    if (g.cd.nova <= 0) {
      const L = w.nova, R = 80 + 22 * L;
      if (nearest(p.x, p.y, R + 40, 1).length) {
        g.cd.nova = (3.6 - 0.38 * L) * cdm;
        const nd = (16 + 9 * L) * dm;
        for (const e of g.en) {
          if (e.dead) continue;
          const dx = e.x - p.x, dy = e.y - p.y, d = Math.hypot(dx, dy) || 1;
          if (d < R + e.r) hit(e, nd, dx / d * 320, dy / d * 320);
        }
        g.fx.push({ k: 'ring', x: p.x, y: p.y, r1: R, life: 0.35, max: 0.35, col: '#ff4d9d' });
        sfx('nova');
      } else g.cd.nova = 0.15;
    }
  }

  // Молния
  if (w.chain > 0) {
    g.cd.chain -= dt;
    if (g.cd.chain <= 0) {
      const L = w.chain, first = nearest(p.x, p.y, 320, 1)[0];
      if (first) {
        g.cd.chain = (1.7 - 0.2 * L) * cdm;
        const jumps = 2 + L, cd = (12 + 6 * L) * dm, used = new Set();
        const pts = [{ x: p.x, y: p.y }];
        let cur = first;
        for (let j = 0; j <= jumps && cur; j++) {
          used.add(cur.id);
          pts.push({ x: cur.x, y: cur.y });
          const cx = cur.x, cy = cur.y;
          hit(cur, cd, 0, 0);
          let best = null, bd = 150 * 150;
          for (const e of g.en) {
            if (e.dead || used.has(e.id)) continue;
            const dx = e.x - cx, dy = e.y - cy, d = dx * dx + dy * dy;
            if (d < bd) { bd = d; best = e; }
          }
          cur = best;
        }
        g.fx.push({ k: 'bolt', pts, life: 0.18, max: 0.18 });
        sfx('zap');
      } else g.cd.chain = 0.15;
    }
  }

  // Луч
  if (w.laser > 0) {
    g.cd.laser -= dt;
    if (g.cd.laser <= 0) {
      const L = w.laser, nb = L >= 5 ? 3 : L >= 3 ? 2 : 1;
      const tg = nearest(p.x, p.y, 520, nb);
      if (tg.length) {
        g.cd.laser = (2.6 - 0.3 * L) * cdm;
        const hw = 6 + 1.5 * L, ld = (26 + 12 * L) * dm, len = 560;
        for (let b = 0; b < nb; b++) {
          const e0 = tg[b % tg.length];
          let a = Math.atan2(e0.y - p.y, e0.x - p.x);
          if (tg.length < nb) a += (b - (nb - 1) / 2) * 0.35;
          const dx = Math.cos(a), dy = Math.sin(a);
          for (const e of g.en) {
            if (e.dead) continue;
            const ex = e.x - p.x, ey = e.y - p.y;
            const tt = ex * dx + ey * dy;
            if (tt > 0 && tt < len && Math.abs(ex * dy - ey * dx) < hw + e.r) hit(e, ld, dx * 120, dy * 120);
          }
          g.fx.push({ k: 'beam', x: p.x, y: p.y, dx, dy, len, w: hw * 1.6, life: 0.22, max: 0.22 });
        }
        sfx('zap'); g.shake = Math.max(g.shake, 2);
      } else g.cd.laser = 0.15;
    }
  }
}

// ================= Обновление мира =================
function update(dt) {
  const g = G;
  if (!g) return;
  if (g.banner) { g.banner.life -= dt; if (g.banner.life <= 0) g.banner = null; }
  g.shake = Math.max(0, g.shake - 40 * dt);

  if (g.state === 'win' || g.state === 'dead') {
    updateFx(dt);
    g.winT -= dt;
    if (g.winT <= 0) endRun(g.state === 'win');
    return;
  }
  if (g.state !== 'run') return;

  g.t += dt;
  const p = g.p;

  // движение
  let ix = stick.dx, iy = stick.dy;
  if (keys.size) {
    const kx = (keys.has('d') || keys.has('arrowright') || keys.has('в') ? 1 : 0) - (keys.has('a') || keys.has('arrowleft') || keys.has('ф') ? 1 : 0);
    const ky = (keys.has('s') || keys.has('arrowdown') || keys.has('ы') ? 1 : 0) - (keys.has('w') || keys.has('arrowup') || keys.has('ц') ? 1 : 0);
    if (kx || ky) { const l = Math.hypot(kx, ky); ix = kx / l; iy = ky / l; }
  }
  const sp = 150 * spdMul();
  p.x += ix * sp * dt; p.y += iy * sp * dt;
  if (ix || iy) p.face = Math.atan2(iy, ix);
  p.inv -= dt; p.flash -= dt;
  const regen = 0.4 * g.ps.regen;
  if (regen && p.hp < p.maxHp) p.hp = Math.min(p.maxHp, p.hp + regen * dt);

  spawnTick(dt);
  weapons(dt);
  enemiesTick(dt);
  bulletsTick(dt);
  gemsTick(dt);
  updateFx(dt);

  g.en = g.en.filter(e => !e.dead);

  if (g.pending > 0 && g.state === 'run') openLevelUp();
}

function spawnTick(dt) {
  const g = G, t = g.t;
  let rate = 1.4 + (t / 60) * 1.25;
  if (g.boss) rate *= 0.45;
  g.spawnAcc += rate * dt;
  const cap = 90 + Math.min(220, t * 0.35);
  while (g.spawnAcc >= 1) {
    g.spawnAcc -= 1;
    if (g.en.length < cap) spawnEnemy(pickType(t));
  }
  if (g.nextBoss < 4 && t >= BOSS_TIMES[g.nextBoss]) { spawnBoss(g.nextBoss); g.nextBoss++; }
}

function enemyBullet(x, y, a, spd, dmg, r) {
  G.eb.push({ x, y, vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, r: r || 5, dmg, life: 6 });
}

function enemiesTick(dt) {
  const g = G, p = g.p, t = g.t;
  const far = Math.max(viewW(), viewH()) / 2 + 260;
  for (let i = 0; i < g.en.length; i++) {
    const e = g.en[i];
    if (e.dead) continue;
    const dx = p.x - e.x, dy = p.y - e.y, d = Math.hypot(dx, dy) || 1;
    let mx = dx / d, my = dy / d, sp = e.sp;

    if (e.type === 'shooter') {
      if (d < 190) { mx = -mx; my = -my; sp *= 0.7; }
      else if (d < 250) sp = 0;
      e.shoot -= dt;
      if (e.shoot <= 0 && d < 420) { e.shoot = 2.4; enemyBullet(e.x, e.y, Math.atan2(dy, dx), 150, e.dmg, 5); }
    }

    if (e.boss) {
      const fin = e.idx === 3;
      if (e.cstate === 2) { // рывок
        e.cTimer -= dt; mx = e.cdx; my = e.cdy; sp = 380;
        if (e.cTimer <= 0) { e.cstate = 0; e.chargeT = fin ? 5 : 6.5; }
      } else {
        e.chargeT -= dt;
        if (e.cstate === 0 && e.chargeT <= 0.9) { e.cstate = 1; e.cdx = mx; e.cdy = my; }
        if (e.cstate === 1) {
          sp = 0; e.cdx = mx; e.cdy = my;
          if (e.chargeT <= 0) { e.cstate = 2; e.cTimer = 0.6; }
        }
        e.atk -= dt;
        if (e.atk <= 0) {
          e.atk = fin ? 2.2 : 3;
          const n = fin ? 26 : 12 + e.idx * 4, off = Math.random() * TAU;
          for (let k = 0; k < n; k++) enemyBullet(e.x, e.y, off + k * TAU / n, 125 + e.idx * 10, 10 + e.idx * 2, 6);
        }
        if (fin) {
          e.adds -= dt;
          if (e.adds <= 0) { e.adds = 5; for (let k = 0; k < 6; k++) { const a = k * TAU / 6; spawnEnemy('runner', e.x + Math.cos(a) * 60, e.y + Math.sin(a) * 60); } }
        }
      }
      e.ph += dt * 0.8;
    } else {
      const wob = Math.sin(t * 2 + e.ph) * 0.25;
      const tx = mx; mx = mx - my * wob; my = my + tx * wob;
    }

    e.x += (mx * sp + e.kx) * dt;
    e.y += (my * sp + e.ky) * dt;
    const kd = Math.max(0, 1 - 8 * dt); e.kx *= kd; e.ky *= kd;
    if (e.flash > 0) e.flash -= dt;

    if (d < e.r + p.r && p.inv <= 0) hurt(e.dmg);

    if (!e.boss && d > far) { const q = ringPos(); e.x = q[0]; e.y = q[1]; }
  }
}

function bulletsTick(dt) {
  const g = G, p = g.p;
  for (const b of g.bu) {
    b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
    for (const e of g.en) {
      if (e.dead || b.life <= 0) continue;
      const dx = e.x - b.x, dy = e.y - b.y, rr = e.r + b.r;
      if (dx * dx + dy * dy < rr * rr && b.hit.indexOf(e.id) < 0) {
        b.hit.push(e.id);
        hit(e, b.dmg, b.vx * 0.25, b.vy * 0.25);
        if (b.pierce-- <= 0) { b.life = 0; break; }
      }
    }
  }
  g.bu = g.bu.filter(b => b.life > 0);

  for (const b of g.eb) {
    b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
    const dx = p.x - b.x, dy = p.y - b.y, rr = p.r + b.r;
    if (dx * dx + dy * dy < rr * rr && p.inv <= 0 && g.state === 'run') { b.life = 0; hurt(b.dmg); }
  }
  g.eb = g.eb.filter(b => b.life > 0);
}

function gemsTick(dt) {
  const g = G, p = g.p, mr = magR();
  for (let i = g.gm.length - 1; i >= 0; i--) {
    const m = g.gm[i];
    const dx = p.x - m.x, dy = p.y - m.y, d = Math.hypot(dx, dy) || 1;
    if (d < mr) m.pull = true;
    if (m.pull) { const s = 280 + (mr - Math.min(d, mr)) * 2 + 120; m.x += dx / d * s * dt; m.y += dy / d * s * dt; }
    if (d < p.r + 8) {
      if (m.kind === 1) {
        p.hp = Math.min(p.maxHp, p.hp + 20);
        addText(p.x, p.y - 18, '+20', '#7dff9d');
        sfx('level');
      } else {
        addXp(m.v);
        g.streak = (g.t - g.gemT < 0.4) ? g.streak + 1 : 0; g.gemT = g.t;
        sfx('gem', g.streak);
      }
      g.gm.splice(i, 1);
    }
  }
}

function updateFx(dt) {
  const g = G;
  for (const q of g.pt) { q.life -= dt; q.x += q.vx * dt; q.y += q.vy * dt; q.vx *= 0.94; q.vy *= 0.94; }
  g.pt = g.pt.filter(q => q.life > 0);
  for (const f of g.fx) f.life -= dt;
  g.fx = g.fx.filter(f => f.life > 0);
  for (const s of g.tx) { s.life -= dt; s.y -= 26 * dt; }
  g.tx = g.tx.filter(s => s.life > 0);
}

// ================= Конец забега =================
function fmtTime(s) { s = Math.floor(s); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); }

function endRun(win) {
  const g = G;
  if (!g || g.over) return;
  g.over = true; g.state = 'over';
  const cores = Math.floor(g.kills / 8) + Math.floor(g.t / 6) + (win ? 150 : 0) + g.bonus;
  S.cores += cores;
  S.bestT = Math.max(S.bestT, Math.floor(g.t));
  S.bestK = Math.max(S.bestK, g.kills);
  if (win) S.wins++;
  persist();
  musicStop();
  $('pauseBtn').classList.add('hidden');
  $('endTitle').textContent = win ? 'Победа!' : 'Забег окончен';
  $('endStats').innerHTML =
    `<div>Время<b>${fmtTime(g.t)}</b></div>` +
    `<div>Уровень<b>${g.lvl}</b></div>` +
    `<div>Уничтожено<b>${g.kills}</b></div>` +
    `<div class="gain">Ядра<b>+${cores} ◈</b></div>`;
  showScreen('end');
}

// ================= Отрисовка =================
function poly(x, y, r, n, rot) {
  ctx.beginPath();
  for (let i = 0; i < n; i++) {
    const a = rot + i * TAU / n;
    const px = x + Math.cos(a) * r, py = y + Math.sin(a) * r;
    if (i) ctx.lineTo(px, py); else ctx.moveTo(px, py);
  }
  ctx.closePath();
}

function drawGrid(camx, camy, vw, vh) {
  const step = 60;
  const x0 = Math.floor(camx / step) * step, y0 = Math.floor(camy / step) * step;
  ctx.lineWidth = 1;
  ctx.strokeStyle = 'rgba(80,120,255,0.09)';
  ctx.beginPath();
  for (let x = x0; x < camx + vw + step; x += step) if (Math.round(x / step) % 4) { ctx.moveTo(x, camy); ctx.lineTo(x, camy + vh); }
  for (let y = y0; y < camy + vh + step; y += step) if (Math.round(y / step) % 4) { ctx.moveTo(camx, y); ctx.lineTo(camx + vw, y); }
  ctx.stroke();
  ctx.strokeStyle = 'rgba(94,231,255,0.17)';
  ctx.beginPath();
  for (let x = x0; x < camx + vw + step; x += step) if (!(Math.round(x / step) % 4)) { ctx.moveTo(x, camy); ctx.lineTo(x, camy + vh); }
  for (let y = y0; y < camy + vh + step; y += step) if (!(Math.round(y / step) % 4)) { ctx.moveTo(camx, y); ctx.lineTo(camx + vw, y); }
  ctx.stroke();
}

function drawEnemy(e, t) {
  const col = e.flash > 0 ? '#ffffff' : e.col;
  if (e.sides < 3) { ctx.beginPath(); ctx.arc(e.x, e.y, e.r, 0, TAU); }
  else poly(e.x, e.y, e.r, e.sides, e.boss ? t * 0.5 : -Math.PI / 2);
  ctx.globalAlpha = e.flash > 0 ? 0.9 : 0.28;
  ctx.fillStyle = col; ctx.fill();
  ctx.globalAlpha = 1;
  ctx.lineWidth = e.elite ? 3 : 2;
  ctx.strokeStyle = col; ctx.stroke();
  if (e.elite) { ctx.globalAlpha = 0.5; ctx.beginPath(); ctx.arc(e.x, e.y, e.r + 4, 0, TAU); ctx.stroke(); ctx.globalAlpha = 1; }
  if (e.type === 'splitter') { ctx.beginPath(); ctx.arc(e.x, e.y, e.r * 0.4, 0, TAU); ctx.stroke(); }
  if (e.boss) {
    poly(e.x, e.y, e.r * 0.6, e.sides, -t * 0.9); ctx.lineWidth = 2; ctx.stroke();
    ctx.beginPath(); ctx.arc(e.x, e.y, e.r * 0.22, 0, TAU); ctx.fillStyle = col; ctx.globalAlpha = 0.8; ctx.fill(); ctx.globalAlpha = 1;
  }
}

function render() {
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = '#070913';
  ctx.fillRect(0, 0, W, H);
  const g = G;
  const vw = viewW(), vh = viewH();

  if (!g) { // фон меню: плывущая сетка
    ctx.setTransform(dpr * Z, 0, 0, dpr * Z, 0, 0);
    drawGrid(bgT * 20, bgT * 12, vw, vh);
    return;
  }

  const p = g.p, t = g.t;
  const sx = g.shake > 0 ? (Math.random() - 0.5) * g.shake : 0, sy = g.shake > 0 ? (Math.random() - 0.5) * g.shake : 0;
  const camx = p.x - vw / 2 + sx, camy = p.y - vh / 2 + sy;
  ctx.setTransform(dpr * Z, 0, 0, dpr * Z, -camx * dpr * Z, -camy * dpr * Z);

  drawGrid(camx, camy, vw, vh);

  // кристаллы и сердечки
  for (const m of g.gm) {
    if (m.kind === 1) {
      ctx.fillStyle = '#ff4d6d';
      ctx.fillRect(m.x - 2.5, m.y - 7, 5, 14); ctx.fillRect(m.x - 7, m.y - 2.5, 14, 5);
    } else {
      const s = m.v >= 20 ? 8 : m.v >= 4 ? 6 : 4;
      ctx.fillStyle = m.v >= 20 ? '#ff7df0' : m.v >= 4 ? '#7dff9d' : '#5ee7ff';
      poly(m.x, m.y, s, 4, Math.PI / 4); ctx.fill();
    }
  }

  // пули врагов
  ctx.fillStyle = '#ff6b81';
  for (const b of g.eb) { ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, TAU); ctx.fill(); }

  // враги
  for (const e of g.en) {
    if (e.dead) continue;
    if (e.x < camx - 60 || e.x > camx + vw + 60 || e.y < camy - 60 || e.y > camy + vh + 60) continue;
    drawEnemy(e, t);
    if (e.boss && e.cstate === 1) { // телеграф рывка
      ctx.strokeStyle = 'rgba(255,60,90,' + (0.35 + 0.35 * Math.sin(t * 30)) + ')';
      ctx.lineWidth = e.r * 1.2;
      ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.lineTo(e.x + e.cdx * 600, e.y + e.cdy * 600); ctx.stroke();
    }
  }

  // эффекты оружия (аддитивное свечение)
  ctx.globalCompositeOperation = 'lighter';
  for (const f of g.fx) {
    const k = Math.max(0, f.life / f.max);
    if (f.k === 'ring') {
      ctx.strokeStyle = f.col; ctx.globalAlpha = k; ctx.lineWidth = 6 * k + 2;
      ctx.beginPath(); ctx.arc(f.x, f.y, f.r1 * (1 - k * k), 0, TAU); ctx.stroke();
    } else if (f.k === 'bolt') {
      ctx.strokeStyle = '#9ff0ff'; ctx.globalAlpha = k; ctx.lineWidth = 3;
      ctx.beginPath();
      for (let i = 0; i < f.pts.length; i++) {
        const q = f.pts[i];
        if (i) {
          const a = f.pts[i - 1], mx = (a.x + q.x) / 2 + (Math.random() - 0.5) * 16, my = (a.y + q.y) / 2 + (Math.random() - 0.5) * 16;
          ctx.lineTo(mx, my); ctx.lineTo(q.x, q.y);
        } else ctx.moveTo(q.x, q.y);
      }
      ctx.stroke();
    } else if (f.k === 'beam') {
      ctx.strokeStyle = '#ffd166'; ctx.globalAlpha = k * 0.9; ctx.lineWidth = f.w * k + 2;
      ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.lineTo(f.x + f.dx * f.len, f.y + f.dy * f.len); ctx.stroke();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(1, f.w * 0.3 * k);
      ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.lineTo(f.x + f.dx * f.len, f.y + f.dy * f.len); ctx.stroke();
    }
  }
  ctx.globalAlpha = 1;

  // снаряды игрока и клинки
  ctx.fillStyle = '#7dfcff';
  for (const b of g.bu) {
    ctx.globalAlpha = 0.3; ctx.beginPath(); ctx.arc(b.x, b.y, b.r * 2.2, 0, TAU); ctx.fill();
    ctx.globalAlpha = 1; ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, TAU); ctx.fill();
  }
  if (g.w.orbit > 0) {
    const L = g.w.orbit, n = orbCount(L), R = orbRadius(L);
    ctx.fillStyle = '#ff9ad1';
    for (let i = 0; i < n; i++) {
      const o = orbPos(i, n, R);
      ctx.globalAlpha = 0.3; ctx.beginPath(); ctx.arc(o[0], o[1], 16, 0, TAU); ctx.fill();
      ctx.globalAlpha = 1; poly(o[0], o[1], 9, 4, g.orbAng * 3); ctx.fill();
    }
  }
  ctx.globalCompositeOperation = 'source-over';
  ctx.globalAlpha = 1;

  // частицы
  for (const q of g.pt) {
    ctx.globalAlpha = Math.max(0, q.life / q.max);
    ctx.fillStyle = q.col;
    ctx.fillRect(q.x - q.size / 2, q.y - q.size / 2, q.size, q.size);
  }
  ctx.globalAlpha = 1;

  // игрок
  if (g.state !== 'dead') {
    const blink = p.inv > 0 && Math.floor(t * 20) % 2 === 0;
    ctx.globalAlpha = blink ? 0.35 : 1;
    ctx.beginPath(); ctx.arc(p.x, p.y, p.r + 7, 0, TAU);
    ctx.fillStyle = 'rgba(94,231,255,0.12)'; ctx.fill();
    ctx.beginPath();
    const a = p.face;
    ctx.moveTo(p.x + Math.cos(a) * 15, p.y + Math.sin(a) * 15);
    ctx.lineTo(p.x + Math.cos(a + 2.5) * 12, p.y + Math.sin(a + 2.5) * 12);
    ctx.lineTo(p.x + Math.cos(a + Math.PI) * 5, p.y + Math.sin(a + Math.PI) * 5);
    ctx.lineTo(p.x + Math.cos(a - 2.5) * 12, p.y + Math.sin(a - 2.5) * 12);
    ctx.closePath();
    ctx.fillStyle = p.flash > 0 ? '#ff6b81' : '#5ee7ff'; ctx.fill();
    ctx.lineWidth = 2; ctx.strokeStyle = '#ffffff'; ctx.stroke();
    ctx.globalAlpha = 1;
  }

  // цифры урона
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.font = '700 15px system-ui, sans-serif';
  for (const s of g.tx) {
    ctx.globalAlpha = Math.min(1, s.life / 0.3);
    ctx.fillStyle = s.col;
    ctx.fillText(s.s, s.x, s.y);
  }
  ctx.globalAlpha = 1;

  drawHud();
}

function drawHud() {
  const g = G, p = g.p;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.textBaseline = 'middle';

  // опыт
  ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.fillRect(0, topPad - 4, W, 7);
  ctx.fillStyle = '#5ee7ff'; ctx.fillRect(0, topPad - 4, W * Math.min(1, g.xp / g.xpNext), 7);

  // здоровье
  const bw = Math.min(200, W * 0.42), bx = 14, by = topPad + 10;
  ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.fillRect(bx, by, bw, 14);
  const hr = Math.max(0, p.hp / p.maxHp);
  ctx.fillStyle = hr > 0.35 ? '#4fe08a' : '#ff4d6d'; ctx.fillRect(bx, by, bw * hr, 14);
  ctx.font = '700 11px system-ui, sans-serif'; ctx.textAlign = 'center';
  ctx.fillStyle = '#fff'; ctx.fillText(Math.ceil(p.hp) + ' / ' + Math.ceil(p.maxHp), bx + bw / 2, by + 7.5);
  ctx.textAlign = 'left'; ctx.font = '600 12px system-ui, sans-serif'; ctx.fillStyle = '#8fa0c4';
  ctx.fillText('Ур. ' + g.lvl, bx, by + 26);

  // время и счёт
  ctx.textAlign = 'center';
  ctx.font = '800 26px system-ui, sans-serif'; ctx.fillStyle = '#e9f1ff';
  ctx.fillText(fmtTime(g.t), W / 2 + 24, topPad + 22);
  ctx.font = '600 12px system-ui, sans-serif'; ctx.fillStyle = '#8fa0c4';
  ctx.fillText('☠ ' + g.kills, W / 2 + 24, topPad + 44);

  // босс
  if (g.boss) {
    const w = W * 0.7, x = (W - w) / 2, y = topPad + 62;
    ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.fillRect(x, y, w, 10);
    ctx.fillStyle = g.boss.col; ctx.fillRect(x, y, w * Math.max(0, g.boss.hp / g.boss.maxHp), 10);
    ctx.font = '700 11px system-ui, sans-serif'; ctx.fillStyle = '#fff'; ctx.fillText(g.boss.name, W / 2, y + 22);
  }

  // иконки снаряжения
  ctx.font = '15px system-ui, sans-serif'; ctx.textAlign = 'left';
  let ix = 12; const iy = H - 22 - 8;
  for (const k in WEAPONS) if (g.w[k] > 0) { ctx.fillText(WEAPONS[k].icon, ix, iy); ctx.font = '700 10px system-ui, sans-serif'; ctx.fillStyle = '#ffd166'; ctx.fillText(g.w[k], ix + 15, iy + 8); ctx.font = '15px system-ui, sans-serif'; ix += 30; }
  ctx.textAlign = 'right'; ix = W - 12;
  for (const k in PASSIVES) if (g.ps[k] > 0) { ctx.fillStyle = '#fff'; ctx.fillText(PASSIVES[k].icon, ix - 12, iy); ctx.font = '700 10px system-ui, sans-serif'; ctx.fillStyle = '#8fa0c4'; ctx.fillText(g.ps[k], ix, iy + 8); ctx.font = '15px system-ui, sans-serif'; ix -= 30; }

  // джойстик
  if (stick.a && g.state === 'run') {
    ctx.beginPath(); ctx.arc(stick.ox, stick.oy, 56, 0, TAU);
    ctx.strokeStyle = 'rgba(94,231,255,0.35)'; ctx.lineWidth = 2; ctx.stroke();
    ctx.fillStyle = 'rgba(94,231,255,0.08)'; ctx.fill();
    ctx.beginPath(); ctx.arc(stick.ox + stick.dx * 56, stick.oy + stick.dy * 56, 22, 0, TAU);
    ctx.fillStyle = 'rgba(94,231,255,0.45)'; ctx.fill();
  }

  // баннер
  if (g.banner) {
    const b = g.banner, k = Math.min(1, b.life / 0.5, (b.max - b.life) / 0.2 + 0.2);
    ctx.globalAlpha = Math.max(0, Math.min(1, k));
    ctx.textAlign = 'center';
    ctx.font = '900 ' + Math.min(34, W / 11) + 'px system-ui, sans-serif';
    ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(7,9,19,0.85)';
    ctx.strokeText(b.text, W / 2, H * 0.3);
    ctx.fillStyle = b.col; ctx.fillText(b.text, W / 2, H * 0.3);
    ctx.globalAlpha = 1;
  }
}

// ================= Интерфейс меню =================
const SCREENS = ['menu', 'shop', 'heroes', 'levelup', 'pause', 'end'];
let curScreen = 'menu';
function showScreen(name) {
  curScreen = name;
  for (const s of SCREENS) $(s).classList.toggle('hidden', s !== name);
  if (name === 'menu') renderMenu();
  if (name === 'shop') renderShop();
  if (name === 'heroes') renderHeroes();
}

function renderMenu() {
  $('cores').textContent = S.cores;
  $('heroLine').textContent = 'Герой: ' + HEROES[S.hero].icon + ' ' + HEROES[S.hero].name;
  $('records').textContent = S.bestT ? `Рекорд: ${fmtTime(S.bestT)} · ${S.bestK} убийств · побед: ${S.wins}` : 'Первый забег ещё впереди';
  $('sndBtn').textContent = S.sound ? '🔊 Звук включён' : '🔇 Звук выключен';
}

function renderShop() {
  $('shopCores').textContent = S.cores;
  $('shopList').innerHTML = META.map(m => {
    const lv = S.meta[m.k], max = lv >= m.max, cost = m.cost[lv], can = !max && S.cores >= cost;
    const pips = '●'.repeat(lv) + '○'.repeat(m.max - lv);
    return `<div class="row"><span class="ic">${m.icon}</span><span class="tx"><b>${m.name}</b><em>${m.desc}</em><i>${pips}</i></span><button data-k="${m.k}" ${can ? '' : 'disabled'}>${max ? 'Макс' : '◈ ' + cost}</button></div>`;
  }).join('');
}

function renderHeroes() {
  $('heroCores').textContent = S.cores;
  $('heroList').innerHTML = HEROES.map((h, i) => {
    const own = S.heroes[i], sel = S.hero === i;
    let btn;
    if (sel) btn = '<button disabled>Выбран</button>';
    else if (own) btn = `<button data-h="${i}">Выбрать</button>`;
    else btn = `<button data-h="${i}" ${S.cores >= h.cost ? '' : 'disabled'}>◈ ${h.cost}</button>`;
    return `<div class="row ${sel ? 'sel' : ''}"><span class="ic">${h.icon}</span><span class="tx"><b>${h.name}</b><em>${h.desc}</em></span>${btn}</div>`;
  }).join('');
}

$('shopList').addEventListener('click', e => {
  const b = e.target.closest ? e.target.closest('button[data-k]') : null;
  if (!b) return;
  const m = META.find(x => x.k === b.dataset.k);
  const lv = S.meta[m.k];
  if (lv >= m.max || S.cores < m.cost[lv]) return;
  S.cores -= m.cost[lv]; S.meta[m.k]++; persist(); sfx('level'); renderShop();
});
$('heroList').addEventListener('click', e => {
  const b = e.target.closest ? e.target.closest('button[data-h]') : null;
  if (!b) return;
  const i = +b.dataset.h, h = HEROES[i];
  if (!S.heroes[i]) { if (S.cores < h.cost) return; S.cores -= h.cost; S.heroes[i] = true; }
  S.hero = i; persist(); sfx('click'); renderHeroes();
});
$('cards').addEventListener('click', e => {
  const b = e.target.closest ? e.target.closest('button[data-i]') : null;
  if (b) pickChoice(+b.dataset.i);
});

$('play').addEventListener('click', () => { initAudio(); sfx('click'); startRun(); });
$('again').addEventListener('click', () => { initAudio(); startRun(); });
$('toShop').addEventListener('click', () => { sfx('click'); showScreen('shop'); });
$('toHeroes').addEventListener('click', () => { sfx('click'); showScreen('heroes'); });
$('toMenu').addEventListener('click', () => { G = null; showScreen('menu'); });
$('sndBtn').addEventListener('click', () => { S.sound = !S.sound; persist(); renderMenu(); if (S.sound) { initAudio(); sfx('click'); } });
document.querySelectorAll('[data-back]').forEach(b => b.addEventListener('click', () => showScreen('menu')));

function pauseGame() {
  if (!G || G.state !== 'run') return;
  G.state = 'paused'; stick.a = false; stick.dx = stick.dy = 0;
  showScreen('pause');
}
function resumeGame() {
  if (!G || G.state !== 'paused') return;
  G.state = 'run'; showScreen(null);
}
$('pauseBtn').addEventListener('click', pauseGame);
$('resume').addEventListener('click', resumeGame);
$('quit').addEventListener('click', () => { if (G) { G.state = 'run'; endRun(false); } });

// кнопка «назад» на Android
window.__back = () => {
  if (G && G.state === 'run') { pauseGame(); return 'handled'; }
  if (G && G.state === 'paused') { resumeGame(); return 'handled'; }
  if (G && (G.state === 'levelup' || G.state === 'win' || G.state === 'dead')) return 'handled';
  if (curScreen === 'shop' || curScreen === 'heroes' || curScreen === 'end') { G = null; showScreen('menu'); return 'handled'; }
  return 'exit';
};

// ================= Главный цикл =================
let last = 0;
function frame(now) {
  const dt = Math.min(0.05, Math.max(0, (now - last) / 1000));
  last = now;
  bgT += dt;
  update(dt);
  render();
  requestAnimationFrame(frame);
}

resize();
showScreen('menu');
requestAnimationFrame(t => { last = t; requestAnimationFrame(frame); });

// хуки для отладки
window.__NS = { start: startRun, step: update, pick: pickChoice, get G() { return G; }, render, S };
})();
