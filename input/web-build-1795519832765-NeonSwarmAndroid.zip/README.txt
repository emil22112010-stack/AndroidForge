НЕОНОВЫЙ РОЙ: Android-проект (Gradle) с игрой внутри.

Структура: settings.gradle и build.gradle лежат в корне, приложение в папке app.
Игра (HTML5) лежит в app/src/main/assets, запускается внутри WebView.
Пакет: com.neonswarm.game. minSdk 24, targetSdk 34, AGP 8.5.2, JDK 17.

Сборка:
  gradle assembleDebug     (или assembleRelease, он подписан debug-ключом)
  APK появится в app/build/outputs/apk/

Быстро проверить игру без сборки: откройте app/src/main/assets/index.html в браузере
(на компьютере управление WASD или стрелки).
