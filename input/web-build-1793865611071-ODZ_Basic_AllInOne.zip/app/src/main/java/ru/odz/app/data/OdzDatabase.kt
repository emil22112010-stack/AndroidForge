package ru.odz.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "subjects")
data class SubjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val grade: Int,
    val name: String
)

@Entity(tableName = "books")
data class BookEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val title: String,
    val author: String = "",
    val year: String = ""
)

@Entity(tableName = "exercises")
data class ExerciseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    val number: Int,
    val condition: String = "",
    val solution: String = "",
    val answer: String = ""
)

@Dao
interface OdzDao {
    @Query("SELECT * FROM subjects WHERE grade = :grade ORDER BY name")
    fun subjectsForGrade(grade: Int): Flow<List<SubjectEntity>>

    @Query("SELECT * FROM books WHERE subjectId = :subjectId ORDER BY title")
    fun booksForSubject(subjectId: Long): Flow<List<BookEntity>>

    @Query("SELECT * FROM exercises WHERE bookId = :bookId ORDER BY number")
    fun exercisesForBook(bookId: Long): Flow<List<ExerciseEntity>>

    @Query("SELECT * FROM exercises WHERE id = :exerciseId LIMIT 1")
    fun exerciseById(exerciseId: Long): Flow<ExerciseEntity?>

    @Query("SELECT * FROM exercises WHERE number = :number AND bookId = :bookId LIMIT 1")
    fun exerciseByNumber(bookId: Long, number: Int): Flow<ExerciseEntity?>

    @Query("""SELECT exercises.* FROM exercises
        INNER JOIN books ON exercises.bookId = books.id
        INNER JOIN subjects ON books.subjectId = subjects.id
        WHERE subjects.grade = :grade AND (subjects.name LIKE '%' || :query || '%'
        OR exercises.condition LIKE '%' || :query || '%'
        OR exercises.solution LIKE '%' || :query || '%')
        ORDER BY exercises.number LIMIT 100""")
    fun search(grade: Int, query: String): Flow<List<ExerciseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubject(subject: SubjectEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBook(book: BookEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExercise(exercise: ExerciseEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExercises(exercises: List<ExerciseEntity>)

    @Query("DELETE FROM exercises")
    suspend fun clearExercises()
}

@Database(
    entities = [SubjectEntity::class, BookEntity::class, ExerciseEntity::class],
    version = 2,
    exportSchema = false
)
abstract class OdzDatabase : RoomDatabase() {
    abstract fun dao(): OdzDao

    companion object {
        @Volatile private var INSTANCE: OdzDatabase? = null

        fun get(context: Context): OdzDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    OdzDatabase::class.java,
                    "odz_local.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
    }
}
