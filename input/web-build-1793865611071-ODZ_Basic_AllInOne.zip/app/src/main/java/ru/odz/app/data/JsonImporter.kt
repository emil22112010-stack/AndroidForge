package ru.odz.app.data

import org.json.JSONArray
import org.json.JSONObject

/**
 * Imports a JSON catalog into Room.
 * JSON example:
 * {
 *   "grade": 7,
 *   "subject": "Алгебра",
 *   "book": {"title":"Мой учебник","author":"Автор","year":"2026"},
 *   "exercises":[{"number":1,"condition":"...","solution":"...","answer":"..."}]
 * }
 */
suspend fun OdzDatabase.importJson(jsonText: String) {
    val root = JSONObject(jsonText)
    val grade = root.getInt("grade")
    val subjectName = root.getString("subject")
    val bookJson = root.getJSONObject("book")
    val exercisesJson = root.getJSONArray("exercises")

    withTransaction {
        val dao = dao()
        val subjectId = dao.insertSubject(SubjectEntity(grade = grade, name = subjectName))
        val bookId = dao.insertBook(BookEntity(
            subjectId = subjectId,
            title = bookJson.getString("title"),
            author = bookJson.optString("author", ""),
            year = bookJson.optString("year", "")
        ))
        val rows = mutableListOf<ExerciseEntity>()
        for (i in 0 until exercisesJson.length()) {
            val e = exercisesJson.getJSONObject(i)
            rows += ExerciseEntity(
                bookId = bookId,
                number = e.getInt("number"),
                condition = e.optString("condition", ""),
                solution = e.optString("solution", ""),
                answer = e.optString("answer", "")
            )
        }
        dao.insertExercises(rows)
    }
}
