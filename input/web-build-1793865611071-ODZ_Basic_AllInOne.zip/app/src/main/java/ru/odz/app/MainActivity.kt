package ru.odz.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewModelScope
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import ru.odz.app.data.*

private val Bg = Color(0xFF101114)
private val Panel = Color(0xFF1C1B21)
private val Accent = Color(0xFF8B9EFF)
private val Muted = Color(0xFF9B99A5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = OdzDatabase.get(this)
        lifecycleScope.launch {
            db.seedDemoIfEmpty()
            // Import sample JSON once, if demo book wasn't created by seed.
            val current = db.dao().subjectsForGrade(7).first()
            if (current.isEmpty()) {
                assets.open("demo_catalog.json").bufferedReader().use { db.importJson(it.readText()) }
            }
        }
        setContent { ODZApp(db) }
    }
}

class OdzViewModel(private val dao: OdzDao, private val db: OdzDatabase) : ViewModel() {
    fun subjects(grade: Int) = dao.subjectsForGrade(grade)
    fun books(subjectId: Long) = dao.booksForSubject(subjectId)
    fun exercises(bookId: Long) = dao.exercisesForBook(bookId)
    fun exercise(id: Long) = dao.exerciseById(id)
    fun favorites() = dao.favorites()
    fun search(q: String) = dao.searchAll(q)
    fun toggleFavorite(item: ExerciseEntity) = viewModelScope.launch { dao.setFavorite(item.id, !item.favorite) }
}
class OdzVmFactory(private val dao: OdzDao, private val db: OdzDatabase) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = OdzViewModel(dao, db) as T
}

@Composable
fun ODZApp(db: OdzDatabase) {
    val vm: OdzViewModel = viewModel(factory = OdzVmFactory(db.dao(), db))
    var grade by remember { mutableStateOf<Int?>(null) }
    var subject by remember { mutableStateOf<SubjectEntity?>(null) }
    var book by remember { mutableStateOf<BookEntity?>(null) }
    var exerciseId by remember { mutableStateOf<Long?>(null) }
    var screen by remember { mutableStateOf("home") }
    var query by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val jsonPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                message = "Импортируем файл…"
                try {
                    val json = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        ?: error("Не удалось прочитать файл")
                    db.importJson(json)
                    message = "Каталог успешно добавлен!"
                } catch (e: Exception) {
                    message = "Ошибка импорта: ${e.message ?: "проверь JSON"}"
                }
            }
        }
    }

    val subjects by (grade?.let(vm::subjects) ?: flowOf(emptyList())).collectAsStateWithLifecycle(emptyList())
    val books by (subject?.let { vm.books(it.id) } ?: flowOf(emptyList())).collectAsStateWithLifecycle(emptyList())
    val exercises by (book?.let { vm.exercises(it.id) } ?: flowOf(emptyList())).collectAsStateWithLifecycle(emptyList())
    val exercise by (exerciseId?.let(vm::exercise) ?: flowOf(null)).collectAsStateWithLifecycle(null)
    val favorites by vm.favorites().collectAsStateWithLifecycle(emptyList())
    val searchResults by vm.search(query.trim()).collectAsStateWithLifecycle(emptyList())

    MaterialTheme(colorScheme = darkColorScheme(background=Bg, surface=Panel, primary=Accent, onBackground=Color.White, onSurface=Color.White)) {
        Surface(Modifier.fillMaxSize(), color=Bg) {
            Column(Modifier.fillMaxSize().padding(horizontal=18.dp)) {
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment=Alignment.CenterVertically) {
                    if (screen !in listOf("home","search","favorites")) IconButton(onClick={
                        when(screen) {
                            "exercise" -> screen="list"
                            "list" -> screen=if(book!=null) "books" else "subjects"
                            "books" -> { subject=null; screen="subjects" }
                            "import" -> {
                        Heading("Импорт каталога","Добавляй свои решения без интернета")
                        Detail("Как подготовить файл","Выбери JSON-файл с каталогом. Один файл = один предмет и один учебник. После импорта задания появятся в выбранном классе.")
                        Spacer(Modifier.height(14.dp))
                        Button(onClick={jsonPicker.launch(arrayOf("application/json","text/*"))},modifier=Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.FileOpen,null);Spacer(Modifier.width(8.dp));Text("Выбрать JSON-файл")
                        }
                        Spacer(Modifier.height(12.dp))
                        message?.let { Detail("Статус",it) }
                        Spacer(Modifier.height(12.dp))
                        Detail("Формат JSON","""{
  "grade": 7,
  "subject": "Алгебра",
  "book": {"title": "Учебник", "author": "Автор", "year": "2026"},
  "exercises": [
    {"number": 1, "condition": "Условие", "solution": "Решение", "answer": "Ответ"}
  ]
}""")
                    }
                    "subjects" -> { grade=null; screen="home" }
                            else -> screen="home"
                        }
                    }) { Icon(Icons.Default.ArrowBack,"Назад",tint=Color.White) }
                    Column(Modifier.weight(1f)) {
                        Text("ОДЗ",fontSize=27.sp,fontWeight=FontWeight.Black)
                        Text("Домашние задания • офлайн",color=Muted,fontSize=12.sp)
                    }
                    IconButton(onClick={screen="search";query=""}) { Icon(Icons.Default.Search,"Поиск",tint=Accent) }
                    IconButton(onClick={screen="favorites"}) { Icon(Icons.Default.Bookmark,"Избранное",tint=Accent) }
                }
                Spacer(Modifier.height(18.dp))
                when(screen) {
                    "home" -> {
                        Heading("Выбери свой класс","Решения прямо на устройстве")
                        LazyVerticalGrid(columns=GridCells.Fixed(3),horizontalArrangement=Arrangement.spacedBy(10.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                            items((5..11).toList()) { g -> GradeCard(g){grade=g;screen="subjects"} }
                        }
                        Spacer(Modifier.height(18.dp))
                        ActionCard("Поиск по заданиям","Найти решение по ключевым словам",Icons.Default.Search){screen="search"}
                        ActionCard("Избранное","Твои сохранённые упражнения",Icons.Default.Bookmark){screen="favorites"}
                        ActionCard("Импорт каталога","Добавить учебник и задания из JSON",Icons.Default.FileDownload){screen="import";message=null}
                        Spacer(Modifier.weight(1f))
                        Text("ОДЗ • базовая версия",color=Muted,fontSize=12.sp,modifier=Modifier.align(Alignment.CenterHorizontally).padding(bottom=10.dp))
                    }
                    "import" -> {
                        Heading("Импорт каталога","Добавляй свои решения без интернета")
                        Detail("Как подготовить файл","Выбери JSON-файл с каталогом. Один файл = один предмет и один учебник. После импорта задания появятся в выбранном классе.")
                        Spacer(Modifier.height(14.dp))
                        Button(onClick={jsonPicker.launch(arrayOf("application/json","text/*"))},modifier=Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.FileOpen,null);Spacer(Modifier.width(8.dp));Text("Выбрать JSON-файл")
                        }
                        Spacer(Modifier.height(12.dp))
                        message?.let { Detail("Статус",it) }
                        Spacer(Modifier.height(12.dp))
                        Detail("Формат JSON","""{
  "grade": 7,
  "subject": "Алгебра",
  "book": {"title": "Учебник", "author": "Автор", "year": "2026"},
  "exercises": [
    {"number": 1, "condition": "Условие", "solution": "Решение", "answer": "Ответ"}
  ]
}""")
                    }
                    "subjects" -> {
                        Heading("$grade класс","Предметы")
                        if(subjects.isEmpty()) Empty("Предметы ещё не добавлены")
                        else LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)){items(subjects,key={it.id}){s->ActionCard(s.name,"Учебники и задания",Icons.Default.Book){subject=s;screen="books"}}}
                    }
                    "books" -> {
                        Heading(subject?.name ?: "Учебники","Выбери сборник")
                        if(books.isEmpty()) Empty("Учебники пока не добавлены")
                        else LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)){items(books,key={it.id}){b->ActionCard(b.title,"${b.author} ${b.year}".trim(),Icons.Default.MenuBook){book=b;screen="list"}}}
                    }
                    "list" -> {
                        Heading(book?.title ?: "Упражнения","${exercises.size} заданий в базе")
                        if(exercises.isEmpty()) Empty("В учебнике пока нет упражнений")
                        else LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)){items(exercises,key={it.id}){e->ActionCard("Упражнение №${e.number}",e.condition.ifBlank{"Открыть решение"},Icons.Default.Calculate){exerciseId=e.id;screen="exercise"}}}
                    }
                    "exercise" -> {
                        if(exercise==null) Empty("Задание не найдено")
                        else {
                            Heading("Упражнение №${exercise!!.number}","")
                            Detail("Условие",exercise!!.condition)
                            Spacer(Modifier.height(10.dp));Detail("Решение",exercise!!.solution)
                            Spacer(Modifier.height(10.dp));Detail("Ответ",exercise!!.answer)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick={vm.toggleFavorite(exercise!!)},modifier=Modifier.fillMaxWidth()) {
                                Icon(if(exercise!!.favorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,null)
                                Spacer(Modifier.width(8.dp));Text(if(exercise!!.favorite)"Убрать из избранного" else "В избранное")
                            }
                        }
                    }
                    "search" -> {
                        Heading("Поиск","По условию, решению или ответу")
                        SearchField(query,{query=it})
                        Spacer(Modifier.height(12.dp))
                        if(query.isBlank()) Empty("Введи слово или часть условия")
                        else if(searchResults.isEmpty()) Empty("Ничего не найдено")
                        else LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)){items(searchResults,key={it.id}){e->ActionCard("Упражнение №${e.number}",e.condition.ifBlank{"Совпадение в решении"},Icons.Default.Search){exerciseId=e.id;screen="exercise"}}}
                    }
                    "favorites" -> {
                        Heading("Избранное","Сохранённые задания")
                        if(favorites.isEmpty()) Empty("Здесь пока пусто. Открой упражнение и нажми «В избранное».")
                        else LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)){items(favorites,key={it.id}){e->ActionCard("Упражнение №${e.number}",e.condition.ifBlank{"Сохранено"},Icons.Default.Bookmark){exerciseId=e.id;screen="exercise"}}}
                    }
                }
            }
        }
    }
}

@Composable fun Heading(title:String,subtitle:String){Text(title,fontSize=22.sp,fontWeight=FontWeight.Bold);if(subtitle.isNotBlank()){Spacer(Modifier.height(5.dp));Text(subtitle,color=Muted,fontSize=13.sp)};Spacer(Modifier.height(16.dp))}
@Composable fun GradeCard(n:Int,onClick:()->Unit){Column(Modifier.fillMaxWidth().height(88.dp).background(Panel,RoundedCornerShape(16.dp)).clickable(onClick=onClick),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text("$n",fontSize=27.sp,fontWeight=FontWeight.Bold,color=Accent);Text("класс",fontSize=12.sp,color=Muted)}}
@Composable fun ActionCard(title:String,subtitle:String,icon:androidx.compose.ui.graphics.vector.ImageVector,onClick:()->Unit){Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(15.dp)).clickable(onClick=onClick).padding(15.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=Accent,modifier=Modifier.size(24.dp));Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.SemiBold,fontSize=15.sp);if(subtitle.isNotBlank())Text(subtitle,color=Muted,fontSize=12.sp,maxLines=2)};Icon(Icons.Default.ChevronRight,null,tint=Muted)}}
@Composable fun Empty(text:String){Box(Modifier.fillMaxWidth().padding(top=28.dp),contentAlignment=Alignment.Center){Text(text,color=Muted)}}
@Composable fun Detail(title:String,text:String){Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(16.dp)){Column(Modifier.fillMaxWidth().padding(16.dp)){Text(title,color=Accent,fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));Text(text.ifBlank{"Пока не добавлено."},lineHeight=22.sp)}}}
@Composable fun SearchField(value:String,onChange:(String)->Unit){Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(14.dp)).padding(horizontal=14.dp,vertical=12.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Search,null,tint=Muted);Spacer(Modifier.width(10.dp));BasicTextField(value,onChange,modifier=Modifier.weight(1f),singleLine=true,textStyle=MaterialTheme.typography.bodyLarge.copy(color=Color.White),decorationBox={inner->if(value.isEmpty())Text("Например: уравнение",color=Muted);inner()});if(value.isNotEmpty())IconButton(onClick={onChange("")}){Icon(Icons.Default.Close,null,tint=Muted)}}}
