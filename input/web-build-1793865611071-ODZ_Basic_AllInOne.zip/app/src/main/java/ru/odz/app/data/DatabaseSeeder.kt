package ru.odz.app.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.first

/** Demo content for testing local database. */
suspend fun OdzDatabase.seedDemoIfEmpty() {
    withTransaction {
        val dao = dao()
        if (dao.subjectsForGrade(7).first().isNotEmpty()) return@withTransaction
        val subjectId = dao.insertSubject(SubjectEntity(grade = 7, name = "Алгебра"))
        val bookId = dao.insertBook(BookEntity(subjectId = subjectId,
            title = "Демонстрационный учебник", author = "ОДЗ", year = "2026"))
        dao.insertExercises(listOf(
            ExerciseEntity(bookId = bookId, number = 1,
                condition = "Вычислите: 12 + 8",
                solution = "Складываем числа: 12 + 8 = 20.", answer = "20"),
            ExerciseEntity(bookId = bookId, number = 2,
                condition = "Вычислите: 30 − 7",
                solution = "Вычитаем 7 из 30: 30 − 7 = 23.", answer = "23")
        ))
    }
}
