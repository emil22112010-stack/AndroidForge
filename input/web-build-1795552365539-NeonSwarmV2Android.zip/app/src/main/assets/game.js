(() => {
'use strict';

const TAU = Math.PI * 2;
const $ = id => document.getElementById(id);
const cv = $('c');
const ctx = cv.getContext('2d');
let W = 360, H = 640, dpr = 1, Z = 1, topPad = 14;
let G = null;
let bgT = 0;
const easeBack = x => { x = Math.max(0, Math.min(1, x)); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); };

// ================= Данные =================
const WEAPONS = {
  pulse:  { name: 'Импульс',  icon: '⚡', desc: 'Стреляет по ближайшим врагам. С 4 уровня пробивает насквозь.' },
  orbit:  { name: 'Клинки',   icon: '🌀', desc: 'Вращаются вокруг вас и рубят всех, кто подошёл.' },
  nova:   { name: 'Нова',     icon: '💥', desc: 'Взрыв вокруг вас отбрасывает толпу.' },
  chain:  { name: 'Молния',   icon: '🔗', desc: 'Разряд перескакивает с врага на врага.' },
  laser:  { name: 'Луч',      icon: '📏', desc: 'Прошивает всех на линии. С 3 уровня бьёт несколькими лучами.' },
  drone:  { name: 'Дроны',    icon: '🛸', desc: 'Летающие помощники сами стреляют по врагам.' },
  mine:   { name: 'Мины',     icon: '💣', desc: 'Оставляют мины, взрывающиеся рядом с врагами.' },
  boom:   { name: 'Диск',     icon: '🥏', desc: 'Летит вперёд, возвращается и рубит всех на пути.' },
  meteor: { name: 'Метеоры',  icon: '☄️', desc: 'С неба падают метеориты по отмеченным целям.' },
};
const PASSIVES = {
  dmg:   { name: 'Мощь',       icon: '🔥', desc: '+15% к урону.' },
  rate:  { name: 'Темп',       icon: '⏱️', desc: '+12% к скорострельности.' },
  spd:   { name: 'Рывок',      icon: '👟', desc: '+8% к скорости движения.' },
  hp:    { name: 'Корпус',     icon: '❤️', desc: '+20 к максимуму HP и лечение.' },
  mag:   { name: 'Магнит',     icon: '🧲', desc: '+30% к радиусу подбора.' },
  armor: { name: 'Щит',        icon: '🛡️', desc: '−1 к получаемому урону.' },
  regen: { name: 'Ремонт',     icon: '💚', desc: '+0,4 HP в секунду.' },
  xp:    { name: 'Опыт',       icon: '⭐', desc: '+12% к получаемому опыту.' },
  crit:  { name: 'Критудар',   icon: '🎯', desc: '+7% шанс крита (двойной урон).' },
  area:  { name: 'Размах',     icon: '🔆', desc: '+10% к размеру и радиусу атак.' },
  vamp:  { name: 'Вампиризм',  icon: '🩸', desc: '+0,1 HP за каждое убийство.' },
  slow:  { name: 'Холод',      icon: '❄️', desc: 'Враги медленнее на 5%.' },
};
const HEROES = [
  { name: 'Искра',     icon: '⚡', start: 'pulse',  cost: 0,    desc: 'Универсал. Стартует с Импульсом.',            spd: 1,    dmg: 1,    hp: 0,  armor: 0 },
  { name: 'Орбита',    icon: '🌀', start: 'orbit',  cost: 150,  desc: 'Быстрее на 10%. Стартует с Клинками.',        spd: 1.1,  dmg: 1,    hp: 0,  armor: 0 },
  { name: 'Гром',      icon: '🔗', start: 'chain',  cost: 300,  desc: '+25 HP. Стартует с Молнией.',                  spd: 1,    dmg: 1,    hp: 25, armor: 0 },
  { name: 'Лучик',     icon: '📏', start: 'laser',  cost: 500,  desc: '+15% урона. Стартует с Лучом.',                spd: 1,    dmg: 1.15, hp: 0,  armor: 0 },
  { name: 'Рой',       icon: '🛸', start: 'drone',  cost: 700,  desc: '+15 HP. Стартует с Дронами.',                  spd: 1,    dmg: 1,    hp: 15, armor: 0 },
  { name: 'Комета',    icon: '☄️', start: 'meteor', cost: 900,  desc: '+10% урона. Стартует с Метеорами.',            spd: 1,    dmg: 1.1,  hp: 0,  armor: 0 },
  { name: 'Сапёр',     icon: '💣', start: 'mine',   cost: 1100, desc: '−1 урон от ударов. Стартует с Минами.',        spd: 1,    dmg: 1,    hp: 0,  armor: 1 },
  { name: 'Метатель',  icon: '🥏', start: 'boom',   cost: 1300, desc: 'Быстрее на 6%. Стартует с Диском.',            spd: 1.06, dmg: 1,    hp: 10, armor: 0 },
];
const META = [
  { k: 'hp',   name: 'Прочность',    icon: '❤️', desc: '+15 HP за уровень',          max: 5, cost: [20, 45, 80, 130, 200] },
  { k: 'dmg',  name: 'Сила',         icon: '🔥', desc: '+8% урона за уровень',       max: 5, cost: [30, 60, 100, 160, 250] },
  { k: 'spd',  name: 'Скорость',     icon: '👟', desc: '+4% скорости за уровень',    max: 5, cost: [20, 45, 75, 120, 180] },
  { k: 'xp',   name: 'Обучение',     icon: '⭐', desc: '+8% опыта за уровень',       max: 5, cost: [30, 60, 100, 160, 250] },
  { k: 'mag',  name: 'Магнит',       icon: '🧲', desc: '+15% радиуса подбора',       max: 5, cost: [18, 35, 65, 100, 150] },
  { k: 'rr',   name: 'Обновление',   icon: '🎲', desc: '+1 обновление выбора за уровень', max: 3, cost: [30, 70, 130] },
  { k: 'gold', name: 'Трофеи',       icon: '◈',  desc: '+10% ядер за забег',         max: 5, cost: [40, 80, 140, 220, 340] },
  { k: 'rev',  name: 'Второй шанс',  icon: '✨', desc: 'Воскрешение с 50% HP',       max: 2, cost: [220, 500] },
];
const ET = {
  grunt:    { hp: 12, sp: 52,  r: 10, dmg: 8,  xp: 1, col: '#ff4d6d', sides: 0 },
  runner:   { hp: 7,  sp: 100, r: 8,  dmg: 6,  xp: 1, col: '#ffb703', sides: 3 },
  tank:     { hp: 70, sp: 36,  r: 17, dmg: 15, xp: 5, col: '#9b5de5', sides: 6 },
  shooter:  { hp: 22, sp: 46,  r: 10, dmg: 8,  xp: 2, col: '#00f5d4', sides: 4 },
  splitter: { hp: 34, sp: 48,  r: 13, dmg: 9,  xp: 2, col: '#f15bb5', sides: 8 },
  mini:     { hp: 7,  sp: 80,  r: 6,  dmg: 5,  xp: 1, col: '#f15bb5', sides: 0 },
};

// ---- 100 боссов, собираются из названий и наборов атак ----
const B_PRE  = ['Тёмный', 'Ледяной', 'Пылающий', 'Ядовитый', 'Призрачный', 'Стальной', 'Громовой', 'Кристальный', 'Древний', 'Багровый'];
const B_NOUN = ['Страж', 'Жнец', 'Колосс', 'Охотник', 'Паук', 'Змей', 'Рой', 'Шар', 'Глаз', 'Король'];
const P_ALL  = ['ring', 'spiral', 'aimed', 'charge', 'rain', 'summon', 'orbs', 'blink', 'sweep'];
const P_NAME = { ring: 'кольцевые залпы', spiral: 'спираль', aimed: 'прицельные залпы', charge: 'рывки', rain: 'ливень', summon: 'призыв', orbs: 'щит из сфер', blink: 'телепорт', sweep: 'вращающийся луч' };
function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const bossCache = {};
function bossDef(idx) {
  if (bossCache[idx]) return bossCache[idx];
  const v = idx % 100, cyc = Math.floor(idx / 100);
  const r = rng(v * 7919 + 13);
  const pool = P_ALL.slice();
  for (let i = pool.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [pool[i], pool[j]] = [pool[j], pool[i]]; }
  const np = v < 3 ? 1 : v < 12 ? 2 : v < 40 ? 3 : 4;
  const hue = (v * 47) % 360;
  const d = {
    idx, name: B_PRE[v % 10] + ' ' + B_NOUN[Math.floor(v / 10) % 10] + (cyc ? ' ' + (cyc + 1) + '.0' : ''),
    hue, col: `hsl(${hue},90%,62%)`, sides: 5 + (v % 6) + (v % 7 === 0 ? 3 : 0),
    pats: pool.slice(0, np), tier: Math.min(12, Math.floor(idx / 6)),
    hp: 1200 + 800 * idx + 14 * idx * idx,
  };
  bossCache[idx] = d;
  return d;
}

// ================= Сохранение =================
const SKEY = 'neonswarm_v1';
const defSave = () => ({ cores: 0, meta: { hp: 0, dmg: 0, spd: 0, xp: 0, mag: 0, rev: 0, rr: 0, gold: 0 }, heroes: HEROES.map((h, i) => i === 0), hero: 0, bestT: 0, bestK: 0, bestB: 0, beast: {}, sound: true });
let S = (() => {
  try {
    const d = JSON.parse(localStorage.getItem(SKEY));
    if (d && d.meta) {
      const base = defSave();
      const m = Object.assign(base, d, { meta: Object.assign(base.meta, d.meta), beast: d.beast || {} });
      if (!Array.isArray(m.heroes)) m.heroes = base.heroes;
      while (m.heroes.length < HEROES.length) m.heroes.push(false);
      return m;
    }
  } catch (e) {}
  return defSave();
})();
function persist() { try { localStorage.setItem(SKEY, JSON.stringify(S)); } catch (e) {} }

// ================= Звук =================
let actx = null;
function initAudio() {
  try {
    if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
    else if (actx.state === 'suspended') actx.resume();
  } catch (e) {}
}
function tone(f, d, type, v, slide, delay) {
  if (!S.sound || !actx) return;
  try {
    const t0 = actx.currentTime + (delay || 0);
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(f, t0);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, f * slide), t0 + d);
    g.gain.setValueAtTime(v || 0.08, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    o.connect(g); g.connect(actx.destination);
    o.start(t0); o.stop(t0 + d + 0.02);
  } catch (e) {}
}
const sfxLast = {};
function sfx(name, arg) {
  const now = performance.now();
  const gap = { shoot: 90, hit: 60, gem: 40, zap: 120, boom: 150 }[name] || 0;
  if (gap && sfxLast[name] && now - sfxLast[name] < gap) return;
  sfxLast[name] = now;
  switch (name) {
    case 'shoot': tone(780, 0.05, 'square', 0.018, 0.5); break;
    case 'hit':   tone(180, 0.04, 'square', 0.02, 0.6); break;
    case 'gem':   tone(620 + Math.min(arg || 0, 12) * 45, 0.07, 'sine', 0.05); break;
    case 'zap':   tone(300, 0.1, 'sawtooth', 0.03, 2.2); break;
    case 'nova':  tone(140, 0.28, 'sine', 0.12, 0.35); break;
    case 'boom':  tone(110, 0.2, 'sine', 0.09, 0.4); break;
    case 'hurt':  tone(120, 0.18, 'sawtooth', 0.09, 0.5); break;
    case 'level': [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.16, 'triangle', 0.07, 0, i * 0.07)); break;
    case 'boss':  tone(70, 0.7, 'sawtooth', 0.12, 0.6); tone(105, 0.7, 'square', 0.05, 0.6, 0.15); break;
    case 'bosskill': [392, 523, 659, 784, 1047].forEach((f, i) => tone(f, 0.22, 'triangle', 0.08, 0, i * 0.08)); break;
    case 'die':   [330, 262, 196, 130].forEach((f, i) => tone(f, 0.3, 'sawtooth', 0.08, 0.8, i * 0.14)); break;
    case 'click': tone(500, 0.04, 'sine', 0.05); break;
    case 'reroll': tone(400, 0.05, 'triangle', 0.06); tone(600, 0.06, 'triangle', 0.06, 0, 0.05); break;
  }
}
function buzz(ms) { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) {} }

let musicTimer = null, mStep = 0;
const ROOTS = [55, 55, 43.65, 49];
const PENTA = [0, 3, 5, 7, 10, 12, 15];
function musicTick() {
  if (!S.sound || !actx || !G || G.state !== 'run') return;
  const bar = Math.floor(mStep / 16) % 4, root = ROOTS[bar], s = mStep % 16;
  if (s % 4 === 0) tone(root, 0.3, 'sawtooth', 0.045);
  if (s === 0 || s === 8) tone(90, 0.12, 'sine', 0.1, 0.35);
  const chance = 0.35 + Math.min(0.5, G.t / 900) + (G.boss ? 0.15 : 0);
  if (s % 2 === 1 && Math.random() < chance) {
    const n = PENTA[Math.floor(Math.random() * PENTA.length)];
    tone(root * 4 * Math.pow(2, n / 12), 0.14, 'triangle', 0.02);
  }
  if (G.boss && s % 4 === 2) tone(root * 2, 0.1, 'square', 0.02);
  mStep++;
}
function musicStart() { if (!musicTimer) musicTimer = setInterval(musicTick, 140); }
function musicStop() { if (musicTimer) { clearInterval(musicTimer); musicTimer = null; } }

// ================= Экран и ввод =================
function resize() {
  dpr = Math.min(window.devicePixelRatio || 1, 2.5);
  W = window.innerWidth; H = window.innerHeight;
  cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
  cv.style.width = W + 'px'; cv.style.height = H + 'px';
  Z = Math.max(0.6, Math.min(1.4, Math.min(W, H) / 520));
  try { topPad = Math.max(12, parseFloat(getComputedStyle($('inset')).paddingTop) || 0) + 4; } catch (e) { topPad = 16; }
}
const viewW = () => W / Z;
const viewH = () => H / Z;

const stick = { a: false, id: null, ox: 0, oy: 0, x: 0, y: 0, dx: 0, dy: 0 };
const keys = new Set();

cv.addEventListener('pointerdown', e => {
  initAudio();
  if (!G || G.state !== 'run' || stick.a) return;
  stick.a = true; stick.id = e.pointerId;
  stick.ox = stick.x = e.clientX; stick.oy = stick.y = e.clientY;
  stick.dx = stick.dy = 0;
  try { cv.setPointerCapture(e.pointerId); } catch (err) {}
  if (e.preventDefault) e.preventDefault();
});
cv.addEventListener('pointermove', e => {
  if (!stick.a || e.pointerId !== stick.id) return;
  stick.x = e.clientX; stick.y = e.clientY;
  let dx = stick.x - stick.ox, dy = stick.y - stick.oy;
  const len = Math.hypot(dx, dy), R = 56;
  if (len > R) { stick.ox += dx / len * (len - R); stick.oy += dy / len * (len - R); dx = stick.x - stick.ox; dy = stick.y - stick.oy; }
  const l = Math.hypot(dx, dy);
  if (l < 6) { stick.dx = stick.dy = 0; }
  else { const k = Math.min(1, l / R); stick.dx = dx / l * k; stick.dy = dy / l * k; }
  if (e.preventDefault) e.preventDefault();
});
function stickEnd(e) { if (e.pointerId !== stick.id) return; stick.a = false; stick.dx = stick.dy = 0; }
cv.addEventListener('pointerup', stickEnd);
cv.addEventListener('pointercancel', stickEnd);

window.addEventListener('keydown', e => {
  const k = (e.key || '').toLowerCase();
  if (k === 'escape') { window.__back(); return; }
  keys.add(k);
});
window.addEventListener('keyup', e => keys.delete((e.key || '').toLowerCase()));
document.addEventListener('pointerdown', initAudio);
document.addEventListener('contextmenu', e => e.preventDefault());
window.addEventListener('resize', resize);
document.addEventListener('visibilitychange', () => { if (document.hidden) pauseGame(); });

// ================= Характеристики =================
const area   = () => 1 + 0.1 * G.ps.area;
const dmgMul = () => (1 + 0.15 * G.ps.dmg + G.ovDmg) * (1 + 0.08 * S.meta.dmg) * HEROES[S.hero].dmg;
const spdMul = () => (1 + 0.08 * G.ps.spd) * (1 + 0.04 * S.meta.spd) * HEROES[S.hero].spd;
const magR   = () => 70 * (1 + 0.3 * G.ps.mag) * (1 + 0.15 * S.meta.mag);
const cdMul  = () => 1 / (1 + 0.12 * G.ps.rate + G.ovRate);
const xpMul  = () => (1 + 0.12 * G.ps.xp) * (1 + 0.08 * S.meta.xp);
const xpNeed = l => Math.floor(4 + l * 2.4 + l * l * 0.3);
const hpMul  = t => 1 + (t / 60) * 0.28 + Math.pow(t / 60, 1.5) * 0.1;

// ================= Звёзды и фон =================
const STAR_LAYERS = [0.15, 0.3, 0.55].map((f, li) => {
  const r = rng(1000 + li), arr = [];
  for (let i = 0; i < 46; i++) arr.push({ x: r() * 512, y: r() * 512, s: 0.8 + r() * (1 + li * 0.6), ph: r() * TAU });
  return { f, arr };
});
function drawStars(camx, camy, t) {
  const tile = 512;
  for (const L of STAR_LAYERS) {
    const ox = -(((camx * L.f) % tile) + tile) % tile, oy = -(((camy * L.f) % tile) + tile) % tile;
    for (let tx = ox; tx < W; tx += tile) for (let ty = oy; ty < H; ty += tile) {
      for (const s of L.arr) {
        const x = tx + s.x, y = ty + s.y;
        if (x < -2 || x > W || y < -2 || y > H) continue;
        ctx.globalAlpha = 0.25 + 0.45 * (0.5 + 0.5 * Math.sin(t * 2 + s.ph));
        ctx.fillStyle = L.f > 0.5 ? '#bfe9ff' : '#7f8fd6';
        ctx.fillRect(x, y, s.s, s.s);
      }
    }
  }
  ctx.globalAlpha = 1;
}
const menuShapes = [];
{
  const r = rng(77);
  for (let i = 0; i < 16; i++) menuShapes.push({ x: r(), y: r(), vx: (r() - 0.5) * 0.02, vy: (r() - 0.5) * 0.02, r: 10 + r() * 22, sides: [0, 3, 4, 6, 8][Math.floor(r() * 5)], rot: r() * TAU, vr: (r() - 0.5) * 0.8, col: ['#ff4d6d', '#ffb703', '#9b5de5', '#00f5d4', '#f15bb5', '#5ee7ff'][i % 6] });
}

// ================= Старт забега =================
function startRun() {
  const h = HEROES[S.hero], m = S.meta;
  const maxHp = 100 + m.hp * 15 + h.hp;
  G = {
    t: 0, state: 'run',
    p: { x: 0, y: 0, r: 11, hp: maxHp, maxHp, inv: 0, face: -Math.PI / 2, revives: m.rev, flash: 0 },
    w: { pulse: 0, orbit: 0, nova: 0, chain: 0, laser: 0, drone: 0, mine: 0, boom: 0, meteor: 0 },
    cd: { pulse: 0, nova: 1, chain: 0.5, laser: 1, mine: 1, boom: 0.5, meteor: 1.5 },
    ps: { dmg: 0, rate: 0, spd: 0, hp: 0, mag: 0, armor: 0, regen: 0, xp: 0, crit: 0, area: 0, vamp: 0, slow: 0 },
    ovDmg: 0, ovRate: 0, vampAcc: 0, rerolls: 2 + m.rr,
    en: [], bu: [], eb: [], gm: [], pt: [], tx: [], fx: [], mn: [], bm: [], mt: [], drCd: [],
    xp: 0, lvl: 1, xpNext: xpNeed(1), pending: 0, choices: [], levelTitle: 'Новый уровень',
    kills: 0, bossKills: 0, spawned: 0, spawnAcc: 0, boss: null, shake: 0, orbAng: 0, drAng: 0, nid: 1,
    streak: 0, gemT: -9, banner: null, bonus: 0, endT: 0,
    hurtT: 0, dark: 0, hpShow: maxHp, bossBar: 0,
  };
  G.w[h.start] = 1;
  stick.a = false; stick.dx = stick.dy = 0;
  showScreen(null);
  $('pauseBtn').classList.remove('hidden');
  say('Выживи', '#5ee7ff');
  musicStart();
}

function say(text, col, life) { G.banner = { text, col: col || '#fff', life: life || 2.2, max: life || 2.2 }; }

// ================= Спавн =================
function pickType(t) {
  const pool = [['grunt', 10]];
  if (t > 25)  pool.push(['runner', 4 + Math.min(6, t / 40)]);
  if (t > 80)  pool.push(['shooter', 2 + Math.min(5, t / 90)]);
  if (t > 110) pool.push(['tank', 2 + Math.min(5, t / 100)]);
  if (t > 170) pool.push(['splitter', 2 + Math.min(4, t / 120)]);
  let sum = 0; for (const a of pool) sum += a[1];
  let r = Math.random() * sum;
  for (const a of pool) { r -= a[1]; if (r <= 0) return a[0]; }
  return 'grunt';
}

function ringPos() {
  const a = Math.random() * TAU, d = Math.max(viewW(), viewH()) / 2 + 40;
  return [G.p.x + Math.cos(a) * d, G.p.y + Math.sin(a) * d];
}

function spawnEnemy(type, x, y, forceElite) {
  const g = G, d = ET[type], t = g.t;
  if (x === undefined) { const q = ringPos(); x = q[0]; y = q[1]; }
  const elite = !!forceElite || (t > 150 && type !== 'mini' && Math.random() < 0.035);
  const hm = hpMul(t) * (elite ? 5 : 1);
  g.en.push({
    id: g.nid++, type, x, y, kx: 0, ky: 0, born: 0,
    r: d.r * (elite ? 1.35 : 1), hp: d.hp * hm, maxHp: d.hp * hm,
    sp: d.sp * (elite ? 0.9 : 1) * (0.9 + Math.random() * 0.2),
    dmg: d.dmg * (1 + Math.min(2.5, t / 720 * 0.8)), xp: d.xp * (elite ? 4 : 1),
    col: d.col, sides: d.sides, elite, flash: 0, shoot: 1 + Math.random() * 2,
    ph: Math.random() * TAU, oh: -9, boss: false, dead: false,
  });
}

function fxRing(x, y, r, col, life) { if (G.fx.length < 60) G.fx.push({ k: 'ring', x, y, r1: r, life: life || 0.3, max: life || 0.3, col }); }

function spawnBoss(idx) {
  const g = G, d = bossDef(idx), q = ringPos();
  const b = {
    id: g.nid++, type: 'boss', x: q[0], y: q[1], kx: 0, ky: 0, born: 0,
    r: 28 + Math.min(22, d.tier * 2.2), hp: d.hp, maxHp: d.hp, sp: 40 + Math.min(34, d.tier * 3),
    dmg: 18 + idx * 0.5, xp: 0, col: d.col, sides: d.sides, elite: false, boss: true, idx, def: d, name: d.name,
    flash: 0, ph: 0, oh: -9, dead: false, pats: d.pats, s: {}, cstate: 0, cdx: 0, cdy: 0, cTimer: 0, chargeT: 5,
    sa: 0, sw: null, bl: null, orbN: 3 + Math.min(5, d.tier >> 1), spiralOn: 0,
  };
  for (const p of d.pats) b.s[p] = 1.5 + Math.random() * 1.5;
  g.en.push(b); g.boss = b; g.spawned++; g.bossBar = 0; g.dark = 1;
  say('Босс №' + (idx + 1) + ': ' + d.name, d.col, 3.2);
  g.shake = 14;
  fxRing(b.x, b.y, 520, d.col, 1);
  fxRing(b.x, b.y, 300, '#ffffff', 0.7);
  burst(b.x, b.y, d.col, 30, 240, true);
  sfx('boss'); buzz(120);
}

function enemyBullet(x, y, a, spd, dmg, r) {
  if (G.eb.length > 280) return;
  G.eb.push({ x, y, vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, r: r || 5, dmg, life: 6 });
}

// Возвращает [mx, my, sp] для босса и выполняет его атаки
function bossTick(e, dt, dx, dy, d) {
  const g = G, p = g.p, def = e.def, tier = def.tier, idx = e.idx;
  const bdmg = 9 + Math.floor(idx / 4);
  let mx = dx / d, my = dy / d, sp = e.sp;
  const s = e.s;
  e.ph += dt;

  for (const pat of e.pats) {
    switch (pat) {
      case 'ring':
        s.ring -= dt;
        if (s.ring <= 0) {
          s.ring = Math.max(1.7, 3.2 - 0.04 * idx);
          const n = 12 + Math.min(14, Math.floor(idx / 2)), off = Math.random() * TAU;
          for (let k = 0; k < n; k++) enemyBullet(e.x, e.y, off + k * TAU / n, 115 + tier * 6, bdmg, 6);
          fxRing(e.x, e.y, e.r * 3, e.col, 0.4);
        }
        break;
      case 'aimed':
        s.aimed -= dt;
        if (s.aimed <= 0) {
          s.aimed = 2.1 - Math.min(0.8, tier * 0.07);
          const n = 3 + Math.min(4, tier >> 1), base = Math.atan2(dy, dx);
          for (let k = 0; k < n; k++) enemyBullet(e.x, e.y, base + (k - (n - 1) / 2) * 0.13, 190 + tier * 5, bdmg, 5);
        }
        break;
      case 'spiral':
        if (e.spiralOn > 0) {
          e.spiralOn -= dt; s.spc = (s.spc || 0) - dt;
          if (s.spc <= 0) {
            s.spc = 0.14; e.sa += 0.45;
            const arms = tier >= 7 ? 3 : tier >= 3 ? 2 : 1;
            for (let a = 0; a < arms; a++) enemyBullet(e.x, e.y, e.sa + a * TAU / arms, 135, bdmg, 5);
          }
        } else { s.spiral -= dt; if (s.spiral <= 0) { e.spiralOn = 2.2; s.spiral = 5.5; } }
        break;
      case 'rain':
        s.rain -= dt;
        if (s.rain <= 0) {
          s.rain = 3.6;
          const n = 8 + Math.min(10, tier);
          for (let k = 0; k < n && g.eb.length < 280; k++) g.eb.push({ x: p.x + (Math.random() - 0.5) * 540, y: p.y - viewH() / 2 - 30, vx: 0, vy: 210 + tier * 5, r: 6, dmg: bdmg, life: 5 });
        }
        break;
      case 'summon':
        s.summon -= dt;
        if (s.summon <= 0) {
          s.summon = 6.5;
          const n = 3 + Math.min(5, tier);
          for (let k = 0; k < n && g.en.length < 330; k++) { const a = Math.random() * TAU; spawnEnemy(Math.random() < 0.5 ? 'runner' : 'grunt', e.x + Math.cos(a) * (e.r + 20), e.y + Math.sin(a) * (e.r + 20)); }
          fxRing(e.x, e.y, e.r * 3.2, '#ffffff', 0.4);
        }
        break;
      case 'orbs': {
        const R = e.r + 34;
        for (let k = 0; k < e.orbN; k++) {
          const a = e.ph * 1.7 + k * TAU / e.orbN, ox = e.x + Math.cos(a) * R, oy = e.y + Math.sin(a) * R;
          if (p.inv <= 0 && Math.hypot(p.x - ox, p.y - oy) < p.r + 8) hurt(bdmg + 3);
        }
        break;
      }
      case 'blink':
        if (!e.bl) {
          s.blink -= dt;
          if (s.blink <= 0) { const a = Math.random() * TAU; e.bl = { t: 0.7, x: p.x + Math.cos(a) * 230, y: p.y + Math.sin(a) * 230 }; }
        } else {
          e.bl.t -= dt;
          if (e.bl.t <= 0) {
            burst(e.x, e.y, e.col, 14, 180, true);
            e.x = e.bl.x; e.y = e.bl.y; e.bl = null; s.blink = 5;
            burst(e.x, e.y, e.col, 22, 240, true); fxRing(e.x, e.y, 160, e.col, 0.4);
            for (let k = 0; k < 10; k++) enemyBullet(e.x, e.y, k * TAU / 10, 140, bdmg, 5);
          }
        }
        break;
      case 'sweep':
        if (!e.sw) {
          s.sweep -= dt;
          if (s.sweep <= 0) { e.sw = { t: 0, ang: Math.atan2(dy, dx), dir: Math.random() < 0.5 ? -1 : 1 }; s.sweep = 9; }
        } else {
          e.sw.t += dt; sp *= 0.4;
          if (e.sw.t > 0.8) {
            e.sw.ang += e.sw.dir * 0.95 * dt;
            const c = Math.cos(e.sw.ang), sn = Math.sin(e.sw.ang), ex = p.x - e.x, ey = p.y - e.y, tt = ex * c + ey * sn;
            if (tt > 0 && tt < 460 && Math.abs(ex * sn - ey * c) < 10 + p.r && p.inv <= 0) hurt(bdmg + 5);
          }
          if (e.sw.t > 3.6) e.sw = null;
        }
        break;
      case 'charge':
        if (e.cstate === 2) {
          e.cTimer -= dt; mx = e.cdx; my = e.cdy; sp = 380;
          if (e.cTimer <= 0) { e.cstate = 0; e.chargeT = Math.max(3.5, 6.5 - tier * 0.2); }
        } else {
          e.chargeT -= dt;
          if (e.cstate === 0 && e.chargeT <= 0.9) { e.cstate = 1; e.cdx = mx; e.cdy = my; }
          if (e.cstate === 1) {
            sp = 0; e.cdx = mx; e.cdy = my;
            if (e.chargeT <= 0) { e.cstate = 2; e.cTimer = 0.6; }
          }
        }
        break;
    }
  }
  return [mx, my, sp];
}

// ================= Урон и смерть =================
function addText(x, y, s, col, big) {
  if (G.tx.length > 36) return;
  G.tx.push({ x: x + (Math.random() - 0.5) * 10, y, s: String(s), col: col || '#fff', life: big ? 0.9 : 0.7, max: big ? 0.9 : 0.7, big: !!big });
}

function burst(x, y, col, n, spd, shard) {
  const g = G;
  for (let i = 0; i < n && g.pt.length < 340; i++) {
    const a = Math.random() * TAU, v = (spd || 120) * (0.3 + Math.random());
    const isShard = shard ? i % 2 === 0 : false;
    g.pt.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: 0.35 + Math.random() * 0.4, max: 0.75, col, size: 2 + Math.random() * 3, k: isShard ? 1 : 0 });
  }
}

function hit(e, dmg, kx, ky) {
  if (e.dead) return;
  let crit = false;
  const cc = 0.07 * G.ps.crit;
  if (cc > 0 && Math.random() < cc) { dmg *= 2; crit = true; }
  e.hp -= dmg; e.flash = 0.07;
  if ((kx || ky) && !e.boss) { e.kx += kx; e.ky += ky; }
  addText(e.x, e.y - e.r, Math.max(1, Math.round(dmg)), crit ? '#ffd166' : '#fff', crit);
  sfx('hit');
  if (e.hp <= 0) kill(e);
}

function dropGem(x, y, v) {
  const g = G;
  if (g.gm.length > 320) { const old = g.gm.shift(); if (old.kind === 0) addXp(old.v); }
  g.gm.push({ x: x + (Math.random() - 0.5) * 10, y: y + (Math.random() - 0.5) * 10, v, pull: false, kind: 0 });
}
function dropHeart(x, y) { G.gm.push({ x, y, v: 0, pull: false, kind: 1 }); }

function kill(e) {
  const g = G;
  if (e.dead) return;
  e.dead = true; g.kills++;
  burst(e.x, e.y, e.col, e.boss ? 60 : 8, e.boss ? 300 : 140, true);
  if (e.boss) {
    for (let i = 0; i < 6; i++) dropGem(e.x, e.y, 20);
    dropHeart(e.x, e.y);
    g.boss = null; g.shake = 20; g.eb.length = 0; g.bossKills++;
    g.pending++; g.rerolls++; g.levelTitle = 'Награда за босса';
    S.beast[e.idx % 100] = true;
    fxRing(e.x, e.y, 460, e.col, 0.9); fxRing(e.x, e.y, 240, '#ffffff', 0.6);
    say('Босс повержен!', '#ffd166', 2.6);
    sfx('bosskill'); buzz(150);
    return;
  }
  if (g.fx.length < 30) fxRing(e.x, e.y, e.r * 2.4, e.col, 0.25);
  dropGem(e.x, e.y, e.xp);
  if (Math.random() < (e.elite ? 0.3 : 0.012)) dropHeart(e.x, e.y);
  if (g.ps.vamp) { g.vampAcc += 0.1 * g.ps.vamp; if (g.vampAcc >= 1) { g.vampAcc -= 1; g.p.hp = Math.min(g.p.maxHp, g.p.hp + 1); } }
  if (e.type === 'splitter') for (let i = 0; i < 3; i++) spawnEnemy('mini', e.x + (Math.random() - 0.5) * 24, e.y + (Math.random() - 0.5) * 24);
}

function hurt(raw) {
  const g = G, p = g.p;
  const d = Math.max(1, Math.round(raw - g.ps.armor - (HEROES[S.hero].armor || 0)));
  p.hp -= d; p.inv = 0.55; p.flash = 0.18; g.hurtT = 0.55;
  g.shake = Math.max(g.shake, 7);
  addText(p.x, p.y - 18, '-' + d, '#ff6b81');
  sfx('hurt'); buzz(25);
  if (p.hp <= 0) {
    if (p.revives > 0) {
      p.revives--; p.hp = p.maxHp * 0.5; p.inv = 2.5;
      for (const e of g.en) {
        const dx = e.x - p.x, dy = e.y - p.y, dist = Math.hypot(dx, dy) || 1;
        if (dist < 320 && !e.boss) { e.kx += dx / dist * 700; e.ky += dy / dist * 700; }
      }
      g.eb.length = 0;
      fxRing(p.x, p.y, 320, '#ffd166', 0.5);
      burst(p.x, p.y, '#ffd166', 30, 260, true);
      say('Второй шанс!', '#ffd166');
      sfx('level');
    } else { p.hp = 0; die(); }
  }
}

function die() {
  const g = G;
  if (g.state === 'dead') return;
  g.state = 'dead'; g.endT = 1.4;
  burst(g.p.x, g.p.y, '#5ee7ff', 50, 280, true);
  fxRing(g.p.x, g.p.y, 260, '#5ee7ff', 0.7);
  g.shake = 16;
  sfx('die'); buzz(200);
}

// ================= Опыт и улучшения =================
function addXp(v) {
  const g = G;
  g.xp += v * xpMul();
  while (g.xp >= g.xpNext) { g.xp -= g.xpNext; g.lvl++; g.xpNext = xpNeed(g.lvl); g.pending++; }
}

function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }

function buildChoices() {
  const g = G, pool = [];
  for (const k in WEAPONS) if (g.w[k] < 5) pool.push({ t: 'w', k });
  for (const k in PASSIVES) if (g.ps[k] < 5) pool.push({ t: 'p', k });
  shuffle(pool);
  const ch = pool.slice(0, 3);
  const owned = Object.keys(g.w).filter(k => g.w[k] > 0).length;
  if (owned < 3 && ch.length && !ch.some(c => c.t === 'w')) {
    const wo = pool.find(c => c.t === 'w');
    if (wo) { if (ch.length < 3) ch.push(wo); else ch[2] = wo; }
  }
  const fb = shuffle([{ t: 'ov', k: 'dmg' }, { t: 'ov', k: 'rate' }, { t: 'heal' }, { t: 'gold' }]);
  for (let i = 0; ch.length < 3 && i < fb.length; i++) ch.push(fb[i]);
  return ch;
}

function renderChoices() {
  const g = G;
  $('lvTitle').textContent = g.levelTitle;
  $('cards').innerHTML = g.choices.map((c, i) => {
    let ic, name, sub = '', desc;
    if (c.t === 'w') { const d = WEAPONS[c.k], lv = g.w[c.k]; ic = d.icon; name = d.name; sub = lv ? `Уровень ${lv} → ${lv + 1}` : 'Новое оружие'; desc = d.desc; }
    else if (c.t === 'p') { const d = PASSIVES[c.k], lv = g.ps[c.k]; ic = d.icon; name = d.name; sub = lv ? `Уровень ${lv} → ${lv + 1}` : 'Новое улучшение'; desc = d.desc; }
    else if (c.t === 'ov') { ic = c.k === 'dmg' ? '🔥' : '⚡'; name = 'Перегрузка'; sub = 'Без предела'; desc = c.k === 'dmg' ? '+8% к урону навсегда.' : '+6% к скорострельности навсегда.'; }
    else if (c.t === 'heal') { ic = '🔧'; name = 'Ремонт'; desc = 'Восстановить 40% HP.'; }
    else { ic = '◈'; name = 'Трофеи'; desc = '+25 ядер после забега.'; }
    return `<button class="card ${c.t}" data-i="${i}"><span class="ic">${ic}</span><span class="tx"><b>${name}</b><i>${sub}</i><em>${desc}</em></span></button>`;
  }).join('');
  const rr = $('reroll');
  rr.textContent = '🎲 Обновить (' + g.rerolls + ')';
  rr.disabled = g.rerolls <= 0;
}

function openLevelUp() {
  const g = G;
  g.state = 'levelup'; stick.a = false; stick.dx = stick.dy = 0;
  g.choices = buildChoices();
  renderChoices();
  showScreen('levelup');
  sfx('level');
}

function rerollChoices() {
  const g = G;
  if (!g || g.state !== 'levelup' || g.rerolls <= 0) return;
  g.rerolls--;
  g.choices = buildChoices();
  renderChoices();
  sfx('reroll');
}

function pickChoice(i) {
  const g = G;
  if (!g || g.state !== 'levelup') return;
  const c = g.choices[i];
  if (!c) return;
  if (c.t === 'w') g.w[c.k]++;
  else if (c.t === 'p') {
    g.ps[c.k]++;
    if (c.k === 'hp') { g.p.maxHp += 20; g.p.hp += 20; }
  } else if (c.t === 'ov') { if (c.k === 'dmg') g.ovDmg += 0.08; else g.ovRate += 0.06; }
  else if (c.t === 'heal') g.p.hp = Math.min(g.p.maxHp, g.p.hp + g.p.maxHp * 0.4);
  else g.bonus += 25;
  sfx('click');
  fxRing(g.p.x, g.p.y, 150, '#ffd166', 0.5);
  burst(g.p.x, g.p.y, '#ffd166', 22, 200, true);
  g.pending--;
  g.levelTitle = 'Новый уровень';
  if (g.pending > 0) openLevelUp();
  else { g.state = 'run'; showScreen(null); }
}

// ================= Оружие =================
function nearest(x, y, maxD, n) {
  const arr = [], m2 = maxD * maxD;
  for (const e of G.en) {
    if (e.dead) continue;
    const dx = e.x - x, dy = e.y - y, d = dx * dx + dy * dy;
    if (d < m2) arr.push([d, e]);
  }
  arr.sort((a, b) => a[0] - b[0]);
  return arr.slice(0, n).map(a => a[1]);
}

const orbCount = L => [2, 3, 3, 4, 5][L - 1];
const orbRadius = L => (62 + 5 * L) * area();
function orbPos(i, n, R) { const a = G.orbAng + i * TAU / n; return [G.p.x + Math.cos(a) * R, G.p.y + Math.sin(a) * R]; }
const droneCount = L => [1, 2, 2, 3, 3][L - 1];
function dronePos(i, n) { const a = G.drAng + i * TAU / n, R = 46 + Math.sin(G.t * 3 + i) * 4; return [G.p.x + Math.cos(a) * R, G.p.y + Math.sin(a) * R]; }

function explode(x, y, R, dmg, kb, col) {
  const g = G;
  for (const e of g.en) {
    if (e.dead) continue;
    const dx = e.x - x, dy = e.y - y, d = Math.hypot(dx, dy) || 1;
    if (d < R + e.r) hit(e, dmg, dx / d * kb, dy / d * kb);
  }
  fxRing(x, y, R, col, 0.35);
  burst(x, y, col, 14, 200, true);
}

function weapons(dt) {
  const g = G, p = g.p, w = g.w, cdm = cdMul(), dm = dmgMul(), ar = area();

  if (w.pulse > 0) {
    g.cd.pulse -= dt;
    if (g.cd.pulse <= 0) {
      const L = w.pulse, n = [1, 2, 2, 3, 4][L - 1];
      const tg = nearest(p.x, p.y, 480, n);
      if (tg.length) {
        g.cd.pulse = (0.95 - 0.11 * L) * cdm;
        for (let i = 0; i < n; i++) {
          const e = tg[i % tg.length];
          let a = Math.atan2(e.y - p.y, e.x - p.x);
          if (tg.length < n) a += (i - (n - 1) / 2) * 0.16;
          g.bu.push({ x: p.x, y: p.y, vx: Math.cos(a) * 430, vy: Math.sin(a) * 430, r: 5 * Math.sqrt(ar), dmg: (10 + 5 * L) * dm, pierce: L >= 4 ? 1 : 0, life: 1.2, hit: [] });
        }
        sfx('shoot');
      } else g.cd.pulse = 0.1;
    }
  }

  if (w.orbit > 0) {
    const L = w.orbit, n = orbCount(L), R = orbRadius(L), od = (7 + 3 * L) * dm;
    g.orbAng += (2.6 + 0.25 * L) * dt;
    for (let i = 0; i < n; i++) {
      const o = orbPos(i, n, R);
      for (const e of g.en) {
        if (e.dead) continue;
        const dx = e.x - o[0], dy = e.y - o[1], rr = e.r + 9 * ar;
        if (dx * dx + dy * dy < rr * rr && g.t - e.oh > 0.4) { e.oh = g.t; hit(e, od, dx * 8, dy * 8); }
      }
    }
  }

  if (w.nova > 0) {
    g.cd.nova -= dt;
    if (g.cd.nova <= 0) {
      const L = w.nova, R = (80 + 22 * L) * ar;
      if (nearest(p.x, p.y, R + 40, 1).length) {
        g.cd.nova = (3.6 - 0.38 * L) * cdm;
        explode(p.x, p.y, R, (16 + 9 * L) * dm, 320, '#ff4d9d');
        fxRing(p.x, p.y, R * 0.6, '#ffffff', 0.25);
        sfx('nova');
      } else g.cd.nova = 0.15;
    }
  }

  if (w.chain > 0) {
    g.cd.chain -= dt;
    if (g.cd.chain <= 0) {
      const L = w.chain, first = nearest(p.x, p.y, 320 * ar, 1)[0];
      if (first) {
        g.cd.chain = (1.7 - 0.2 * L) * cdm;
        const jumps = 2 + L, cd = (12 + 6 * L) * dm, used = new Set();
        const pts = [{ x: p.x, y: p.y }];
        let cur = first;
        for (let j = 0; j <= jumps && cur; j++) {
          used.add(cur.id);
          pts.push({ x: cur.x, y: cur.y });
          const cx = cur.x, cy = cur.y;
          hit(cur, cd, 0, 0);
          let best = null, bd = 150 * 150 * ar * ar;
          for (const e of g.en) {
            if (e.dead || used.has(e.id)) continue;
            const dx = e.x - cx, dy = e.y - cy, d = dx * dx + dy * dy;
            if (d < bd) { bd = d; best = e; }
          }
          cur = best;
        }
        g.fx.push({ k: 'bolt', pts, life: 0.2, max: 0.2 });
        sfx('zap');
      } else g.cd.chain = 0.15;
    }
  }

  if (w.laser > 0) {
    g.cd.laser -= dt;
    if (g.cd.laser <= 0) {
      const L = w.laser, nb = L >= 5 ? 3 : L >= 3 ? 2 : 1;
      const tg = nearest(p.x, p.y, 520, nb);
      if (tg.length) {
        g.cd.laser = (2.6 - 0.3 * L) * cdm;
        const hw = (6 + 1.5 * L) * ar, ld = (26 + 12 * L) * dm, len = 560;
        for (let b = 0; b < nb; b++) {
          const e0 = tg[b % tg.length];
          let a = Math.atan2(e0.y - p.y, e0.x - p.x);
          if (tg.length < nb) a += (b - (nb - 1) / 2) * 0.35;
          const dx = Math.cos(a), dy = Math.sin(a);
          for (const e of g.en) {
            if (e.dead) continue;
            const ex = e.x - p.x, ey = e.y - p.y, tt = ex * dx + ey * dy;
            if (tt > 0 && tt < len && Math.abs(ex * dy - ey * dx) < hw + e.r) hit(e, ld, dx * 120, dy * 120);
          }
          g.fx.push({ k: 'beam', x: p.x, y: p.y, dx, dy, len, w: hw * 1.6, life: 0.24, max: 0.24 });
        }
        sfx('zap'); g.shake = Math.max(g.shake, 2);
      } else g.cd.laser = 0.15;
    }
  }

  // Дроны
  if (w.drone > 0) {
    const L = w.drone, n = droneCount(L);
    g.drAng += 1.9 * dt;
    for (let i = 0; i < n; i++) {
      g.drCd[i] = (g.drCd[i] || 0) - dt;
      if (g.drCd[i] <= 0) {
        const pos = dronePos(i, n), tg = nearest(pos[0], pos[1], 380, 1);
        if (tg.length) {
          const a = Math.atan2(tg[0].y - pos[1], tg[0].x - pos[0]);
          g.bu.push({ x: pos[0], y: pos[1], vx: Math.cos(a) * 400, vy: Math.sin(a) * 400, r: 4 * Math.sqrt(ar), dmg: (6 + 3 * L) * dm, pierce: L >= 5 ? 1 : 0, life: 1, hit: [] });
          g.drCd[i] = (1.05 - 0.1 * L) * cdm;
        } else g.drCd[i] = 0.2;
      }
    }
  }

  // Мины
  if (w.mine > 0) {
    const L = w.mine;
    g.cd.mine -= dt;
    if (g.cd.mine <= 0) {
      if (g.mn.length < 4 + L && nearest(p.x, p.y, 420, 1).length) { g.mn.push({ x: p.x, y: p.y, arm: 0.6, life: 14 }); g.cd.mine = (2.6 - 0.26 * L) * cdm; }
      else g.cd.mine = 0.3;
    }
    const R = (55 + 8 * L) * ar;
    for (const m of g.mn) {
      m.arm -= dt; m.life -= dt;
      if (m.arm > 0) continue;
      for (const e of g.en) {
        if (e.dead) continue;
        if (Math.hypot(e.x - m.x, e.y - m.y) < e.r + 16) { explode(m.x, m.y, R, (24 + 11 * L) * dm, 260, '#ffb703'); m.life = 0; g.shake = Math.max(g.shake, 3); sfx('boom'); break; }
      }
    }
    g.mn = g.mn.filter(m => m.life > 0);
  }

  // Диск-бумеранг
  if (w.boom > 0) {
    const L = w.boom;
    g.cd.boom -= dt;
    if (g.cd.boom <= 0) {
      const n = 1 + (L >= 3 ? 1 : 0) + (L >= 5 ? 1 : 0), tg = nearest(p.x, p.y, 500, n);
      if (tg.length) {
        for (let i = 0; i < n; i++) {
          const a = i < tg.length ? Math.atan2(tg[i].y - p.y, tg[i].x - p.x) : Math.atan2(tg[0].y - p.y, tg[0].x - p.x) + (i - tg.length + 1) * 0.5;
          g.bm.push({ x: p.x, y: p.y, vx: Math.cos(a) * 380, vy: Math.sin(a) * 380, ph: 0, d: 0, max: (250 + 20 * L) * ar, hit: [], rot: 0, dead: false });
        }
        g.cd.boom = (2.3 - 0.22 * L) * cdm; sfx('shoot');
      } else g.cd.boom = 0.2;
    }
  }
  for (const b of g.bm) {
    b.rot += 14 * dt;
    if (b.ph === 0) {
      b.x += b.vx * dt; b.y += b.vy * dt; b.d += 380 * dt;
      if (b.d >= b.max) { b.ph = 1; b.hit = []; }
    } else {
      const dx = p.x - b.x, dy = p.y - b.y, d = Math.hypot(dx, dy) || 1;
      b.x += dx / d * 480 * dt; b.y += dy / d * 480 * dt;
      if (d < 18) b.dead = true;
    }
    const bd = (14 + 7 * (w.boom || 1)) * dm;
    for (const e of g.en) {
      if (e.dead) continue;
      const dx = e.x - b.x, dy = e.y - b.y, rr = e.r + 14 * ar;
      if (dx * dx + dy * dy < rr * rr && b.hit.indexOf(e.id) < 0) { b.hit.push(e.id); hit(e, bd, dx * 3, dy * 3); }
    }
  }
  g.bm = g.bm.filter(b => !b.dead);

  // Метеоры
  if (w.meteor > 0) {
    const L = w.meteor;
    g.cd.meteor -= dt;
    if (g.cd.meteor <= 0) {
      const n = 1 + Math.floor(L / 2), c = nearest(p.x, p.y, 520, 16);
      if (c.length) {
        for (let i = 0; i < n; i++) { const e = c[Math.floor(Math.random() * c.length)]; g.mt.push({ x: e.x, y: e.y, t: 0.75, max: 0.75, R: (46 + 6 * L) * ar }); }
        g.cd.meteor = (3.3 - 0.3 * L) * cdm;
      } else g.cd.meteor = 0.3;
    }
  }
  for (const m of g.mt) {
    m.t -= dt;
    if (m.t <= 0) { explode(m.x, m.y, m.R, (30 + 14 * (w.meteor || 1)) * dm, 300, '#ff9f1c'); g.shake = Math.max(g.shake, 5); sfx('boom'); }
  }
  g.mt = g.mt.filter(m => m.t > 0);
}

// ================= Обновление мира =================
function update(dt) {
  const g = G;
  if (!g) return;
  if (g.banner) { g.banner.life -= dt; if (g.banner.life <= 0) g.banner = null; }
  g.shake = Math.max(0, g.shake - 40 * dt);
  g.hurtT = Math.max(0, g.hurtT - 1.6 * dt);
  g.dark = Math.max(0, g.dark - 0.9 * dt);

  if (g.state === 'dead') {
    updateFx(dt);
    g.endT -= dt;
    if (g.endT <= 0) endRun();
    return;
  }
  if (g.state !== 'run') return;

  g.t += dt;
  const p = g.p;

  let ix = stick.dx, iy = stick.dy;
  if (keys.size) {
    const kx = (keys.has('d') || keys.has('arrowright') || keys.has('в') ? 1 : 0) - (keys.has('a') || keys.has('arrowleft') || keys.has('ф') ? 1 : 0);
    const ky = (keys.has('s') || keys.has('arrowdown') || keys.has('ы') ? 1 : 0) - (keys.has('w') || keys.has('arrowup') || keys.has('ц') ? 1 : 0);
    if (kx || ky) { const l = Math.hypot(kx, ky); ix = kx / l; iy = ky / l; }
  }
  const sp = 150 * spdMul();
  p.x += ix * sp * dt; p.y += iy * sp * dt;
  if (ix || iy) {
    p.face = Math.atan2(iy, ix);
    if (Math.random() < 0.7 && g.pt.length < 340) { // след двигателя
      g.pt.push({ x: p.x - Math.cos(p.face) * 9, y: p.y - Math.sin(p.face) * 9, vx: -ix * 30 + (Math.random() - 0.5) * 24, vy: -iy * 30 + (Math.random() - 0.5) * 24, life: 0.3, max: 0.3, col: '#5ee7ff', size: 3, k: 0 });
    }
  }
  p.inv -= dt; p.flash -= dt;
  const regen = 0.4 * g.ps.regen;
  if (regen && p.hp < p.maxHp) p.hp = Math.min(p.maxHp, p.hp + regen * dt);
  g.hpShow = g.hpShow > p.hp ? Math.max(p.hp, g.hpShow - 60 * dt) : p.hp;
  if (g.boss) g.bossBar = Math.min(1, g.bossBar + dt * 2.5);

  spawnTick(dt);
  weapons(dt);
  enemiesTick(dt);
  bulletsTick(dt);
  gemsTick(dt);
  updateFx(dt);

  g.en = g.en.filter(e => !e.dead);

  if (g.pending > 0 && g.state === 'run') openLevelUp();
}

function spawnTick(dt) {
  const g = G, t = g.t;
  let rate = 1.4 + Math.min(10, (t / 60) * 1.0);
  if (g.boss) rate *= 0.45;
  g.spawnAcc += rate * dt;
  const cap = 90 + Math.min(200, t * 0.3);
  while (g.spawnAcc >= 1) {
    g.spawnAcc -= 1;
    if (g.en.length < cap) spawnEnemy(pickType(t));
  }
  if (!g.boss && t >= 90 + 55 * g.spawned) spawnBoss(g.spawned);
}

function enemiesTick(dt) {
  const g = G, p = g.p, t = g.t;
  const far = Math.max(viewW(), viewH()) / 2 + 260;
  const slowM = 1 - Math.min(0.35, 0.05 * g.ps.slow);
  for (let i = 0; i < g.en.length; i++) {
    const e = g.en[i];
    if (e.dead) continue;
    e.born += dt;
    const dx = p.x - e.x, dy = p.y - e.y, d = Math.hypot(dx, dy) || 1;
    let mx = dx / d, my = dy / d, sp = e.sp * (e.boss ? 1 : slowM);

    if (e.type === 'shooter') {
      if (d < 190) { mx = -mx; my = -my; sp *= 0.7; }
      else if (d < 250) sp = 0;
      e.shoot -= dt;
      if (e.shoot <= 0 && d < 420) { e.shoot = 2.4; enemyBullet(e.x, e.y, Math.atan2(dy, dx), 150, e.dmg, 5); }
    }

    if (e.boss) {
      const r = bossTick(e, dt, dx, dy, d);
      mx = r[0]; my = r[1]; sp = r[2];
    } else {
      const wob = Math.sin(t * 2 + e.ph) * 0.25;
      const tx = mx; mx = mx - my * wob; my = my + tx * wob;
    }

    e.x += (mx * sp + e.kx) * dt;
    e.y += (my * sp + e.ky) * dt;
    const kd = Math.max(0, 1 - 8 * dt); e.kx *= kd; e.ky *= kd;
    if (e.flash > 0) e.flash -= dt;

    if (d < e.r + p.r && p.inv <= 0) hurt(e.dmg);

    if (!e.boss && d > far) { const q = ringPos(); e.x = q[0]; e.y = q[1]; e.born = 0; }
  }
}

function bulletsTick(dt) {
  const g = G, p = g.p;
  for (const b of g.bu) {
    b.px = b.x; b.py = b.y;
    b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
    for (const e of g.en) {
      if (e.dead || b.life <= 0) continue;
      const dx = e.x - b.x, dy = e.y - b.y, rr = e.r + b.r;
      if (dx * dx + dy * dy < rr * rr && b.hit.indexOf(e.id) < 0) {
        b.hit.push(e.id);
        hit(e, b.dmg, b.vx * 0.25, b.vy * 0.25);
        if (b.pierce-- <= 0) { b.life = 0; break; }
      }
    }
  }
  g.bu = g.bu.filter(b => b.life > 0);

  for (const b of g.eb) {
    b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
    const dx = p.x - b.x, dy = p.y - b.y, rr = p.r + b.r;
    if (dx * dx + dy * dy < rr * rr && p.inv <= 0 && g.state === 'run') { b.life = 0; hurt(b.dmg); }
  }
  g.eb = g.eb.filter(b => b.life > 0);
}

function gemsTick(dt) {
  const g = G, p = g.p, mr = magR();
  for (let i = g.gm.length - 1; i >= 0; i--) {
    const m = g.gm[i];
    const dx = p.x - m.x, dy = p.y - m.y, d = Math.hypot(dx, dy) || 1;
    if (d < mr) m.pull = true;
    if (m.pull) { const s = 400 + (mr - Math.min(d, mr)) * 2; m.x += dx / d * s * dt; m.y += dy / d * s * dt; }
    if (d < p.r + 8) {
      if (m.kind === 1) {
        p.hp = Math.min(p.maxHp, p.hp + 20);
        addText(p.x, p.y - 18, '+20', '#7dff9d');
        sfx('level'); fxRing(p.x, p.y, 70, '#7dff9d', 0.35);
      } else {
        addXp(m.v);
        g.streak = (g.t - g.gemT < 0.4) ? g.streak + 1 : 0; g.gemT = g.t;
        sfx('gem', g.streak);
      }
      g.gm.splice(i, 1);
    }
  }
}

function updateFx(dt) {
  const g = G;
  for (const q of g.pt) { q.life -= dt; q.x += q.vx * dt; q.y += q.vy * dt; q.vx *= 0.94; q.vy *= 0.94; }
  g.pt = g.pt.filter(q => q.life > 0);
  for (const f of g.fx) f.life -= dt;
  g.fx = g.fx.filter(f => f.life > 0);
  for (const s of g.tx) { s.life -= dt; s.y -= 26 * dt; }
  g.tx = g.tx.filter(s => s.life > 0);
}

// ================= Конец забега =================
function fmtTime(s) { s = Math.floor(s); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); }

function endRun() {
  const g = G;
  if (!g || g.over) return;
  g.over = true; g.state = 'over';
  const raw = Math.floor(g.kills / 8) + Math.floor(g.t / 6) + g.bossKills * 25 + g.bonus;
  const cores = Math.floor(raw * (1 + 0.1 * S.meta.gold));
  S.cores += cores;
  S.bestT = Math.max(S.bestT, Math.floor(g.t));
  S.bestK = Math.max(S.bestK, g.kills);
  S.bestB = Math.max(S.bestB, g.bossKills);
  persist();
  musicStop();
  $('pauseBtn').classList.add('hidden');
  $('endTitle').textContent = 'Забег окончен';
  $('endStats').innerHTML =
    `<div>Время<b>${fmtTime(g.t)}</b></div>` +
    `<div>Уровень<b>${g.lvl}</b></div>` +
    `<div>Боссов повержено<b>${g.bossKills}</b></div>` +
    `<div>Уничтожено<b>${g.kills}</b></div>` +
    `<div class="gain">Ядра<b>+${cores} ◈</b></div>`;
  showScreen('end');
}

// ================= Отрисовка =================
function poly(x, y, r, n, rot) {
  ctx.beginPath();
  for (let i = 0; i < n; i++) {
    const a = rot + i * TAU / n;
    const px = x + Math.cos(a) * r, py = y + Math.sin(a) * r;
    if (i) ctx.lineTo(px, py); else ctx.moveTo(px, py);
  }
  ctx.closePath();
}

function drawGrid(camx, camy, vw, vh, hue, t) {
  const step = 60;
  const x0 = Math.floor(camx / step) * step, y0 = Math.floor(camy / step) * step;
  const pulse = 0.85 + 0.15 * Math.sin(t * 2);
  ctx.lineWidth = 1;
  ctx.strokeStyle = `hsla(${hue},80%,60%,${0.08 * pulse})`;
  ctx.beginPath();
  for (let x = x0; x < camx + vw + step; x += step) if (Math.round(x / step) % 4) { ctx.moveTo(x, camy); ctx.lineTo(x, camy + vh); }
  for (let y = y0; y < camy + vh + step; y += step) if (Math.round(y / step) % 4) { ctx.moveTo(camx, y); ctx.lineTo(camx + vw, y); }
  ctx.stroke();
  ctx.strokeStyle = `hsla(${hue},90%,65%,${0.2 * pulse})`;
  ctx.beginPath();
  for (let x = x0; x < camx + vw + step; x += step) if (!(Math.round(x / step) % 4)) { ctx.moveTo(x, camy); ctx.lineTo(x, camy + vh); }
  for (let y = y0; y < camy + vh + step; y += step) if (!(Math.round(y / step) % 4)) { ctx.moveTo(camx, y); ctx.lineTo(camx + vw, y); }
  ctx.stroke();
}

function drawEnemy(e, t) {
  const sc = e.boss ? easeBack(e.born / 0.9) : easeBack(e.born / 0.3);
  const r = e.r * sc;
  if (r < 0.5) return;
  const col = e.flash > 0 ? '#ffffff' : e.col;
  if (e.sides < 3) { ctx.beginPath(); ctx.arc(e.x, e.y, r, 0, TAU); }
  else poly(e.x, e.y, r, e.sides, e.boss ? t * 0.5 : -Math.PI / 2);
  ctx.globalAlpha = e.flash > 0 ? 0.9 : 0.28;
  ctx.fillStyle = col; ctx.fill();
  ctx.globalAlpha = 1;
  ctx.lineWidth = e.elite ? 3 : 2;
  ctx.strokeStyle = col; ctx.stroke();
  if (e.elite) { ctx.globalAlpha = 0.5 + 0.3 * Math.sin(t * 8); ctx.beginPath(); ctx.arc(e.x, e.y, r + 4, 0, TAU); ctx.stroke(); ctx.globalAlpha = 1; }
  if (e.type === 'splitter') { ctx.beginPath(); ctx.arc(e.x, e.y, r * 0.4, 0, TAU); ctx.stroke(); }
  if (e.boss) {
    poly(e.x, e.y, r * 0.6, e.sides, -t * 0.9); ctx.lineWidth = 2; ctx.stroke();
    ctx.beginPath(); ctx.arc(e.x, e.y, r * (0.22 + 0.04 * Math.sin(t * 5)), 0, TAU); ctx.fillStyle = col; ctx.globalAlpha = 0.85; ctx.fill(); ctx.globalAlpha = 1;
    // аура
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.18 + 0.1 * Math.sin(t * 4);
    ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(e.x, e.y, r * 1.25 + 3 * Math.sin(t * 3), 0, TAU); ctx.stroke();
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  }
}

function drawBossExtras(e, t) {
  if (e.cstate === 1) {
    ctx.strokeStyle = 'rgba(255,60,90,' + (0.35 + 0.35 * Math.sin(t * 30)) + ')';
    ctx.lineWidth = e.r * 1.2;
    ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.lineTo(e.x + e.cdx * 600, e.y + e.cdy * 600); ctx.stroke();
  }
  if (e.pats.indexOf('orbs') >= 0) {
    const R = e.r + 34;
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = e.col;
    for (let k = 0; k < e.orbN; k++) {
      const a = e.ph * 1.7 + k * TAU / e.orbN, ox = e.x + Math.cos(a) * R, oy = e.y + Math.sin(a) * R;
      ctx.globalAlpha = 0.3; ctx.beginPath(); ctx.arc(ox, oy, 15, 0, TAU); ctx.fill();
      ctx.globalAlpha = 1; ctx.beginPath(); ctx.arc(ox, oy, 8, 0, TAU); ctx.fill();
    }
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  }
  if (e.bl) {
    const k = 1 - e.bl.t / 0.7;
    ctx.strokeStyle = e.col; ctx.lineWidth = 3; ctx.globalAlpha = 0.5 + 0.4 * Math.sin(t * 20);
    ctx.beginPath(); ctx.arc(e.bl.x, e.bl.y, e.r * (1.6 - 0.6 * k), 0, TAU); ctx.stroke();
    poly(e.bl.x, e.bl.y, e.r * k, e.sides, t); ctx.stroke();
    ctx.globalAlpha = 1;
  }
  if (e.sw) {
    const c = Math.cos(e.sw.ang), s = Math.sin(e.sw.ang);
    ctx.globalCompositeOperation = 'lighter';
    if (e.sw.t < 0.8) {
      ctx.strokeStyle = 'rgba(255,80,110,' + (0.3 + 0.3 * Math.sin(t * 30)) + ')'; ctx.lineWidth = 3;
    } else {
      ctx.strokeStyle = 'rgba(255,90,120,0.85)'; ctx.lineWidth = 16 + 3 * Math.sin(t * 40);
    }
    ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.lineTo(e.x + c * 460, e.y + s * 460); ctx.stroke();
    if (e.sw.t >= 0.8) { ctx.strokeStyle = '#fff'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.lineTo(e.x + c * 460, e.y + s * 460); ctx.stroke(); }
    ctx.globalCompositeOperation = 'source-over';
  }
}

function render() {
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = '#070913';
  ctx.fillRect(0, 0, W, H);
  const g = G;
  const vw = viewW(), vh = viewH();

  if (!g) { // фон меню
    drawStars(bgT * 30, bgT * 18, bgT);
    ctx.setTransform(dpr * Z, 0, 0, dpr * Z, 0, 0);
    drawGrid(bgT * 20, bgT * 12, vw, vh, 190, bgT);
    ctx.globalCompositeOperation = 'lighter';
    for (const s of menuShapes) {
      s.x = (s.x + s.vx / 60 + 1) % 1; s.y = (s.y + s.vy / 60 + 1) % 1; s.rot += s.vr / 60;
      const x = s.x * vw, y = s.y * vh;
      ctx.globalAlpha = 0.35; ctx.lineWidth = 2; ctx.strokeStyle = s.col;
      if (s.sides < 3) { ctx.beginPath(); ctx.arc(x, y, s.r, 0, TAU); } else poly(x, y, s.r, s.sides, s.rot);
      ctx.stroke();
      ctx.globalAlpha = 0.06; ctx.fillStyle = s.col; ctx.fill();
    }
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    return;
  }

  const p = g.p, t = g.t;
  const sx = g.shake > 0 ? (Math.random() - 0.5) * g.shake : 0, sy = g.shake > 0 ? (Math.random() - 0.5) * g.shake : 0;
  const camx = p.x - vw / 2 + sx, camy = p.y - vh / 2 + sy;

  drawStars(camx, camy, t);
  const hue = (200 + g.bossKills * 22) % 360;
  ctx.setTransform(dpr * Z, 0, 0, dpr * Z, -camx * dpr * Z, -camy * dpr * Z);
  drawGrid(camx, camy, vw, vh, hue, t);

  // телеграф метеоров и мины
  for (const m of g.mt) {
    const k = 1 - m.t / m.max;
    ctx.strokeStyle = '#ff9f1c'; ctx.globalAlpha = 0.85; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(m.x, m.y, m.R, 0, TAU); ctx.stroke();
    ctx.fillStyle = '#ff9f1c'; ctx.globalAlpha = 0.08 + 0.25 * k;
    ctx.beginPath(); ctx.arc(m.x, m.y, m.R * k, 0, TAU); ctx.fill();
    ctx.globalAlpha = 1;
    // падающий камень
    const fy = m.y - (1 - k) * 260;
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = '#ffd166'; ctx.beginPath(); ctx.arc(m.x, fy, 8, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(255,159,28,.7)'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(m.x, fy); ctx.lineTo(m.x, fy - 40); ctx.stroke();
    ctx.globalCompositeOperation = 'source-over';
  }
  for (const m of g.mn) {
    const armed = m.arm <= 0, blink = armed ? 0.6 + 0.4 * Math.sin(t * 8) : 0.4;
    ctx.globalAlpha = blink; ctx.fillStyle = '#ffb703';
    poly(m.x, m.y, 8, 4, Math.PI / 4); ctx.fill();
    ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.globalAlpha = 1;
  }

  // кристаллы и сердечки
  for (const m of g.gm) {
    const pul = 1 + 0.15 * Math.sin(t * 6 + m.x * 0.1);
    if (m.kind === 1) {
      ctx.fillStyle = '#ff4d6d';
      const s = pul;
      ctx.fillRect(m.x - 2.5 * s, m.y - 7 * s, 5 * s, 14 * s); ctx.fillRect(m.x - 7 * s, m.y - 2.5 * s, 14 * s, 5 * s);
    } else {
      const s = (m.v >= 20 ? 8 : m.v >= 4 ? 6 : 4) * pul;
      ctx.fillStyle = m.v >= 20 ? '#ff7df0' : m.v >= 4 ? '#7dff9d' : '#5ee7ff';
      poly(m.x, m.y, s, 4, Math.PI / 4); ctx.fill();
      if (m.pull) { ctx.globalAlpha = 0.4; ctx.strokeStyle = ctx.fillStyle; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(m.x, m.y); ctx.lineTo(m.x + (p.x - m.x) * 0.15, m.y + (p.y - m.y) * 0.15); ctx.stroke(); ctx.globalAlpha = 1; }
    }
  }

  // пули врагов
  ctx.globalCompositeOperation = 'lighter';
  for (const b of g.eb) {
    ctx.fillStyle = '#ff6b81';
    ctx.globalAlpha = 0.3; ctx.beginPath(); ctx.arc(b.x, b.y, b.r * 2, 0, TAU); ctx.fill();
    ctx.globalAlpha = 1; ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, TAU); ctx.fill();
  }
  ctx.globalCompositeOperation = 'source-over';

  // враги
  for (const e of g.en) {
    if (e.dead) continue;
    if (e.x < camx - 80 || e.x > camx + vw + 80 || e.y < camy - 80 || e.y > camy + vh + 80) continue;
    drawEnemy(e, t);
    if (e.boss) drawBossExtras(e, t);
  }

  // эффекты оружия (аддитивное свечение)
  ctx.globalCompositeOperation = 'lighter';
  for (const f of g.fx) {
    const k = Math.max(0, f.life / f.max);
    if (f.k === 'ring') {
      ctx.strokeStyle = f.col; ctx.globalAlpha = k; ctx.lineWidth = 6 * k + 2;
      ctx.beginPath(); ctx.arc(f.x, f.y, f.r1 * (1 - k * k), 0, TAU); ctx.stroke();
    } else if (f.k === 'bolt') {
      for (let pass = 0; pass < 2; pass++) {
        ctx.strokeStyle = pass ? '#ffffff' : '#7fe8ff'; ctx.globalAlpha = k * (pass ? 1 : 0.6); ctx.lineWidth = pass ? 2 : 6;
        ctx.beginPath();
        for (let i = 0; i < f.pts.length; i++) {
          const q = f.pts[i];
          if (i) {
            const a = f.pts[i - 1], mx = (a.x + q.x) / 2 + (Math.random() - 0.5) * 18, my = (a.y + q.y) / 2 + (Math.random() - 0.5) * 18;
            ctx.lineTo(mx, my); ctx.lineTo(q.x, q.y);
          } else ctx.moveTo(q.x, q.y);
        }
        ctx.stroke();
      }
    } else if (f.k === 'beam') {
      ctx.strokeStyle = '#ffd166'; ctx.globalAlpha = k * 0.9; ctx.lineWidth = f.w * k + 2;
      ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.lineTo(f.x + f.dx * f.len, f.y + f.dy * f.len); ctx.stroke();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(1, f.w * 0.3 * k);
      ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.lineTo(f.x + f.dx * f.len, f.y + f.dy * f.len); ctx.stroke();
    }
  }
  ctx.globalAlpha = 1;

  // снаряды: след + ядро
  ctx.fillStyle = '#7dfcff';
  for (const b of g.bu) {
    ctx.strokeStyle = 'rgba(125,252,255,0.55)'; ctx.lineWidth = b.r * 1.4;
    ctx.beginPath(); ctx.moveTo(b.x - b.vx * 0.045, b.y - b.vy * 0.045); ctx.lineTo(b.x, b.y); ctx.stroke();
    ctx.globalAlpha = 0.3; ctx.beginPath(); ctx.arc(b.x, b.y, b.r * 2.2, 0, TAU); ctx.fill();
    ctx.globalAlpha = 1; ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, TAU); ctx.fill();
  }
  // клинки
  if (g.w.orbit > 0) {
    const L = g.w.orbit, n = orbCount(L), R = orbRadius(L);
    ctx.strokeStyle = 'rgba(255,154,209,0.12)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(p.x, p.y, R, 0, TAU); ctx.stroke();
    ctx.fillStyle = '#ff9ad1';
    for (let i = 0; i < n; i++) {
      const o = orbPos(i, n, R);
      for (let tr = 1; tr <= 3; tr++) { // шлейф
        const a = g.orbAng - tr * 0.12 + i * TAU / n;
        ctx.globalAlpha = 0.25 / tr; ctx.beginPath(); ctx.arc(p.x + Math.cos(a) * R, p.y + Math.sin(a) * R, 9 - tr * 1.5, 0, TAU); ctx.fill();
      }
      ctx.globalAlpha = 0.3; ctx.beginPath(); ctx.arc(o[0], o[1], 16, 0, TAU); ctx.fill();
      ctx.globalAlpha = 1; poly(o[0], o[1], 9, 4, g.orbAng * 3); ctx.fill();
    }
  }
  // дроны
  if (g.w.drone > 0) {
    const n = droneCount(g.w.drone);
    for (let i = 0; i < n; i++) {
      const o = dronePos(i, n);
      ctx.fillStyle = '#9fffe0';
      ctx.globalAlpha = 0.3; ctx.beginPath(); ctx.arc(o[0], o[1], 11, 0, TAU); ctx.fill();
      ctx.globalAlpha = 1; poly(o[0], o[1], 6, 3, g.drAng * 2 + i); ctx.fill();
    }
  }
  // диски
  for (const b of g.bm) {
    ctx.strokeStyle = '#ffd166'; ctx.fillStyle = '#ffd166';
    ctx.globalAlpha = 0.25; ctx.beginPath(); ctx.arc(b.x, b.y, 20, 0, TAU); ctx.fill();
    ctx.globalAlpha = 1; ctx.lineWidth = 3;
    poly(b.x, b.y, 12, 4, b.rot); ctx.stroke();
    poly(b.x, b.y, 6, 4, -b.rot); ctx.stroke();
  }

  // частицы
  for (const q of g.pt) {
    ctx.globalAlpha = Math.max(0, q.life / q.max);
    if (q.k === 1) {
      ctx.strokeStyle = q.col; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(q.x, q.y); ctx.lineTo(q.x - q.vx * 0.06, q.y - q.vy * 0.06); ctx.stroke();
    } else {
      ctx.fillStyle = q.col;
      ctx.fillRect(q.x - q.size / 2, q.y - q.size / 2, q.size, q.size);
    }
  }
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';

  // игрок
  if (g.state !== 'dead') {
    const blink = p.inv > 0 && Math.floor(t * 20) % 2 === 0;
    ctx.globalAlpha = blink ? 0.35 : 1;
    const pr = p.r + 7 + Math.sin(t * 4) * 1.5;
    ctx.beginPath(); ctx.arc(p.x, p.y, pr, 0, TAU);
    ctx.fillStyle = 'rgba(94,231,255,0.12)'; ctx.fill();
    ctx.beginPath();
    const a = p.face;
    ctx.moveTo(p.x + Math.cos(a) * 15, p.y + Math.sin(a) * 15);
    ctx.lineTo(p.x + Math.cos(a + 2.5) * 12, p.y + Math.sin(a + 2.5) * 12);
    ctx.lineTo(p.x + Math.cos(a + Math.PI) * 5, p.y + Math.sin(a + Math.PI) * 5);
    ctx.lineTo(p.x + Math.cos(a - 2.5) * 12, p.y + Math.sin(a - 2.5) * 12);
    ctx.closePath();
    ctx.fillStyle = p.flash > 0 ? '#ff6b81' : '#5ee7ff'; ctx.fill();
    ctx.lineWidth = 2; ctx.strokeStyle = '#ffffff'; ctx.stroke();
    ctx.globalAlpha = 1;
  }

  // цифры урона
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  for (const s of g.tx) {
    const age = 1 - s.life / s.max, pop = 1 + (s.big ? 0.5 : 0.25) * Math.max(0, 1 - age * 5);
    ctx.font = '800 ' + Math.round((s.big ? 20 : 14) * pop) + 'px system-ui, sans-serif';
    ctx.globalAlpha = Math.min(1, s.life / 0.3);
    ctx.fillStyle = s.col;
    ctx.fillText(s.s, s.x, s.y);
  }
  ctx.globalAlpha = 1;

  drawHud();
}

function drawHud() {
  const g = G, p = g.p, t = g.t;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.textBaseline = 'middle';

  // затемнение при появлении босса
  if (g.dark > 0) { ctx.fillStyle = 'rgba(0,0,0,' + (g.dark * 0.45) + ')'; ctx.fillRect(0, 0, W, H); }

  // виньетка урона и низкого HP
  const low = p.hp / p.maxHp < 0.3 && g.state !== 'dead' ? 0.22 + 0.12 * Math.sin(t * 6) : 0;
  const hv = Math.max(g.hurtT * 0.6, low);
  if (hv > 0.01) {
    const gr = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.max(W, H) * 0.75);
    gr.addColorStop(0, 'rgba(255,40,70,0)'); gr.addColorStop(1, 'rgba(255,40,70,' + hv + ')');
    ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H);
  }

  // опыт
  const xw = W * Math.min(1, g.xp / g.xpNext);
  ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.fillRect(0, topPad - 4, W, 7);
  ctx.fillStyle = '#5ee7ff'; ctx.fillRect(0, topPad - 4, xw, 7);
  if (xw > 20) { const hx = (t * 240) % (xw + 60) - 60, x0 = Math.max(0, hx), x1 = Math.min(xw, hx + 60); if (x1 > x0) { ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.fillRect(x0, topPad - 4, x1 - x0, 7); } }

  // здоровье с «хвостом»
  const bw = Math.min(200, W * 0.42), bx = 14, by = topPad + 10;
  ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.fillRect(bx, by, bw, 14);
  ctx.fillStyle = 'rgba(255,255,255,0.75)'; ctx.fillRect(bx, by, bw * Math.max(0, g.hpShow / p.maxHp), 14);
  const hr = Math.max(0, p.hp / p.maxHp);
  ctx.fillStyle = hr > 0.35 ? '#4fe08a' : '#ff4d6d'; ctx.fillRect(bx, by, bw * hr, 14);
  ctx.font = '700 11px system-ui, sans-serif'; ctx.textAlign = 'center';
  ctx.fillStyle = '#fff'; ctx.fillText(Math.ceil(p.hp) + ' / ' + Math.ceil(p.maxHp), bx + bw / 2, by + 7.5);
  ctx.textAlign = 'left'; ctx.font = '600 12px system-ui, sans-serif'; ctx.fillStyle = '#8fa0c4';
  ctx.fillText('Ур. ' + g.lvl, bx, by + 26);

  // время и счёт
  ctx.textAlign = 'center';
  ctx.font = '800 26px system-ui, sans-serif'; ctx.fillStyle = '#e9f1ff';
  ctx.fillText(fmtTime(g.t), W / 2 + 24, topPad + 22);
  ctx.font = '600 12px system-ui, sans-serif'; ctx.fillStyle = '#8fa0c4';
  ctx.fillText('☠ ' + g.kills + '   👑 ' + g.bossKills, W / 2 + 24, topPad + 44);

  // босс (выезжает сверху)
  if (g.boss) {
    const k = easeBack(g.bossBar), w = W * 0.7, x = (W - w) / 2, y = topPad + 62 - (1 - k) * 40;
    ctx.globalAlpha = Math.min(1, g.bossBar * 1.5);
    ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.fillRect(x, y, w, 10);
    ctx.fillStyle = g.boss.col; ctx.fillRect(x, y, w * Math.max(0, g.boss.hp / g.boss.maxHp), 10);
    ctx.font = '700 11px system-ui, sans-serif'; ctx.fillStyle = '#fff'; ctx.fillText('№' + (g.boss.idx + 1) + ' ' + g.boss.name, W / 2, y + 22);
    ctx.globalAlpha = 1;
  }

  // иконки снаряжения
  ctx.font = '15px system-ui, sans-serif'; ctx.textAlign = 'left';
  let ix = 12; const iy = H - 30;
  for (const k in WEAPONS) if (g.w[k] > 0) { ctx.fillStyle = '#fff'; ctx.font = '15px system-ui, sans-serif'; ctx.fillText(WEAPONS[k].icon, ix, iy); ctx.font = '700 10px system-ui, sans-serif'; ctx.fillStyle = '#ffd166'; ctx.fillText(g.w[k], ix + 15, iy + 8); ix += 30; }
  ctx.textAlign = 'right'; ix = W - 12;
  for (const k in PASSIVES) if (g.ps[k] > 0) { ctx.fillStyle = '#fff'; ctx.font = '15px system-ui, sans-serif'; ctx.fillText(PASSIVES[k].icon, ix - 12, iy - 16); ctx.font = '700 10px system-ui, sans-serif'; ctx.fillStyle = '#8fa0c4'; ctx.fillText(g.ps[k], ix, iy - 8); ix -= 28; if (ix < W * 0.4) break; }

  // джойстик
  if (stick.a && g.state === 'run') {
    ctx.beginPath(); ctx.arc(stick.ox, stick.oy, 56, 0, TAU);
    ctx.strokeStyle = 'rgba(94,231,255,0.35)'; ctx.lineWidth = 2; ctx.stroke();
    ctx.fillStyle = 'rgba(94,231,255,0.08)'; ctx.fill();
    ctx.beginPath(); ctx.arc(stick.ox + stick.dx * 56, stick.oy + stick.dy * 56, 22, 0, TAU);
    ctx.fillStyle = 'rgba(94,231,255,0.45)'; ctx.fill();
  }

  // баннер с эффектом появления
  if (g.banner) {
    const b = g.banner, age = b.max - b.life;
    const sc = easeBack(age / 0.35), a = Math.max(0, Math.min(1, b.life / 0.5, age / 0.12));
    ctx.save();
    ctx.globalAlpha = a; ctx.translate(W / 2, H * 0.3); ctx.scale(sc, sc);
    ctx.textAlign = 'center';
    ctx.font = '900 ' + Math.min(32, W / 12) + 'px system-ui, sans-serif';
    ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(7,9,19,0.85)';
    ctx.strokeText(b.text, 0, 0);
    ctx.fillStyle = b.col; ctx.fillText(b.text, 0, 0);
    ctx.restore();
    ctx.globalAlpha = 1;
  }
}

// ================= Интерфейс =================
const SCREENS = ['menu', 'shop', 'heroes', 'beast', 'levelup', 'pause', 'end'];
let curScreen = 'menu';
function showScreen(name) {
  curScreen = name;
  for (const s of SCREENS) $(s).classList.toggle('hidden', s !== name);
  if (name === 'menu') renderMenu();
  if (name === 'shop') renderShop();
  if (name === 'heroes') renderHeroes();
  if (name === 'beast') renderBeast();
}

function renderMenu() {
  $('cores').textContent = S.cores;
  $('heroLine').textContent = 'Герой: ' + HEROES[S.hero].icon + ' ' + HEROES[S.hero].name;
  $('records').textContent = S.bestT ? `Рекорд: ${fmtTime(S.bestT)} · боссов: ${S.bestB} · убийств: ${S.bestK}` : 'Первый забег ещё впереди';
  $('sndBtn').textContent = S.sound ? '🔊 Звук включён' : '🔇 Звук выключен';
}

function renderShop() {
  $('shopCores').textContent = S.cores;
  $('shopList').innerHTML = META.map((m, i) => {
    const lv = S.meta[m.k], max = lv >= m.max, cost = m.cost[lv], can = !max && S.cores >= cost;
    const pips = '●'.repeat(lv) + '○'.repeat(m.max - lv);
    return `<div class="row" style="animation-delay:${i * 0.03}s"><span class="ic">${m.icon}</span><span class="tx"><b>${m.name}</b><em>${m.desc}</em><i>${pips}</i></span><button data-k="${m.k}" ${can ? '' : 'disabled'}>${max ? 'Макс' : '◈ ' + cost}</button></div>`;
  }).join('');
}

function renderHeroes() {
  $('heroCores').textContent = S.cores;
  $('heroList').innerHTML = HEROES.map((h, i) => {
    const own = S.heroes[i], sel = S.hero === i;
    let btn;
    if (sel) btn = '<button disabled>Выбран</button>';
    else if (own) btn = `<button data-h="${i}">Выбрать</button>`;
    else btn = `<button data-h="${i}" ${S.cores >= h.cost ? '' : 'disabled'}>◈ ${h.cost}</button>`;
    return `<div class="row ${sel ? 'sel' : ''}" style="animation-delay:${i * 0.03}s"><span class="ic">${h.icon}</span><span class="tx"><b>${h.name}</b><em>${h.desc}</em></span>${btn}</div>`;
  }).join('');
}

function renderBeast() {
  const n = Object.keys(S.beast).length;
  $('beastCount').textContent = n + ' / 100';
  let html = '';
  for (let i = 0; i < 100; i++) {
    const d = bossDef(i), ok = !!S.beast[i];
    html += `<div class="row ${ok ? '' : 'lock'}"><span class="ic" style="color:${ok ? d.col : '#4a5578'}">◆</span><span class="tx"><b>${ok ? d.name : '???'}</b><em>${ok ? '№' + (i + 1) + ' · ' + d.pats.map(x => P_NAME[x]).join(', ') : 'Босс №' + (i + 1) + ' · не побеждён'}</em></span></div>`;
  }
  $('beastList').innerHTML = html;
}

$('shopList').addEventListener('click', e => {
  const b = e.target.closest ? e.target.closest('button[data-k]') : null;
  if (!b) return;
  const m = META.find(x => x.k === b.dataset.k);
  const lv = S.meta[m.k];
  if (lv >= m.max || S.cores < m.cost[lv]) return;
  S.cores -= m.cost[lv]; S.meta[m.k]++; persist(); sfx('level'); renderShop();
});
$('heroList').addEventListener('click', e => {
  const b = e.target.closest ? e.target.closest('button[data-h]') : null;
  if (!b) return;
  const i = +b.dataset.h, h = HEROES[i];
  if (!S.heroes[i]) { if (S.cores < h.cost) return; S.cores -= h.cost; S.heroes[i] = true; }
  S.hero = i; persist(); sfx('click'); renderHeroes();
});
$('cards').addEventListener('click', e => {
  const b = e.target.closest ? e.target.closest('button[data-i]') : null;
  if (b) pickChoice(+b.dataset.i);
});
$('reroll').addEventListener('click', rerollChoices);

$('play').addEventListener('click', () => { initAudio(); sfx('click'); startRun(); });
$('again').addEventListener('click', () => { initAudio(); startRun(); });
$('toShop').addEventListener('click', () => { sfx('click'); showScreen('shop'); });
$('toHeroes').addEventListener('click', () => { sfx('click'); showScreen('heroes'); });
$('toBeast').addEventListener('click', () => { sfx('click'); showScreen('beast'); });
$('toMenu').addEventListener('click', () => { G = null; showScreen('menu'); });
$('sndBtn').addEventListener('click', () => { S.sound = !S.sound; persist(); renderMenu(); if (S.sound) { initAudio(); sfx('click'); } });
document.querySelectorAll('[data-back]').forEach(b => b.addEventListener('click', () => showScreen('menu')));

function pauseGame() {
  if (!G || G.state !== 'run') return;
  G.state = 'paused'; stick.a = false; stick.dx = stick.dy = 0;
  showScreen('pause');
}
function resumeGame() {
  if (!G || G.state !== 'paused') return;
  G.state = 'run'; showScreen(null);
}
$('pauseBtn').addEventListener('click', pauseGame);
$('resume').addEventListener('click', resumeGame);
$('quit').addEventListener('click', () => { if (G) { G.state = 'run'; endRun(); } });

window.__back = () => {
  if (G && G.state === 'run') { pauseGame(); return 'handled'; }
  if (G && G.state === 'paused') { resumeGame(); return 'handled'; }
  if (G && (G.state === 'levelup' || G.state === 'dead')) return 'handled';
  if (curScreen === 'shop' || curScreen === 'heroes' || curScreen === 'beast' || curScreen === 'end') { G = null; showScreen('menu'); return 'handled'; }
  return 'exit';
};

// ================= Главный цикл =================
let last = 0;
function frame(now) {
  const dt = Math.min(0.05, Math.max(0, (now - last) / 1000));
  last = now;
  bgT += dt;
  update(dt);
  render();
  requestAnimationFrame(frame);
}

resize();
showScreen('menu');
requestAnimationFrame(t => { last = t; requestAnimationFrame(frame); });

window.__NS = { start: startRun, step: update, pick: pickChoice, reroll: rerollChoices, spawnBoss, bossDef, get G() { return G; }, render, S, HEROES, WEAPONS, PASSIVES };
})();
