(() => {
'use strict';

const N = 8, TAU = Math.PI * 2;
const HUES = [350, 28, 48, 150, 195, 232, 280]; // роза, мандарин, лимон, мята, небо, индиго, сирень
const BOMB_C = 7;
const $ = id => document.getElementById(id);
const cv = $('c');
const ctx = cv.getContext('2d');
let W = 360, H = 560, dpr = 1, cell = 40, bx = 0, by = 46, bw = 320, ty = 400, ts = 24;
let T = 0;
let SP = null;

const clamp01 = x => Math.max(0, Math.min(1, x));
const easeOut = x => 1 - Math.pow(1 - clamp01(x), 3);
const easeBack = x => { x = clamp01(x); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); };
const lerp = (a, b, k) => a + (b - a) * k;

// ================= Фигуры =================
const BASE = [
  { m: ['#'],                    w: 0.55 },
  { m: ['##'],                   w: 1,    rot: 1 },
  { m: ['###'],                  w: 1,    rot: 1 },
  { m: ['####'],                 w: 0.8,  rot: 1 },
  { m: ['#####'],                w: 0.45, rot: 1 },
  { m: ['##', '##'],             w: 1.2 },
  { m: ['###', '###', '###'],    w: 0.5 },
  { m: ['###', '###'],           w: 1,    rot: 1 },
  { m: ['#.', '##'],             w: 1.1,  rot: 1 },
  { m: ['#..', '#..', '###'],    w: 0.7,  rot: 1 },
  { m: ['###', '.#.'],           w: 1,    rot: 1 },
  { m: ['.##', '##.'],           w: 0.9,  rot: 1 },
  { m: ['##.', '.##'],           w: 0.9,  rot: 1 },
  { m: ['#.', '#.', '##'],       w: 0.9,  rot: 1 },
  { m: ['.#', '.#', '##'],       w: 0.9,  rot: 1 },
  { m: ['#.#', '###'],           w: 0.5,  rot: 1 },
  { m: ['#.', '.#'],             w: 0.55, rot: 1 },
  { m: ['#..', '.#.', '..#'],    w: 0.3,  rot: 1 },
  { m: ['.#.', '###', '.#.'],    w: 0.3 },
  { m: ['##', '#.', '##'],       w: 0.5,  rot: 1 },
];
function toMatrix(rows) { return rows.map(r => [...r].map(ch => (ch === '#' ? 1 : 0))); }
function rotate(m) {
  const R = m.length, C = m[0].length, out = Array.from({ length: C }, () => Array(R).fill(0));
  for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) out[c][R - 1 - r] = m[r][c];
  return out;
}
const SHAPES = [];
{
  const seen = new Set();
  for (const b of BASE) {
    let m = toMatrix(b.m);
    for (let i = 0; i < (b.rot ? 4 : 1); i++) {
      const key = m.map(r => r.join('')).join('/');
      if (!seen.has(key)) {
        seen.add(key);
        SHAPES.push({ m, w: b.w, n: m.reduce((a, r) => a + r.reduce((x, y) => x + y, 0), 0) });
      }
      m = rotate(m);
    }
  }
}
const SINGLE = SHAPES.findIndex(s => s.n === 1);

// ================= Состояние =================
const SKEY = 'blockblast_glass_v1', BKEY = 'blockblast_glass_best', MKEY = 'blockblast_glass_sound';
let G = null;
let best = 0, soundOn = true;
try { best = parseInt(localStorage.getItem(BKEY) || '0', 10) || 0; } catch (e) {}
try { soundOn = localStorage.getItem(MKEY) !== '0'; } catch (e) {}

const cloneGrid = g => g.map(r => r.map(v => (v ? { c: v.c, sp: v.sp, born: -9 } : null)));
const clonePieces = ps => ps.map(p => Object.assign({}, p));
const emptyGrid = () => Array.from({ length: N }, () => Array(N).fill(null));
const levelOf = s => 1 + Math.floor(s / 1500);

function canPlace(m, gx, gy) {
  for (let r = 0; r < m.length; r++) for (let c = 0; c < m[0].length; c++) {
    if (!m[r][c]) continue;
    const x = gx + c, y = gy + r;
    if (x < 0 || y < 0 || x >= N || y >= N || G.grid[y][x]) return false;
  }
  return true;
}
function fitsAnywhere(m) {
  for (let y = 0; y <= N - m.length; y++) for (let x = 0; x <= N - m[0].length; x++) if (canPlace(m, x, y)) return true;
  return false;
}
function fillRatio() { let n = 0; for (const r of G.grid) for (const v of r) if (v) n++; return n / (N * N); }

// ---- умная раздача: чаще даёт фигуры, которые закрывают линии ----
function findHelper() {
  const rowCnt = Array(N).fill(0), colCnt = Array(N).fill(0);
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) if (G.grid[y][x]) { rowCnt[y]++; colCnt[x]++; }
  const order = SHAPES.map((s, i) => i).sort(() => Math.random() - 0.5);
  for (const si of order) {
    const m = SHAPES[si].m;
    if (SHAPES[si].n < 2 && Math.random() < 0.7) continue;
    const rowCells = m.map(r => r.reduce((a, v) => a + v, 0));
    const colCells = m[0].map((_, c) => m.reduce((a, r) => a + r[c], 0));
    for (let y = 0; y <= N - m.length; y++) for (let x = 0; x <= N - m[0].length; x++) {
      if (!canPlace(m, x, y)) continue;
      for (let r = 0; r < m.length; r++) if (rowCells[r] && rowCnt[y + r] + rowCells[r] === N) return si;
      for (let c = 0; c < m[0].length; c++) if (colCells[c] && colCnt[x + c] + colCells[c] === N) return si;
    }
  }
  return -1;
}

function randShape(fr) {
  let sum = 0; const ws = SHAPES.map(s => {
    let w = s.w;
    if (fr > 0.55) w *= s.n <= 4 ? 1.7 : s.n >= 7 ? 0.35 : 1;
    if (fr < 0.25 && s.n <= 2) w *= 0.5;
    sum += w; return w;
  });
  let r = Math.random() * sum;
  for (let i = 0; i < ws.length; i++) { r -= ws[i]; if (r <= 0) return i; }
  return 0;
}

function makePiece(si) {
  const sh = SHAPES[si];
  return { s: si, c: Math.floor(Math.random() * 7), star: (sh.n >= 2 && Math.random() < 0.2) ? Math.floor(Math.random() * sh.n) : -1, bomb: false, used: false, dead: false };
}

function updateDead() { for (const p of G.pieces) p.dead = !p.used && !fitsAnywhere(SHAPES[p.s].m); }

function genTray(forceHelper) {
  const fr = fillRatio();
  const ps = [makePiece(randShape(fr)), makePiece(randShape(fr)), makePiece(randShape(fr))];
  if (Math.random() < (forceHelper ? 1 : 0.7)) {
    const h = findHelper();
    if (h >= 0) ps[Math.floor(Math.random() * 3)] = makePiece(h);
  }
  if (G.score > 300 && Math.random() < 0.06) {
    const b = makePiece(SINGLE); b.bomb = true; b.c = BOMB_C; b.star = -1;
    ps[Math.floor(Math.random() * 3)] = b;
  }
  G.pieces = ps;
  if (!ps.some(p => fitsAnywhere(SHAPES[p.s].m))) { // всегда даём шанс сходить
    const small = SHAPES.map((s, i) => i).sort((a, b) => SHAPES[a].n - SHAPES[b].n);
    for (const si of small) if (fitsAnywhere(SHAPES[si].m)) { ps[0] = makePiece(si); break; }
  }
  updateDead();
}

function newGame() {
  G = {
    grid: emptyGrid(), pieces: [], score: 0, shown: 0, streak: 0, miss: 0, undo: 3, shuf: 2,
    lvl: 1, over: false, moved: false, hist: [], shake: 0, anims: [], parts: [], pops: [], overT: 0,
  };
  genTray(true);
  hideOver();
  syncUi(true);
  setBg();
  save();
}

function save() {
  try {
    if (G.over) { localStorage.removeItem(SKEY); return; }
    localStorage.setItem(SKEY, JSON.stringify({
      grid: G.grid.map(r => r.map(v => (v ? [v.c, v.sp || ''] : 0))),
      pieces: G.pieces, score: G.score, streak: G.streak, miss: G.miss, undo: G.undo, shuf: G.shuf, moved: G.moved,
    }));
  } catch (e) {}
}
function load() {
  try {
    const d = JSON.parse(localStorage.getItem(SKEY));
    if (!d || !d.grid || d.grid.length !== N || !d.pieces || d.pieces.length !== 3) return false;
    if (d.pieces.some(p => p.s >= SHAPES.length)) return false;
    G = {
      grid: d.grid.map(r => r.map(v => (v ? { c: v[0], sp: v[1] || null, born: -9 } : null))),
      pieces: d.pieces, score: d.score, shown: d.score, streak: d.streak, miss: d.miss, undo: d.undo, shuf: d.shuf,
      lvl: levelOf(d.score), over: false, moved: !!d.moved, hist: [], shake: 0, anims: [], parts: [], pops: [], overT: 0,
    };
    updateDead();
    if (G.pieces.every(p => p.used || p.dead)) return false;
    syncUi(true); setBg();
    return true;
  } catch (e) { return false; }
}

// ================= Звук =================
let actx = null;
function initAudio() { try { if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)(); else if (actx.state === 'suspended') actx.resume(); } catch (e) {} }
function tone(f, d, type, v, delay, slide) {
  if (!soundOn || !actx) return;
  try {
    const t0 = actx.currentTime + (delay || 0), o = actx.createOscillator(), g = actx.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t0);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, f * slide), t0 + d);
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(v || 0.08, t0 + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    o.connect(g); g.connect(actx.destination); o.start(t0); o.stop(t0 + d + 0.03);
  } catch (e) {}
}
const SCALE = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24, 26];
const note = i => 261.63 * Math.pow(2, SCALE[Math.min(Math.max(0, i), SCALE.length - 1)] / 12);
function sfx(name, a) {
  switch (name) {
    case 'pick':  tone(520, 0.05, 'sine', 0.05); break;
    case 'place': tone(note(2), 0.14, 'triangle', 0.09); tone(note(2) * 0.5, 0.18, 'sine', 0.06); break;
    case 'bad':   tone(150, 0.12, 'sine', 0.07, 0, 0.7); break;
    case 'clear': for (let i = 0; i < Math.min(8, 3 + (a || 1) * 2); i++) tone(note(i + Math.min(G.streak, 4)), 0.28, 'sine', 0.085, i * 0.06); break;
    case 'bomb':  tone(90, 0.35, 'sine', 0.2, 0, 0.3); tone(180, 0.2, 'sawtooth', 0.05, 0, 0.4); break;
    case 'star':  tone(1318, 0.18, 'triangle', 0.06); tone(1760, 0.22, 'triangle', 0.05, 0.07); break;
    case 'level': [0, 2, 4, 7, 9, 12].forEach((s, i) => tone(note(s / 2 + i), 0.3, 'triangle', 0.08, i * 0.08)); break;
    case 'perfect': [0, 4, 7, 12, 16, 19, 24].forEach((s, i) => tone(261.63 * Math.pow(2, s / 12), 0.4, 'triangle', 0.08, i * 0.07)); break;
    case 'click': tone(640, 0.05, 'sine', 0.05); break;
    case 'undo':  tone(500, 0.08, 'triangle', 0.06, 0, 0.6); break;
    case 'shuffle': tone(400, 0.06, 'triangle', 0.06); tone(600, 0.06, 'triangle', 0.06, 0.06); tone(900, 0.08, 'triangle', 0.06, 0.12); break;
    case 'over':  [392, 330, 262, 196].forEach((f, i) => tone(f, 0.4, 'sine', 0.08, i * 0.16)); break;
  }
}
function buzz(ms) { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) {} }

// ================= Спрайты «мягкого стекла» =================
function rr(c, x, y, w, h, r) {
  c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
}
function newCanvas(n) { const c = document.createElement('canvas'); c.width = c.height = n; return c; }

function makeBlock(h, sp, pad, tot) {
  const cv2 = newCanvas(tot), g = cv2.getContext('2d');
  const x = pad + sp * 0.045, w = sp * 0.91, r = sp * 0.27;
  const col = (l, a, s) => h === null ? `hsla(258,22%,${Math.max(8, l - 38)}%,${a})` : `hsla(${h},${s || 92}%,${l}%,${a})`;
  g.save(); g.shadowColor = col(66, 0.7); g.shadowBlur = sp * 0.3; g.fillStyle = col(60, 0.55); rr(g, x, x, w, w, r); g.fill(); g.restore();
  const body = g.createLinearGradient(0, x, 0, x + w);
  body.addColorStop(0, col(82, 0.93)); body.addColorStop(0.5, col(66, 0.86)); body.addColorStop(1, col(54, 0.85));
  rr(g, x, x, w, w, r); g.fillStyle = body; g.fill();
  g.save(); rr(g, x, x, w, w, r); g.clip();
  const refr = g.createRadialGradient(x + w / 2, x + w * 1.08, 0, x + w / 2, x + w * 1.08, w * 0.85);
  refr.addColorStop(0, col(88, 0.6)); refr.addColorStop(1, col(88, 0));
  g.fillStyle = refr; g.fillRect(x, x, w, w);
  const spec = g.createRadialGradient(x + w * 0.3, x + w * 0.22, 0, x + w * 0.3, x + w * 0.22, w * 0.6);
  spec.addColorStop(0, 'rgba(255,255,255,0.8)'); spec.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = spec; g.fillRect(x, x, w, w);
  g.restore();
  rr(g, x + w * 0.15, x + w * 0.07, w * 0.7, w * 0.1, w * 0.05); g.fillStyle = 'rgba(255,255,255,0.42)'; g.fill();
  const edge = g.createLinearGradient(x, x, x + w, x + w);
  edge.addColorStop(0, 'rgba(255,255,255,0.9)'); edge.addColorStop(0.5, 'rgba(255,255,255,0.18)'); edge.addColorStop(1, 'rgba(255,255,255,0.45)');
  rr(g, x + 0.8, x + 0.8, w - 1.6, w - 1.6, r); g.lineWidth = Math.max(1.2, sp * 0.036); g.strokeStyle = edge; g.stroke();
  return cv2;
}

function makeStar(sp, pad, tot) {
  const cv2 = newCanvas(tot), g = cv2.getContext('2d');
  const cx = tot / 2, cy = tot / 2, R = sp * 0.3, r = R * 0.45;
  g.save(); g.shadowColor = 'rgba(255,230,140,0.95)'; g.shadowBlur = sp * 0.25;
  g.beginPath();
  for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rad = i % 2 ? r : R; g.lineTo(cx + Math.cos(a) * rad, cy + Math.sin(a) * rad); }
  g.closePath();
  const gr = g.createLinearGradient(0, cy - R, 0, cy + R); gr.addColorStop(0, '#ffffff'); gr.addColorStop(1, '#ffd45e');
  g.fillStyle = gr; g.fill(); g.restore();
  g.lineWidth = Math.max(1, sp * 0.02); g.strokeStyle = 'rgba(255,255,255,0.9)'; g.stroke();
  return cv2;
}

function makeBombIcon(sp, pad, tot) {
  const cv2 = newCanvas(tot), g = cv2.getContext('2d');
  const cx = tot / 2, cy = tot / 2 + sp * 0.04, R = sp * 0.26;
  const gr = g.createRadialGradient(cx - R * 0.35, cy - R * 0.4, R * 0.1, cx, cy, R);
  gr.addColorStop(0, '#9a8cc4'); gr.addColorStop(0.5, '#3a2f62'); gr.addColorStop(1, '#171233');
  g.beginPath(); g.arc(cx, cy, R, 0, TAU); g.fillStyle = gr; g.fill();
  g.lineWidth = Math.max(1, sp * 0.02); g.strokeStyle = 'rgba(255,255,255,0.55)'; g.stroke();
  g.beginPath(); g.arc(cx - R * 0.35, cy - R * 0.38, R * 0.22, 0, TAU); g.fillStyle = 'rgba(255,255,255,0.7)'; g.fill();
  g.beginPath(); g.moveTo(cx + R * 0.45, cy - R * 0.8); g.quadraticCurveTo(cx + R * 0.9, cy - R * 1.3, cx + R * 1.2, cy - R * 1.05);
  g.lineWidth = Math.max(1.5, sp * 0.04); g.strokeStyle = '#ffd89a'; g.stroke();
  g.save(); g.shadowColor = '#ffb04d'; g.shadowBlur = sp * 0.18; g.beginPath(); g.arc(cx + R * 1.2, cy - R * 1.05, sp * 0.045, 0, TAU); g.fillStyle = '#fff3c4'; g.fill(); g.restore();
  return cv2;
}

function buildSprites() {
  const sp = Math.max(8, Math.round(cell * dpr)), pad = Math.round(sp * 0.22), tot = sp + pad * 2;
  const blocks = HUES.map(h => makeBlock(h, sp, pad, tot));
  blocks.push(makeBlock(null, sp, pad, tot));
  SP = { sp, pad, tot, blocks, star: makeStar(sp, pad, tot), bomb: makeBombIcon(sp, pad, tot) };
}

function sprite(img, x, y, size, alpha) {
  const k = size / cell, d = SP.tot / dpr * k, o = SP.pad / dpr * k;
  ctx.globalAlpha = alpha === undefined ? 1 : alpha;
  ctx.drawImage(img, x - o, y - o, d, d);
}

// ================= Экран и раскладка =================
function resize() {
  dpr = Math.min(window.devicePixelRatio || 1, 3);
  W = cv.clientWidth || window.innerWidth; H = cv.clientHeight || window.innerHeight;
  cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
  cell = Math.max(24, Math.floor(Math.min((W - 30) / N, (H - 84) / 11.6)));
  bw = cell * N; bx = Math.round((W - bw) / 2); by = 44;
  ty = by + bw + 24;
  ts = Math.min(cell * 0.62, (W / 3 - 14) / 5);
  buildSprites();
}
function trayCenter(i) { return { x: (W / 3) * (i + 0.5), y: ty + Math.max((H - ty) / 2, ts * 2.4) }; }

// ================= Эффекты =================
function spark(x, y, hue, n, spd, kind) {
  for (let i = 0; i < n && G.parts.length < 380; i++) {
    const a = Math.random() * TAU, v = spd * (0.35 + Math.random() * 0.9);
    G.parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - spd * 0.25, life: 0.5 + Math.random() * 0.5, max: 1, hue, size: 2 + Math.random() * 3.5, k: kind === undefined ? (Math.random() < 0.4 ? 1 : 0) : kind, rot: Math.random() * TAU });
  }
}
function pop(text, x, y, col, big) { G.pops.push({ text, x, y, t: 0, max: big ? 1.5 : 1.1, col: col || '#fff', big: !!big }); }

// ================= Ход =================
function snapshot() {
  G.hist.push({ grid: cloneGrid(G.grid), pieces: clonePieces(G.pieces), score: G.score, streak: G.streak, miss: G.miss, lvl: G.lvl });
  if (G.hist.length > 5) G.hist.shift();
}

function linesAfter(m, gx, gy) {
  const occ = G.grid.map(r => r.map(v => !!v));
  for (let r = 0; r < m.length; r++) for (let c = 0; c < m[0].length; c++) if (m[r][c]) occ[gy + r][gx + c] = true;
  const rows = [], cols = [];
  for (let y = 0; y < N; y++) if (occ[y].every(v => v)) rows.push(y);
  for (let x = 0; x < N; x++) if (occ.every(row => row[x])) cols.push(x);
  return { rows, cols };
}

function placePiece(i, gx, gy) {
  const g = G, p = g.pieces[i], m = SHAPES[p.s].m;
  if (!canPlace(m, gx, gy)) return false;
  snapshot();
  g.moved = true;
  let ord = 0, cells = 0, cx = 0, cy = 0;
  for (let r = 0; r < m.length; r++) for (let c = 0; c < m[0].length; c++) {
    if (!m[r][c]) continue;
    g.grid[gy + r][gx + c] = { c: p.c, sp: p.bomb ? 'bomb' : (ord === p.star ? 'star' : null), born: T };
    ord++; cells++; cx += gx + c + 0.5; cy += gy + r + 0.5;
  }
  cx /= cells; cy /= cells;
  p.used = true;
  let pts = cells * 3;

  // что сгорает
  const rows = [], cols = [];
  for (let y = 0; y < N; y++) if (g.grid[y].every(v => v)) rows.push(y);
  for (let x = 0; x < N; x++) if (g.grid.every(row => row[x])) cols.push(x);
  const n = rows.length + cols.length;
  const clear = new Set();
  rows.forEach(y => { for (let x = 0; x < N; x++) clear.add(y * N + x); });
  cols.forEach(x => { for (let y = 0; y < N; y++) clear.add(y * N + x); });
  let bombCells = 0;
  if (p.bomb) {
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      const x = gx + dx, y = gy + dy;
      if (x >= 0 && y >= 0 && x < N && y < N && g.grid[y][x] && !clear.has(y * N + x)) { clear.add(y * N + x); bombCells++; }
    }
  }

  // бонус за однотонные линии
  let mono = 0;
  const lineCells = [];
  rows.forEach(y => lineCells.push(Array.from({ length: N }, (_, x) => g.grid[y][x])));
  cols.forEach(x => lineCells.push(Array.from({ length: N }, (_, y) => g.grid[y][x])));
  for (const L of lineCells) if (L.every(v => v.c === L[0].c && v.c !== BOMB_C)) mono++;

  let stars = 0;
  for (const k of clear) { const v = g.grid[Math.floor(k / N)][k % N]; if (v && v.sp === 'star') stars++; }

  const hit = n > 0 || p.bomb;
  if (hit) { g.streak++; g.miss = 0; } else { g.miss++; if (g.miss >= 3) g.streak = 0; }
  const mult = Math.min(3, 1 + 0.25 * (Math.min(g.streak, 9) - 1));

  if (n > 0) {
    const base = [0, 60, 170, 340, 560, 850][Math.min(n, 5)];
    pts += Math.round(base * mult) + mono * 60;
  }
  pts += stars * 100 + bombCells * 8;

  // анимации исчезновения (волной от места постановки)
  for (const k of clear) {
    const y = Math.floor(k / N), x = k % N, v = g.grid[y][x];
    const dist = Math.hypot(x + 0.5 - cx, y + 0.5 - cy);
    g.anims.push({ x, y, c: v.c, sp: v.sp, t: -dist * 0.045, max: 0.5, born: v.born, fx: false });
    g.grid[y][x] = null;
  }

  // перфект
  const perfect = clear.size > 0 && g.grid.every(r => r.every(v => !v));
  if (perfect) pts += 600;

  g.score += pts;
  const mx = bx + cx * cell, my = by + cy * cell;

  if (clear.size) {
    sfx('clear', Math.max(1, n));
    buzz(n >= 3 ? 60 : 30);
    g.shake = Math.min(9, 2 + n * 2);
    if (p.bomb) sfx('bomb');
    if (stars) sfx('star');
    pop('+' + pts, mx, my - cell, '#ffe9a8', n >= 3);
    const words = ['', '', 'Отлично!', 'Супер!', 'Невероятно!', 'Легенда!'];
    if (n >= 2) pop(words[Math.min(n, 5)], W / 2, by + bw * 0.34, '#ffffff', true);
    if (g.streak >= 2) pop('Серия ×' + g.streak, W / 2, by + bw * 0.34 + (n >= 2 ? 42 : 0), '#9ff3ff');
    if (mono) pop('Один цвет! +' + mono * 60, W / 2, by + bw * 0.34 + 78, '#ffd0f0');
    if (n >= 3 && g.undo < 5) { g.undo++; pop('+1 отмена', W / 2, ty - 12, '#ffe08a'); }
  } else {
    sfx('place');
    buzz(10);
    if (pts) pop('+' + pts, bx + cx * cell, by + cy * cell - cell, '#ffffff');
  }
  if (perfect) {
    sfx('perfect'); g.shake = 11; buzz(120);
    pop('ИДЕАЛЬНО! +600', W / 2, by + bw * 0.5, '#ffe08a', true);
    if (g.undo < 5) g.undo++;
    if (g.shuf < 5) g.shuf++;
    for (let k = 0; k < 6; k++) spark(bx + Math.random() * bw, by + Math.random() * bw, HUES[k], 14, 280, 1);
  }

  // уровень
  const nl = levelOf(g.score);
  if (nl > g.lvl) {
    g.lvl = nl;
    sfx('level');
    pop('Уровень ' + nl + '!', W / 2, by - 6, '#ffe08a', true);
    if (g.shuf < 5) { g.shuf++; pop('+1 новые фигуры', W / 2, by + 26, '#ffe08a'); }
    setBg();
  }

  if (g.pieces.every(q => q.used)) genTray(false); else updateDead();

  if (g.score > best) { best = g.score; try { localStorage.setItem(BKEY, String(best)); } catch (e) {} }

  syncUi(false);
  if (g.pieces.every(q => q.used || q.dead)) {
    g.over = true; g.overT = 0.9; save();
    sfx('over');
  } else save();
  return true;
}

function undo() {
  const g = G;
  if (!g || g.undo <= 0 || !g.hist.length) return;
  const s = g.hist.pop();
  g.undo--; g.over = false; g.overT = 0;
  g.grid = s.grid; g.pieces = s.pieces; g.score = s.score; g.streak = s.streak; g.miss = s.miss;
  g.anims = []; g.lvl = levelOf(g.score);
  hideOver(); updateDead(); sfx('undo'); syncUi(false); setBg(); save();
}

function shuffleTray() {
  const g = G;
  if (!g || g.over || g.shuf <= 0) return;
  g.shuf--;
  genTray(true);
  for (let i = 0; i < 3; i++) { const c = trayCenter(i); spark(c.x, c.y, 48, 10, 160, 1); }
  sfx('shuffle'); syncUi(false); save();
  if (g.pieces.every(q => q.used || q.dead)) { g.over = true; g.overT = 0.6; sfx('over'); }
}

// ================= Ввод =================
let drag = null;
function pos(e) { const r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
function dragCenter() { return { x: drag.x, y: drag.y - cell * 2.2 }; }
function dragTarget() {
  const m = SHAPES[G.pieces[drag.i].s].m, c = dragCenter();
  const gx = Math.round((c.x - bx) / cell - m[0].length / 2), gy = Math.round((c.y - by) / cell - m.length / 2);
  return { gx, gy, ok: canPlace(m, gx, gy) };
}

cv.addEventListener('pointerdown', e => {
  initAudio();
  if (!G || G.over || drag) return;
  const { x, y } = pos(e);
  if (y < ty - cell * 0.6) return;
  const i = Math.min(2, Math.max(0, Math.floor(x / (W / 3))));
  if (G.pieces[i].used) return;
  drag = { i, x, y, id: e.pointerId, t0: T };
  try { cv.setPointerCapture(e.pointerId); } catch (err) {}
  sfx('pick');
  if (e.preventDefault) e.preventDefault();
});
cv.addEventListener('pointermove', e => {
  if (!drag || e.pointerId !== drag.id) return;
  const { x, y } = pos(e); drag.x = x; drag.y = y;
  if (e.preventDefault) e.preventDefault();
});
function endDrag(e, cancel) {
  if (!drag || e.pointerId !== drag.id) return;
  const t = dragTarget(), i = drag.i;
  drag = null;
  if (cancel) return;
  if (t.ok) placePiece(i, t.gx, t.gy);
  else if (Math.abs(t.gx) < 20) sfx('bad');
}
cv.addEventListener('pointerup', e => endDrag(e, false));
cv.addEventListener('pointercancel', e => endDrag(e, true));

$('undo').addEventListener('click', () => { initAudio(); undo(); });
$('shuffle').addEventListener('click', () => { initAudio(); shuffleTray(); });
$('restart').addEventListener('click', () => { initAudio(); sfx('click'); newGame(); });
$('again').addEventListener('click', () => { initAudio(); sfx('click'); newGame(); });
$('undo2').addEventListener('click', () => { initAudio(); undo(); });
$('sound').addEventListener('click', () => {
  soundOn = !soundOn; $('sound').textContent = soundOn ? '🔊' : '🔇';
  try { localStorage.setItem(MKEY, soundOn ? '1' : '0'); } catch (e) {}
  if (soundOn) { initAudio(); sfx('click'); }
});
document.addEventListener('contextmenu', e => e.preventDefault());
window.addEventListener('resize', resize);
window.addEventListener('orientationchange', () => setTimeout(resize, 150));
window.__back = () => 'exit';

// ================= Интерфейс =================
let lastShown = -1;
function syncUi(instant) {
  if (instant) { G.shown = G.score; lastShown = -1; }
  $('best').textContent = best;
  $('lvl').textContent = 'Уровень ' + G.lvl;
  $('undoN').textContent = G.undo; $('shufN').textContent = G.shuf;
  $('undo').disabled = G.undo <= 0 || !G.hist.length;
  $('shuffle').disabled = G.shuf <= 0;
  $('sound').textContent = soundOn ? '🔊' : '🔇';
}
function setBg() { try { $('bg').style.filter = 'hue-rotate(' + ((G.lvl - 1) * 38 % 360) + 'deg)'; } catch (e) {} }
function showOver() {
  $('finalScore').textContent = G.score;
  $('finalNote').textContent = G.score >= best && G.score > 0 ? 'Новый рекорд!' : 'Рекорд: ' + best;
  $('undo2N').textContent = G.undo;
  $('undo2').disabled = G.undo <= 0 || !G.hist.length;
  $('over').classList.remove('hidden');
}
function hideOver() { $('over').classList.add('hidden'); }

// ================= Отрисовка =================
function drawPieceCells(p, ox, oy, size, alpha, t) {
  const m = SHAPES[p.s].m;
  let ord = 0;
  for (let r = 0; r < m.length; r++) for (let c = 0; c < m[0].length; c++) {
    if (!m[r][c]) continue;
    const x = ox + c * size, y = oy + r * size;
    sprite(SP.blocks[p.c], x, y, size, alpha);
    if (p.bomb) sprite(SP.bomb, x, y, size * (1 + 0.04 * Math.sin(t * 6)), alpha);
    else if (ord === p.star) sprite(SP.star, x, y, size * (1 + 0.08 * Math.sin(t * 4 + 1)), alpha);
    ord++;
  }
  ctx.globalAlpha = 1;
}

function render() {
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, W, H);
  if (!G) return;
  const g = G;
  const sx = g.shake > 0 ? (Math.random() - 0.5) * g.shake : 0, sy = g.shake > 0 ? (Math.random() - 0.5) * g.shake : 0;
  ctx.translate(sx, sy);

  // стеклянная панель поля
  const pad = 11;
  const pg = ctx.createLinearGradient(bx, by, bx + bw, by + bw);
  pg.addColorStop(0, 'rgba(255,255,255,0.20)'); pg.addColorStop(1, 'rgba(255,255,255,0.06)');
  rr(ctx, bx - pad, by - pad, bw + pad * 2, bw + pad * 2, 26); ctx.fillStyle = pg; ctx.fill();
  const eg = ctx.createLinearGradient(bx, by, bx + bw, by + bw);
  eg.addColorStop(0, 'rgba(255,255,255,0.65)'); eg.addColorStop(0.5, 'rgba(255,255,255,0.14)'); eg.addColorStop(1, 'rgba(255,255,255,0.3)');
  ctx.lineWidth = 1.5; ctx.strokeStyle = eg; ctx.stroke();

  // пустые ячейки
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const alt = ((x >> 2) + (y >> 2)) & 1;
    rr(ctx, bx + x * cell + 2, by + y * cell + 2, cell - 4, cell - 4, cell * 0.22);
    ctx.fillStyle = alt ? 'rgba(255,255,255,0.095)' : 'rgba(255,255,255,0.055)'; ctx.fill();
    ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,0.10)'; ctx.stroke();
  }

  // подсветка линий, которые сгорят, и зона бомбы
  let target = null;
  if (drag) {
    target = dragTarget();
    if (target.ok) {
      const p = g.pieces[drag.i], m = SHAPES[p.s].m;
      const { rows, cols } = linesAfter(m, target.gx, target.gy);
      const hue = p.bomb ? 30 : HUES[p.c], a = 0.16 + 0.1 * Math.sin(T * 7);
      ctx.fillStyle = `hsla(${hue},95%,75%,${a})`;
      for (const y of rows) { rr(ctx, bx + 1, by + y * cell + 1, bw - 2, cell - 2, cell * 0.25); ctx.fill(); }
      for (const x of cols) { rr(ctx, bx + x * cell + 1, by + 1, cell - 2, bw - 2, cell * 0.25); ctx.fill(); }
      if (p.bomb) { rr(ctx, bx + (target.gx - 1) * cell, by + (target.gy - 1) * cell, cell * 3, cell * 3, cell * 0.3); ctx.fillStyle = 'rgba(255,160,80,0.18)'; ctx.fill(); }
    }
  }

  // занятые ячейки
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const v = g.grid[y][x];
    if (!v) continue;
    const age = T - v.born, sc = age < 0.32 ? 0.72 + 0.28 * easeBack(age / 0.32) : 1;
    const size = cell * sc, off = (cell - size) / 2;
    sprite(SP.blocks[v.c], bx + x * cell + off, by + y * cell + off, size);
    if (v.sp === 'bomb') sprite(SP.bomb, bx + x * cell + off, by + y * cell + off, size);
    else if (v.sp === 'star') sprite(SP.star, bx + x * cell + off, by + y * cell + off, size * (1 + 0.08 * Math.sin(T * 4 + x + y)));
    if (age < 0.28) { // вспышка при посадке
      rr(ctx, bx + x * cell + off + 2, by + y * cell + off + 2, size - 4, size - 4, cell * 0.22);
      ctx.fillStyle = `rgba(255,255,255,${0.45 * (1 - age / 0.28)})`; ctx.fill();
    }
  }
  ctx.globalAlpha = 1;

  // тень-призрак
  if (drag && target && target.ok) {
    const p = g.pieces[drag.i];
    drawPieceCells(p, bx + target.gx * cell, by + target.gy * cell, cell, 0.42, T);
  }

  // исчезающие ячейки
  for (const a of g.anims) {
    const x = bx + a.x * cell, y = by + a.y * cell;
    if (a.t < 0) { sprite(SP.blocks[a.c], x, y, cell); if (a.sp === 'star') sprite(SP.star, x, y, cell); if (a.sp === 'bomb') sprite(SP.bomb, x, y, cell); continue; }
    const p = a.t / a.max;
    const sc = p < 0.18 ? 1 + 0.18 * (p / 0.18) : Math.max(0, 1 - Math.pow((p - 0.18) / 0.82, 1.6));
    const size = cell * sc, off = (cell - size) / 2;
    if (size > 1) {
      sprite(SP.blocks[a.c], x + off, y + off, size, 1 - p * 0.6);
      if (a.sp === 'star') sprite(SP.star, x + off, y + off, size, 1 - p * 0.6);
      ctx.globalAlpha = Math.max(0, 0.85 * (1 - p * 1.6));
      rr(ctx, x + off + 2, y + off + 2, size - 4, size - 4, cell * 0.22); ctx.fillStyle = '#fff'; ctx.fill();
      ctx.globalAlpha = 1;
    }
  }

  // фигуры в лотке
  for (let i = 0; i < 3; i++) {
    const p = g.pieces[i];
    if (p.used || (drag && drag.i === i)) continue;
    const m = SHAPES[p.s].m, c = trayCenter(i), bob = Math.sin(T * 2 + i * 1.7) * 2.2;
    drawPieceCells(p, c.x - (m[0].length * ts) / 2, c.y - (m.length * ts) / 2 + bob, ts, p.dead ? 0.3 : 1, T);
  }

  // перетаскиваемая фигура: плавный подъём
  if (drag) {
    const p = g.pieces[drag.i], m = SHAPES[p.s].m, k = easeOut((T - drag.t0) / 0.16);
    const from = trayCenter(drag.i), to = dragCenter();
    const cx = lerp(from.x, to.x, k), cy = lerp(from.y, to.y, k), size = lerp(ts, cell, k);
    const ox = cx - (m[0].length * size) / 2, oy = cy - (m.length * size) / 2;
    ctx.fillStyle = 'rgba(10,6,40,0.22)'; // мягкая тень
    for (let r = 0; r < m.length; r++) for (let c = 0; c < m[0].length; c++) if (m[r][c]) { rr(ctx, ox + c * size + 4, oy + r * size + 10, size - 4, size - 4, size * 0.25); ctx.fill(); }
    drawPieceCells(p, ox, oy - 2 * k, size, 1, T);
  }

  // частицы
  ctx.globalCompositeOperation = 'lighter';
  for (const q of g.parts) {
    const a = clamp01(q.life / q.max);
    ctx.globalAlpha = a * 0.9;
    if (q.k === 1) {
      ctx.strokeStyle = `hsl(${q.hue},100%,82%)`; ctx.lineWidth = 1.6;
      const s = q.size * 1.6 * (0.4 + a);
      ctx.beginPath(); ctx.moveTo(q.x - s, q.y); ctx.lineTo(q.x + s, q.y); ctx.moveTo(q.x, q.y - s); ctx.lineTo(q.x, q.y + s); ctx.stroke();
    } else {
      ctx.fillStyle = `hsl(${q.hue},100%,78%)`;
      ctx.beginPath(); ctx.arc(q.x, q.y, q.size * (0.4 + a * 0.6), 0, TAU); ctx.fill();
    }
  }
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;

  // серия сверху поля: стеклянная пилюля + индикатор «живости»
  if (g.streak >= 2) {
    const text = 'Серия ×' + g.streak, w = 112, h = 28, x = W / 2 - w / 2, y = by - 38;
    rr(ctx, x, y, w, h, 14);
    const sg = ctx.createLinearGradient(0, y, 0, y + h); sg.addColorStop(0, 'rgba(255,255,255,0.32)'); sg.addColorStop(1, 'rgba(255,255,255,0.1)');
    ctx.fillStyle = sg; ctx.fill(); ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.stroke();
    ctx.font = '700 13px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#fff'; ctx.fillText(text, W / 2 - 8, y + h / 2 + 0.5);
    for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(W / 2 + 30 + i * 8, y + h / 2, 2.6, 0, TAU); ctx.fillStyle = i < 3 - g.miss ? '#ffe08a' : 'rgba(255,255,255,0.25)'; ctx.fill(); }
  }

  // подсказка в начале
  if (!g.moved) {
    const a = 0.65 + 0.3 * Math.sin(T * 3);
    ctx.globalAlpha = a; ctx.font = '600 14px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#fff'; ctx.fillText('Тяни фигуры на поле ✦', W / 2, ty - 4); ctx.globalAlpha = 1;
  }

  // всплывающие стеклянные надписи
  for (const p of g.pops) {
    const k = p.t / p.max, sc = easeBack(p.t / 0.28), a = clamp01(Math.min(1, (1 - k) * 3.2));
    const y = p.y - 36 * easeOut(k);
    ctx.save();
    ctx.translate(p.x, y); ctx.scale(sc, sc); ctx.globalAlpha = a;
    ctx.font = (p.big ? '800 22px' : '700 16px') + ' system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    const w = ctx.measureText(p.text).width + 26, h = p.big ? 40 : 30;
    rr(ctx, -w / 2, -h / 2, w, h, h / 2);
    const pg2 = ctx.createLinearGradient(0, -h / 2, 0, h / 2); pg2.addColorStop(0, 'rgba(255,255,255,0.34)'); pg2.addColorStop(1, 'rgba(255,255,255,0.1)');
    ctx.fillStyle = 'rgba(30,18,70,0.35)'; ctx.fill(); ctx.fillStyle = pg2; ctx.fill();
    ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.stroke();
    ctx.fillStyle = p.col; ctx.fillText(p.text, 0, 1);
    ctx.restore();
  }
  ctx.globalAlpha = 1;
}

function update(dt) {
  const g = G;
  if (!g) return;
  g.shake = Math.max(0, g.shake - 36 * dt);
  for (const a of g.anims) {
    const before = a.t; a.t += dt;
    if (before < 0 && a.t >= 0 && !a.fx) {
      a.fx = true;
      const hue = a.c === BOMB_C ? 270 : HUES[a.c], x = bx + (a.x + 0.5) * cell, y = by + (a.y + 0.5) * cell;
      spark(x, y, hue, 6, 190);
      if (a.sp === 'star') { spark(x, y, 48, 14, 260, 1); }
    }
  }
  g.anims = g.anims.filter(a => a.t < a.max);
  for (const q of g.parts) { q.life -= dt; q.x += q.vx * dt; q.y += q.vy * dt; q.vy += 360 * dt; q.vx *= 0.985; }
  g.parts = g.parts.filter(q => q.life > 0);
  for (const p of g.pops) p.t += dt;
  g.pops = g.pops.filter(p => p.t < p.max);

  // счёт «накручивается»
  if (g.shown !== g.score) {
    const diff = g.score - g.shown;
    g.shown += Math.sign(diff) * Math.max(1, Math.ceil(Math.abs(diff) * Math.min(1, dt * 7)));
    if (Math.abs(g.score - g.shown) < 1) g.shown = g.score;
  }
  if (g.shown !== lastShown) {
    lastShown = g.shown;
    const el = $('score'); el.textContent = g.shown;
    el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump');
  }

  if (g.over && g.overT > 0) {
    g.overT -= dt;
    if (g.overT <= 0) showOver();
  }
}

let last = 0;
function frame(now) {
  const dt = Math.min(0.05, Math.max(0, (now - last) / 1000));
  last = now; T += dt;
  update(dt); render();
  requestAnimationFrame(frame);
}

resize();
if (!load()) newGame();
requestAnimationFrame(t => { last = t; requestAnimationFrame(frame); });

window.__NS = {
  get G() { return G; }, place: placePiece, undo, shuffle: shuffleTray, update, render, newGame, SHAPES, canPlace,
  tick(dt) { T += dt; update(dt); },
  get best() { return best; },
};
})();
