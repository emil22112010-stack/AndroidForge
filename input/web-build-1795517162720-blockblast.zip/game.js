(() => {
'use strict';

const N = 8;
const COLORS = ['#ef5b5b', '#f59e42', '#f2cf3c', '#4fc37b', '#37b6e8', '#5f7df0', '#b274f0'];
const SAVE_KEY = 'blockblast_save_v1';
const BEST_KEY = 'blockblast_best_v1';

// ---------- Фигуры ----------
const BASE = [
  { m: ['#'], rot: false },
  { m: ['##'], rot: true },
  { m: ['###'], rot: true },
  { m: ['####'], rot: true },
  { m: ['#####'], rot: true },
  { m: ['##', '##'], rot: false },
  { m: ['###', '###', '###'], rot: false },
  { m: ['###', '###'], rot: true },
  { m: ['#.', '##'], rot: true },
  { m: ['#..', '#..', '###'], rot: true },
  { m: ['###', '.#.'], rot: true },
  { m: ['.##', '##.'], rot: true },
  { m: ['##.', '.##'], rot: true },
  { m: ['#.', '#.', '##'], rot: true },
  { m: ['.#', '.#', '##'], rot: true },
];

function toMatrix(rows) { return rows.map(r => [...r].map(ch => (ch === '#' ? 1 : 0))); }
function rotate(m) {
  const R = m.length, C = m[0].length;
  const out = Array.from({ length: C }, () => Array(R).fill(0));
  for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) out[c][R - 1 - r] = m[r][c];
  return out;
}
const SHAPES = [];
{
  const seen = new Set();
  for (const b of BASE) {
    let m = toMatrix(b.m);
    const turns = b.rot ? 4 : 1;
    for (let i = 0; i < turns; i++) {
      const key = m.map(r => r.join('')).join('/');
      if (!seen.has(key)) { seen.add(key); SHAPES.push(m); }
      m = rotate(m);
    }
  }
}
const cellCount = m => m.reduce((a, r) => a + r.reduce((x, y) => x + y, 0), 0);

// ---------- Состояние ----------
let grid, pieces, score, combo, miss, best, over;
let drag = null;
let particles = [], flashes = [], floaters = [];

const $ = id => document.getElementById(id);
const canvas = $('c');
const ctx = canvas.getContext('2d');
let W = 0, H = 0, cell = 0, bx = 0, by = 0, bw = 0, ty = 0, ts = 0;

try { best = parseInt(localStorage.getItem(BEST_KEY) || '0', 10) || 0; } catch (e) { best = 0; }

function emptyGrid() { return Array.from({ length: N }, () => Array(N).fill(0)); }

function canPlace(m, gx, gy) {
  for (let r = 0; r < m.length; r++) for (let c = 0; c < m[0].length; c++) {
    if (!m[r][c]) continue;
    const x = gx + c, y = gy + r;
    if (x < 0 || y < 0 || x >= N || y >= N || grid[y][x]) return false;
  }
  return true;
}
function fitsAnywhere(m) {
  for (let y = 0; y <= N - m.length; y++) for (let x = 0; x <= N - m[0].length; x++) {
    if (canPlace(m, x, y)) return true;
  }
  return false;
}

function randPiece() {
  let s;
  do { s = Math.floor(Math.random() * SHAPES.length); }
  while (cellCount(SHAPES[s]) === 1 && Math.random() < 0.75);
  return { s, c: Math.floor(Math.random() * COLORS.length), used: false, dead: false };
}

function updateDead() {
  for (const p of pieces) p.dead = !p.used && !fitsAnywhere(SHAPES[p.s]);
}

function newPieces() {
  let ps;
  for (let t = 0; t < 30; t++) {
    ps = [randPiece(), randPiece(), randPiece()];
    if (ps.some(p => fitsAnywhere(SHAPES[p.s]))) break;
  }
  pieces = ps;
  updateDead();
}

function reset() {
  grid = emptyGrid();
  score = 0; combo = 0; miss = 0; over = false;
  particles = []; flashes = []; floaters = []; drag = null;
  newPieces();
  hideOver();
  updateHud();
  save();
}

function save() {
  try {
    if (over) { localStorage.removeItem(SAVE_KEY); return; }
    localStorage.setItem(SAVE_KEY, JSON.stringify({
      grid, score, combo, miss,
      pieces: pieces.map(p => ({ s: p.s, c: p.c, used: p.used })),
    }));
  } catch (e) {}
}

function load() {
  try {
    const d = JSON.parse(localStorage.getItem(SAVE_KEY));
    if (!d || !d.grid || d.grid.length !== N) return false;
    if (d.pieces.some(p => p.s >= SHAPES.length)) return false;
    grid = d.grid; score = d.score; combo = d.combo; miss = d.miss; over = false;
    pieces = d.pieces.map(p => ({ s: p.s, c: p.c, used: p.used, dead: false }));
    updateDead();
    updateHud();
    return true;
  } catch (e) { return false; }
}

function updateHud() {
  $('score').textContent = score;
  $('best').textContent = best;
}

// ---------- Звук ----------
let actx = null, soundOn = true;
try { soundOn = localStorage.getItem('blockblast_sound') !== '0'; } catch (e) {}
$('sound').textContent = soundOn ? '🔊' : '🔇';

function initAudio() {
  if (actx) return;
  try { actx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {}
}
function tone(freq, dur, type = 'sine', vol = 0.12, delay = 0) {
  if (!soundOn || !actx) return;
  const t0 = actx.currentTime + delay;
  const o = actx.createOscillator(), g = actx.createGain();
  o.type = type; o.frequency.value = freq;
  g.gain.setValueAtTime(vol, t0);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g); g.connect(actx.destination);
  o.start(t0); o.stop(t0 + dur + 0.02);
}
function buzz(ms) { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) {} }

// ---------- Геометрия ----------
function layout() {
  const dpr = Math.min(window.devicePixelRatio || 1, 3);
  W = canvas.clientWidth; H = canvas.clientHeight;
  canvas.width = Math.round(W * dpr);
  canvas.height = Math.round(H * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  cell = Math.floor(Math.min((W - 24) / N, (H - 130) / N));
  cell = Math.max(cell, 20);
  bw = cell * N;
  bx = Math.round((W - bw) / 2);
  by = 10;
  ty = by + bw + 14;
  ts = Math.min(cell * 0.62, (W / 3 - 14) / 5);
}

function trayCenter(i) {
  const slotH = H - ty;
  return { x: (W / 3) * (i + 0.5), y: ty + Math.max(slotH / 2, ts * 2.6) };
}

function dragTarget() {
  const m = SHAPES[pieces[drag.i].s];
  const cx = drag.x, cy = drag.y - cell * 2.2;
  const gx = Math.round((cx - bx) / cell - m[0].length / 2);
  const gy = Math.round((cy - by) / cell - m.length / 2);
  return { gx, gy, ok: canPlace(m, gx, gy) };
}

// ---------- Отрисовка ----------
function rr(x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function block(x, y, s, color, alpha = 1) {
  const p = Math.max(1, s * 0.05), w = s - 2 * p, rad = s * 0.2;
  ctx.globalAlpha = alpha;
  rr(x + p, y + p, w, w, rad); ctx.fillStyle = color; ctx.fill();
  rr(x + p, y + p, w, w * 0.5, rad); ctx.fillStyle = 'rgba(255,255,255,0.2)'; ctx.fill();
  rr(x + p + w * 0.12, y + p + w * 0.62, w * 0.76, w * 0.26, rad * 0.6);
  ctx.fillStyle = 'rgba(0,0,0,0.12)'; ctx.fill();
  ctx.globalAlpha = 1;
}

function drawPiece(m, color, x, y, s, alpha = 1) {
  for (let r = 0; r < m.length; r++) for (let c = 0; c < m[0].length; c++) {
    if (m[r][c]) block(x + c * s, y + r * s, s, color, alpha);
  }
}

function linesFilledIfPlaced(m, gx, gy) {
  const g = grid.map(r => r.slice());
  for (let r = 0; r < m.length; r++) for (let c = 0; c < m[0].length; c++) if (m[r][c]) g[gy + r][gx + c] = 1;
  const rows = [], cols = [];
  for (let y = 0; y < N; y++) if (g[y].every(v => v)) rows.push(y);
  for (let x = 0; x < N; x++) if (g.every(row => row[x])) cols.push(x);
  return { rows, cols };
}

function draw() {
  ctx.clearRect(0, 0, W, H);

  // поле
  rr(bx - 7, by - 7, bw + 14, bw + 14, 16);
  ctx.fillStyle = '#0a1422'; ctx.fill();
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const alt = ((x >> 2) + (y >> 2)) % 2;
    rr(bx + x * cell + 1.5, by + y * cell + 1.5, cell - 3, cell - 3, cell * 0.16);
    ctx.fillStyle = alt ? '#1a2b44' : '#15243b';
    ctx.fill();
  }

  // превью линий, которые сгорят
  let target = null;
  if (drag) {
    target = dragTarget();
    if (target.ok) {
      const m = SHAPES[pieces[drag.i].s];
      const { rows, cols } = linesFilledIfPlaced(m, target.gx, target.gy);
      ctx.fillStyle = COLORS[pieces[drag.i].c];
      ctx.globalAlpha = 0.28;
      for (const y of rows) { rr(bx, by + y * cell, bw, cell, cell * 0.2); ctx.fill(); }
      for (const x of cols) { rr(bx + x * cell, by, cell, bw, cell * 0.2); ctx.fill(); }
      ctx.globalAlpha = 1;
    }
  }

  // занятые клетки
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    if (grid[y][x]) block(bx + x * cell, by + y * cell, cell, COLORS[grid[y][x] - 1]);
  }

  // тень фигуры
  if (drag && target && target.ok) {
    const p = pieces[drag.i];
    drawPiece(SHAPES[p.s], COLORS[p.c], bx + target.gx * cell, by + target.gy * cell, cell, 0.4);
  }

  // вспышки
  for (const f of flashes) {
    ctx.fillStyle = `rgba(255,255,255,${Math.max(0, f.life / 0.35) * 0.8})`;
    rr(bx + f.x * cell + 2, by + f.y * cell + 2, cell - 4, cell - 4, cell * 0.2);
    ctx.fill();
  }

  // фигуры в лотке
  for (let i = 0; i < 3; i++) {
    const p = pieces[i];
    if (p.used || (drag && drag.i === i)) continue;
    const m = SHAPES[p.s];
    const c = trayCenter(i);
    drawPiece(m, COLORS[p.c], c.x - (m[0].length * ts) / 2, c.y - (m.length * ts) / 2, ts, p.dead ? 0.3 : 1);
  }

  // перетаскиваемая фигура
  if (drag) {
    const p = pieces[drag.i], m = SHAPES[p.s];
    drawPiece(m, COLORS[p.c], drag.x - (m[0].length * cell) / 2, drag.y - cell * 2.2 - (m.length * cell) / 2, cell);
  }

  // частицы
  for (const p of particles) {
    ctx.globalAlpha = Math.max(0, p.life / p.max);
    ctx.fillStyle = p.color;
    ctx.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
  }
  ctx.globalAlpha = 1;

  // тексты
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  for (const f of floaters) {
    const a = Math.min(1, f.life / 0.5);
    ctx.globalAlpha = a;
    ctx.font = `800 ${Math.round(cell * f.scale)}px system-ui, sans-serif`;
    ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(10,20,34,.85)';
    ctx.strokeText(f.text, W / 2, f.y);
    ctx.fillStyle = f.color;
    ctx.fillText(f.text, W / 2, f.y);
  }
  ctx.globalAlpha = 1;
}

function update(dt) {
  for (const p of particles) {
    p.life -= dt; p.vy += 900 * dt;
    p.x += p.vx * dt; p.y += p.vy * dt;
  }
  particles = particles.filter(p => p.life > 0);
  for (const f of flashes) f.life -= dt;
  flashes = flashes.filter(f => f.life > 0);
  for (const f of floaters) { f.life -= dt; f.y -= 28 * dt; }
  floaters = floaters.filter(f => f.life > 0);
}

// ---------- Ход ----------
function say(text, color, scale = 1.1) {
  floaters.push({ text, color, scale, life: 1.3, y: by + bw * 0.42 + floaters.length * cell * 1.1 });
}

function burst(x, y, colorIdx) {
  for (let i = 0; i < 6; i++) {
    const a = Math.random() * Math.PI * 2, v = 120 + Math.random() * 260;
    particles.push({
      x: bx + (x + 0.5) * cell, y: by + (y + 0.5) * cell,
      vx: Math.cos(a) * v, vy: Math.sin(a) * v - 160,
      size: cell * (0.12 + Math.random() * 0.14),
      color: COLORS[colorIdx], life: 0.7 + Math.random() * 0.4, max: 1.1,
    });
  }
}

function drop(i, gx, gy) {
  const p = pieces[i], m = SHAPES[p.s];
  let placed = 0;
  for (let r = 0; r < m.length; r++) for (let c = 0; c < m[0].length; c++) {
    if (m[r][c]) { grid[gy + r][gx + c] = p.c + 1; placed++; }
  }
  p.used = true;
  let pts = placed;

  const rows = [], cols = [];
  for (let y = 0; y < N; y++) if (grid[y].every(v => v)) rows.push(y);
  for (let x = 0; x < N; x++) if (grid.every(row => row[x])) cols.push(x);
  const n = rows.length + cols.length;

  tone(300 + placed * 20, 0.09, 'triangle', 0.14);
  buzz(12);

  if (n > 0) {
    const set = new Set();
    rows.forEach(y => { for (let x = 0; x < N; x++) set.add(y * N + x); });
    cols.forEach(x => { for (let y = 0; y < N; y++) set.add(y * N + x); });
    for (const k of set) {
      const y = Math.floor(k / N), x = k % N;
      burst(x, y, grid[y][x] - 1);
      flashes.push({ x, y, life: 0.35 });
      grid[y][x] = 0;
    }
    combo++; miss = 0;
    pts += n * n * 10 + (combo > 1 ? (combo - 1) * 15 : 0);

    const words = ['', '', 'Отлично!', 'Супер!', 'Невероятно!'];
    if (n >= 2) say(words[Math.min(n, 4)], '#ffd166', 1.2);
    if (combo >= 2) say(`Серия ×${combo}`, '#7be0ff', 0.95);

    if (grid.every(row => row.every(v => !v))) {
      pts += 100;
      say('Чистое поле! +100', '#9cf08b', 1.0);
    }
    for (let k = 0; k < Math.min(n, 4) + 2; k++) tone(520 + k * 110, 0.16, 'sine', 0.13, k * 0.06);
    buzz(35);
  } else {
    miss++;
    if (miss >= 3) combo = 0;
  }

  score += pts;
  if (score > best) {
    best = score;
    try { localStorage.setItem(BEST_KEY, String(best)); } catch (e) {}
  }

  if (pieces.every(q => q.used)) newPieces(); else updateDead();
  updateHud();

  if (pieces.every(q => q.used || q.dead)) {
    over = true;
    save();
    setTimeout(showOver, n > 0 ? 900 : 500);
  } else {
    save();
  }
}

function showOver() {
  $('finalScore').textContent = score;
  $('finalNote').textContent = score >= best && score > 0 ? 'Новый рекорд!' : `Рекорд: ${best}`;
  $('over').classList.remove('hidden');
  tone(330, 0.25, 'sawtooth', 0.1);
  tone(262, 0.25, 'sawtooth', 0.1, 0.18);
  tone(196, 0.45, 'sawtooth', 0.1, 0.36);
  buzz(80);
}
function hideOver() { $('over').classList.add('hidden'); }

// ---------- Ввод ----------
function pos(e) {
  const r = canvas.getBoundingClientRect();
  return { x: e.clientX - r.left, y: e.clientY - r.top };
}

canvas.addEventListener('pointerdown', e => {
  initAudio();
  if (over || drag) return;
  const { x, y } = pos(e);
  if (y < ty - cell * 0.6) return;
  const i = Math.min(2, Math.max(0, Math.floor(x / (W / 3))));
  const p = pieces[i];
  if (p.used) return;
  drag = { i, x, y, id: e.pointerId };
  try { canvas.setPointerCapture(e.pointerId); } catch (err) {}
  tone(600, 0.04, 'sine', 0.06);
  e.preventDefault();
});

canvas.addEventListener('pointermove', e => {
  if (!drag || e.pointerId !== drag.id) return;
  const { x, y } = pos(e);
  drag.x = x; drag.y = y;
  e.preventDefault();
});

function endDrag(e, cancel) {
  if (!drag || e.pointerId !== drag.id) return;
  const t = dragTarget();
  const i = drag.i;
  drag = null;
  if (!cancel && t.ok) drop(i, t.gx, t.gy);
}
canvas.addEventListener('pointerup', e => endDrag(e, false));
canvas.addEventListener('pointercancel', e => endDrag(e, true));

$('sound').addEventListener('click', () => {
  initAudio();
  soundOn = !soundOn;
  $('sound').textContent = soundOn ? '🔊' : '🔇';
  try { localStorage.setItem('blockblast_sound', soundOn ? '1' : '0'); } catch (e) {}
});
$('restart').addEventListener('click', () => { initAudio(); reset(); });
$('again').addEventListener('click', () => { initAudio(); reset(); });

document.addEventListener('contextmenu', e => e.preventDefault());
window.addEventListener('resize', layout);
window.addEventListener('orientationchange', () => setTimeout(layout, 150));

// ---------- Старт ----------
layout();
if (!load()) reset();
if (pieces.every(q => q.used || q.dead)) reset();

let last = performance.now();
function loop(now) {
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;
  update(dt);
  draw();
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);
})();
