BLOCK BLAST: HTML5-игра (работает офлайн, без сервера и без интернета)

Файлы: index.html, style.css, game.js, manifest.json, icon.png
Главный файл: index.html (лежит в корне архива).

КАК СДЕЛАТЬ APK
Вариант 1, онлайн-конвертеры (проще всего):
  Загрузите этот zip в WebIntoApp / AppsGeyser / Median и получите APK.

Вариант 2, Capacitor (свой проект, можно публиковать в Google Play):
  1. Установите Node.js и Android Studio.
  2. mkdir blockblast-app && cd blockblast-app
  3. npm init -y
  4. npm i @capacitor/core @capacitor/cli @capacitor/android
  5. npx cap init BlockBlast com.example.blockblast --web-dir=www
  6. Создайте папку www и положите туда все файлы из этого архива.
  7. npx cap add android
  8. npx cap sync
  9. npx cap open android, затем в Android Studio: Build > Build APK(s).

Рекомендация: в AndroidManifest.xml задайте screenOrientation="portrait".
Рекорд и сохранение партии хранятся в localStorage (работает в WebView).
