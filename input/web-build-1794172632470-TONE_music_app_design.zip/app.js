const catalog={
  "Гитара":[["Тихий вечер","Автор / исполнитель"],["Дорога домой","Автор / исполнитель"],["Лунный свет","Автор / исполнитель"],["Письмо тебе","Автор / исполнитель"],["Старый мотив","Автор / исполнитель"]],
  "Пианино":[["Ноктюрн","Автор / исполнитель"],["Первый снег","Автор / исполнитель"],["Мелодия дождя","Автор / исполнитель"]],
  "Укулеле":[["Летнее настроение","Автор / исполнитель"],["У моря","Автор / исполнитель"],["Маленькая история","Автор / исполнитель"]],
  "Бас-гитара":[["Глубокий ритм","Автор / исполнитель"],["Ночной город","Автор / исполнитель"]],
  "Скрипка":[["Вальс","Автор / исполнитель"],["Этюд","Автор / исполнитель"],["Мелодия","Автор / исполнитель"]]
};
let currentInstrument="Гитара", currentSong=null;
const favorites=new Set();
const lyricsBySong={};
const $=id=>document.getElementById(id);
function showScreen(name){document.querySelectorAll(".screen").forEach(s=>s.classList.toggle("active",s.id===name));document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("selected",b.dataset.nav===name));window.scrollTo({top:0,behavior:"smooth"});}
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1800);}
function openInstrument(name){currentInstrument=name;$("libraryTitle").textContent=name;$("searchInput").value="";renderSongs();showScreen("library");}
function renderSongs(filter=""){const list=$("songList");list.innerHTML="";const songs=(catalog[currentInstrument]||[]).filter(s=>s[0].toLowerCase().includes(filter.toLowerCase()));songs.forEach((s,i)=>{const b=document.createElement("button");b.className="song-row";b.innerHTML=`<span class="song-number">${String(i+1).padStart(2,"0")}</span><span class="song-info"><strong>${s[0]}</strong><small>${s[1]}</small></span><span class="song-arrow">↗</span>`;b.addEventListener("click",()=>openSong(currentInstrument,s));list.appendChild(b);});if(!songs.length)list.innerHTML='<p class="subcopy">Ничего не найдено. Попробуй другое название.</p>';}
function openSong(inst,song){currentSong={instrument:inst,title:song[0],artist:song[1]};$("songInstrument").textContent=inst.toUpperCase()+" · ПРОИЗВЕДЕНИЕ";$("songTitle").textContent=song[0];$("songArtist").textContent=song[1];$("lyricsDisplay").innerHTML=(lyricsBySong[song[0]]||"Здесь будет текст произведения.\n\nAm    F    C    G\n\nДобавь сюда свои строки и аккорды — этот макет можно редактировать.").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\n/g,"<br>").replace(/\b(Am|F|C|G|Dm|E|Em|G7)\b/g,'<span class="chord">$1</span>');$("favoriteBtn").classList.toggle("on",favorites.has(song[0]));$("favoriteBtn").textContent=favorites.has(song[0])?"♥":"♡";$("lyricsEditor").hidden=true;$("lyricsDisplay").hidden=false;$("editorActions").hidden=true;showScreen("song");}
function renderFavorites(){const list=$("favoriteList");list.innerHTML="";let count=0;Object.entries(catalog).forEach(([inst,songs])=>songs.forEach(s=>{if(favorites.has(s[0])){count++;const b=document.createElement("button");b.className="song-row";b.innerHTML=`<span class="song-number">♡</span><span class="song-info"><strong>${s[0]}</strong><small>${inst}</small></span><span class="song-arrow">↗</span>`;b.onclick=()=>openSong(inst,s);list.appendChild(b);}}));if(!count)list.innerHTML='<p class="subcopy">Пока здесь пусто. Открой произведение и нажми на сердечко, чтобы сохранить его.</p>';}
document.querySelectorAll("[data-instrument]").forEach(b=>b.addEventListener("click",()=>openInstrument(b.dataset.instrument)));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>showScreen(b.dataset.go)));
document.querySelectorAll("[data-nav]").forEach(b=>b.addEventListener("click",()=>{if(b.dataset.nav==="favorites")renderFavorites();if(b.dataset.nav==="library")openInstrument(currentInstrument);else showScreen(b.dataset.nav);}));
$("searchInput").addEventListener("input",e=>renderSongs(e.target.value));
$("favoriteBtn").addEventListener("click",()=>{if(!currentSong)return;const title=currentSong.title;if(favorites.has(title))favorites.delete(title);else favorites.add(title);$("favoriteBtn").classList.toggle("on",favorites.has(title));$("favoriteBtn").textContent=favorites.has(title)?"♥":"♡";toast(favorites.has(title)?"Добавлено в избранное":"Удалено из избранного");});
$("editBtn").addEventListener("click",()=>{$("lyricsEditor").value=lyricsBySong[currentSong.title]||"Здесь будет текст произведения.\n\nAm    F    C    G\n\nДобавь сюда свои строки и аккорды."; $("lyricsEditor").hidden=false;$("lyricsDisplay").hidden=true;$("editorActions").hidden=false;});
$("saveLyrics").addEventListener("click",()=>{lyricsBySong[currentSong.title]=$("lyricsEditor").value;openSong(currentSong.instrument,[currentSong.title,currentSong.artist]);toast("Изменения сохранены в этом макете");});
$("cancelEdit").addEventListener("click",()=>{$("lyricsEditor").hidden=true;$("lyricsDisplay").hidden=false;$("editorActions").hidden=true;});
$("themeHint").addEventListener("click",()=>toast("TONE — музыка в твоём стиле"));
