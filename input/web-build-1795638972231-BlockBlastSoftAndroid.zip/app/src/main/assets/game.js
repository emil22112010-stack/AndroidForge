(() => {
'use strict';

const TAU = Math.PI * 2;
const BOMB_C = 7, STONE_C = 8;
const $ = id => document.getElementById(id);
const cv = $('c');
const ctx = cv.getContext('2d');
let N = 4;
let W = 360, H = 560, dpr = 1, cell = 60, bx = 0, by = 44, bw = 240, ty = 400, ts = 24;
let T = 0, SP = null, inGame = false;

const clamp01 = x => Math.max(0, Math.min(1, x));
const easeOut = x => 1 - Math.pow(1 - clamp01(x), 3);
const easeBack = x => { x = clamp01(x); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); };
const lerp = (a, b, k) => a + (b - a) * k;

// ================= Темы, фоны, сложность =================
const THEMES = [
  { name: 'Сумерки', hues: [350, 24, 46, 152, 196, 236, 276], sat: 50, lit: 66, bg: ['#1d1a33', '#12203a'], blobs: ['#c46a95', '#5fa3c7', '#7a6fc9', '#d1a36a'], accent: '#e3c98f' },
  { name: 'Океан',   hues: [186, 200, 214, 168, 230, 154, 246], sat: 48, lit: 64, bg: ['#0f2a3a', '#0b1830'], blobs: ['#3aa0b5', '#3c6fb0', '#2f8f8a', '#6fb7d0'], accent: '#a9d9e0' },
  { name: 'Лес',     hues: [96, 128, 150, 62, 36, 176, 18],     sat: 38, lit: 60, bg: ['#15261f', '#101b1a'], blobs: ['#5f9a6e', '#8aa05a', '#4d8a86', '#b59a5f'], accent: '#cfd9a3' },
  { name: 'Сакура',  hues: [340, 320, 8, 290, 356, 26, 310],    sat: 50, lit: 72, bg: ['#2b1d2e', '#1d1a30'], blobs: ['#d487a6', '#a98ad1', '#e0a58f', '#8fa3d6'], accent: '#f1c9d6' },
  { name: 'Графит',  hues: [210, 190, 40, 10, 260, 150, 330],   sat: 20, lit: 66, bg: ['#1c1e24', '#14161b'], blobs: ['#6c7a94', '#807a8f', '#6f8a8a', '#8f8670'], accent: '#cfd3dc' },
];
const BGS = [{ id: 'mist', name: 'Туман' }, { id: 'stars', name: 'Звёзды' }, { id: 'bubbles', name: 'Пузыри' }, { id: 'plain', name: 'Градиент' }];
const DIFFS = [
  { name: 'Спокойно', help: 0.9, grow: 0.27, stone: 5, mercy: 1.0 },
  { name: 'Обычно',   help: 0.8, grow: 0.34, stone: 3, mercy: 0.95 },
  { name: 'Сложно',   help: 0.65, grow: 0.44, stone: 2, mercy: 0.8 },
];
const SIZES = [4, 5, 6, 8];

// ================= Настройки и рекорды =================
const SETKEY = 'blockblast_soft_settings', SKEY = 'blockblast_soft_save', BKEY = 'blockblast_soft_best';
let SET = { theme: 0, bg: 0, size: 4, diff: 1, sound: true, vib: true };
let bests = {};
try { Object.assign(SET, JSON.parse(localStorage.getItem(SETKEY)) || {}); } catch (e) {}
try { bests = JSON.parse(localStorage.getItem(BKEY)) || {}; } catch (e) {}
if (!THEMES[SET.theme]) SET.theme = 0;
if (!BGS[SET.bg]) SET.bg = 0;
if (SIZES.indexOf(SET.size) < 0) SET.size = 4;
if (!DIFFS[SET.diff]) SET.diff = 1;
const saveSettings = () => { try { localStorage.setItem(SETKEY, JSON.stringify(SET)); } catch (e) {} };
const saveBests = () => { try { localStorage.setItem(BKEY, JSON.stringify(bests)); } catch (e) {} };
const bestNow = () => bests[N] || 0;

// ================= Фигуры =================
// d: условная «сложность» фигуры, w: базовая частота
const BASE = [
  { m: ['#'],                    w: 0.6,  d: 0 },
  { m: ['##'],                   w: 1,    d: 1,   rot: 1 },
  { m: ['###'],                  w: 1,    d: 1.3, rot: 1 },
  { m: ['####'],                 w: 0.8,  d: 1.8, rot: 1 },
  { m: ['#####'],                w: 0.5,  d: 3,   rot: 1 },
  { m: ['##', '##'],             w: 1.2,  d: 1.4 },
  { m: ['###', '###', '###'],    w: 0.55, d: 3.8 },
  { m: ['###', '###'],           w: 1,    d: 2.5, rot: 1 },
  { m: ['#.', '##'],             w: 1.1,  d: 1.2, rot: 1 },
  { m: ['#..', '#..', '###'],    w: 0.7,  d: 3.4, rot: 1 },
  { m: ['###', '.#.'],           w: 1,    d: 2,   rot: 1 },
  { m: ['.##', '##.'],           w: 0.9,  d: 2.3, rot: 1 },
  { m: ['##.', '.##'],           w: 0.9,  d: 2.3, rot: 1 },
  { m: ['#.', '#.', '##'],       w: 0.9,  d: 2,   rot: 1 },
  { m: ['.#', '.#', '##'],       w: 0.9,  d: 2,   rot: 1 },
  { m: ['#.#', '###'],           w: 0.5,  d: 3,   rot: 1 },
  { m: ['#.', '.#'],             w: 0.6,  d: 2.2, rot: 1 },
  { m: ['#..', '.#.', '..#'],    w: 0.3,  d: 3.4, rot: 1 },
  { m: ['.#.', '###', '.#.'],    w: 0.35, d: 3.6 },
  { m: ['##', '#.', '##'],       w: 0.5,  d: 2.8, rot: 1 },
];
const toMatrix = rows => rows.map(r => [...r].map(ch => (ch === '#' ? 1 : 0)));
function rotate(m) {
  const R = m.length, C = m[0].length, out = Array.from({ length: C }, () => Array(R).fill(0));
  for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) out[c][R - 1 - r] = m[r][c];
  return out;
}
const SHAPES = [];
{
  const seen = new Set();
  for (const b of BASE) {
    let m = toMatrix(b.m);
    for (let i = 0; i < (b.rot ? 4 : 1); i++) {
      const key = m.map(r => r.join('')).join('/');
      if (!seen.has(key)) { seen.add(key); SHAPES.push({ m, w: b.w, d: b.d, n: m.reduce((a, r) => a + r.reduce((x, y) => x + y, 0), 0) }); }
      m = rotate(m);
    }
  }
}
const SINGLE = SHAPES.findIndex(s => s.n === 1);
let AVAIL = [];
function setN(n) {
  N = n;
  AVAIL = [];
  SHAPES.forEach((s, i) => { if (s.m.length <= N && s.m[0].length <= N) AVAIL.push(i); });
}
setN(4);

// ================= Состояние =================
let G = null;
const cloneGrid = g => g.map(r => r.map(v => (v ? { c: v.c, sp: v.sp, born: -9 } : null)));
const clonePieces = ps => ps.map(p => Object.assign({}, p));
const emptyGrid = () => Array.from({ length: N }, () => Array(N).fill(null));
const D = () => DIFFS[SET.diff];
const goalOf = lvl => Math.round(Math.min(12, 3 + lvl) * Math.max(1, N / 5));
const targetOf = lvl => Math.min(3.7, 0.6 + (lvl - 1) * D().grow);
const mercyOf = lvl => Math.max(0.12, D().mercy - (lvl - 1) * (N <= 4 ? 0.06 : 0.085));
const helpOf = lvl => Math.max(0.15, D().help - (lvl - 1) * 0.06);
const stoneCap = () => (N <= 4 ? 2 : N <= 5 ? 3 : N <= 6 ? 4 : 6);
const stoneStart = () => D().stone + (N <= 4 ? 2 : N <= 5 ? 1 : 0);
const stonesWanted = lvl => (lvl >= stoneStart() ? Math.min(stoneCap(), 1 + Math.floor((lvl - stoneStart()) / 2)) : 0);

function canPlace(m, gx, gy) {
  for (let r = 0; r < m.length; r++) for (let c = 0; c < m[0].length; c++) {
    if (!m[r][c]) continue;
    const x = gx + c, y = gy + r;
    if (x < 0 || y < 0 || x >= N || y >= N || G.grid[y][x]) return false;
  }
  return true;
}
function fitsAnywhere(m) {
  for (let y = 0; y <= N - m.length; y++) for (let x = 0; x <= N - m[0].length; x++) if (canPlace(m, x, y)) return true;
  return false;
}
function fillRatio() { let n = 0; for (const r of G.grid) for (const v of r) if (v) n++; return n / (N * N); }

function findHelper() {
  const rowCnt = Array(N).fill(0), colCnt = Array(N).fill(0);
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) if (G.grid[y][x]) { rowCnt[y]++; colCnt[x]++; }
  const order = AVAIL.slice().sort(() => Math.random() - 0.5);
  for (const si of order) {
    const m = SHAPES[si].m;
    if (SHAPES[si].n < 2 && Math.random() < 0.7) continue;
    const rowCells = m.map(r => r.reduce((a, v) => a + v, 0));
    const colCells = m[0].map((_, c) => m.reduce((a, r) => a + r[c], 0));
    for (let y = 0; y <= N - m.length; y++) for (let x = 0; x <= N - m[0].length; x++) {
      if (!canPlace(m, x, y)) continue;
      for (let r = 0; r < m.length; r++) if (rowCells[r] && rowCnt[y + r] + rowCells[r] === N) return si;
      for (let c = 0; c < m[0].length; c++) if (colCells[c] && colCnt[x + c] + colCells[c] === N) return si;
    }
  }
  return -1;
}

// Чем выше уровень, тем чаще выпадают «неудобные» фигуры
function randShape(fr) {
  const tg = targetOf(G.lvl);
  let sum = 0;
  const ws = AVAIL.map(i => {
    const s = SHAPES[i];
    let w = s.w * (0.15 + Math.exp(-Math.pow((s.d - tg) / 1.2, 2)));
    const cap = 1.6 + N * 0.35 + G.lvl * 0.45;            // «потолок» размера фигуры растёт с уровнем
    if (s.n > cap) w *= Math.exp(-(s.n - cap) * 0.9);
    if (fr > 0.45 && s.n <= 3) w *= 1.6;
    if (fr > 0.6 && s.n <= 2) w *= 1.4;
    sum += w; return w;
  });
  let r = Math.random() * sum;
  for (let k = 0; k < ws.length; k++) { r -= ws[k]; if (r <= 0) return AVAIL[k]; }
  return AVAIL[0];
}

function makePiece(si) {
  const n = SHAPES[si].n;
  return { s: si, c: Math.floor(Math.random() * 7), star: (n >= 2 && Math.random() < 0.18) ? Math.floor(Math.random() * n) : -1, bomb: false, used: false, dead: false, spawnT: -9 };
}
function updateDead() { for (const p of G.pieces) p.dead = !p.used && !fitsAnywhere(SHAPES[p.s].m); }


// ---- «милость»: проверяем, что все три фигуры можно поставить подряд ----
function simPlace(occ, m, x, y) {
  const o = occ.map(r => r.slice());
  for (let r = 0; r < m.length; r++) for (let c = 0; c < m[0].length; c++) if (m[r][c]) o[y + r][x + c] = true;
  const rows = [], cols = [];
  for (let yy = 0; yy < N; yy++) if (o[yy].every(v => v)) rows.push(yy);
  for (let xx = 0; xx < N; xx++) if (o.every(row => row[xx])) cols.push(xx);
  rows.forEach(yy => { for (let xx = 0; xx < N; xx++) o[yy][xx] = false; });
  cols.forEach(xx => { for (let yy = 0; yy < N; yy++) o[yy][xx] = false; });
  return o;
}
function solveRec(occ, ms, budget) {
  if (!ms.length) return true;
  for (let k = 0; k < ms.length; k++) {
    const m = ms[k], rest = ms.filter((_, j) => j !== k);
    for (let y = 0; y <= N - m.length; y++) for (let x = 0; x <= N - m[0].length; x++) {
      let ok = true;
      for (let r = 0; r < m.length && ok; r++) for (let c = 0; c < m[0].length; c++) if (m[r][c] && occ[y + r][x + c]) { ok = false; break; }
      if (!ok) continue;
      if (--budget.n < 0) return true;           // слишком долго считаем: считаем, что решение есть
      if (solveRec(simPlace(occ, m, x, y), rest, budget)) return true;
    }
  }
  return false;
}
function traySolvable(ps) {
  const occ = G.grid.map(r => r.map(v => !!v));
  return solveRec(occ, ps.filter(p => !p.used).map(p => SHAPES[p.s].m), { n: 25000 });
}

function genTray(forceHelper) {
  const wantSolvable = forceHelper || Math.random() < mercyOf(G.lvl);
  let ps = null;
  for (let attempt = 0; attempt < (wantSolvable ? 8 : 1); attempt++) {
    ps = genTrayOnce(forceHelper);
    if (!wantSolvable || traySolvable(ps)) break;
  }
  G.pieces = ps;
  ps.forEach((p, i) => { p.spawnT = T + 0.05 + i * 0.09; });
  updateDead();
}

function genTrayOnce(forceHelper) {
  const fr = fillRatio();
  const ps = [makePiece(randShape(fr)), makePiece(randShape(fr)), makePiece(randShape(fr))];
  if (forceHelper || fr > 0.5 || Math.random() < helpOf(G.lvl)) {
    const h = findHelper();
    if (h >= 0) ps[Math.floor(Math.random() * 3)] = makePiece(h);
  }
  if (G.score > 250 && N >= 5 && Math.random() < 0.05) {
    const b = makePiece(SINGLE); b.bomb = true; b.c = BOMB_C; b.star = -1;
    ps[Math.floor(Math.random() * 3)] = b;
  }
  G.pieces = ps;   // нужно для fitsAnywhere ниже
  // на тесном поле гарантируем: помещаются минимум две фигуры (иначе партия кончается слишком рано)
  const needFit = (N <= 5 && fr > 0.4) ? 2 : 1;
  const small = AVAIL.slice().sort((a, b) => SHAPES[a].n - SHAPES[b].n || Math.random() - 0.5);
  for (let guard = 0; guard < 3; guard++) {
    const fit = ps.filter(p => fitsAnywhere(SHAPES[p.s].m)).length;
    if (fit >= needFit) break;
    const idx = ps.findIndex(p => !fitsAnywhere(SHAPES[p.s].m));
    if (idx < 0) break;
    const si = small.find(s => fitsAnywhere(SHAPES[s].m) && SHAPES[s].n <= 3 + Math.floor(G.lvl / 3));
    if (si === undefined) break;
    ps[idx] = makePiece(si);
  }
  return ps;
}

function spawnStones(want) {
  const g = G;
  let have = 0;
  for (const r of g.grid) for (const v of r) if (v && v.sp === 'stone') have++;
  const need = Math.max(0, want - have);
  if (!need) return 0;
  const rowCnt = Array(N).fill(0), colCnt = Array(N).fill(0);
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) if (g.grid[y][x]) { rowCnt[y]++; colCnt[x]++; }
  const free = [];
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) if (!g.grid[y][x] && rowCnt[y] < N - 2 && colCnt[x] < N - 2) free.push([x, y]);
  let made = 0;
  free.sort(() => Math.random() - 0.5);
  for (let k = 0; k < free.length && made < need; k++) {
    const [x, y] = free[k];
    if (rowCnt[y] >= N - 2 || colCnt[x] >= N - 2) continue;
    g.grid[y][x] = { c: STONE_C, sp: 'stone', born: T + 0.35 + made * 0.12 };
    rowCnt[y]++; colCnt[x]++; made++;
  }
  return made;
}

function newGame() {
  G = {
    grid: emptyGrid(), pieces: [], score: 0, shown: 0, streak: 0, miss: 0, undo: 3, shuf: 2,
    lvl: 1, lvlLines: 0, over: false, moved: false, hist: [], shake: 0,
    anims: [], parts: [], pops: [], fly: [], later: [], ripples: [], overT: 0,
  };
  genTray(true);
  hideOver();
  syncUi(true);
  save();
}

function save() {
  try {
    if (!G || G.over) { localStorage.removeItem(SKEY); return; }
    localStorage.setItem(SKEY, JSON.stringify({
      n: N, diff: SET.diff,
      grid: G.grid.map(r => r.map(v => (v ? [v.c, v.sp || ''] : 0))),
      pieces: G.pieces, score: G.score, streak: G.streak, miss: G.miss, undo: G.undo, shuf: G.shuf,
      lvl: G.lvl, lvlLines: G.lvlLines, moved: G.moved,
    }));
  } catch (e) {}
}
function readSave() {
  try {
    const d = JSON.parse(localStorage.getItem(SKEY));
    if (!d || SIZES.indexOf(d.n) < 0 || !d.grid || d.grid.length !== d.n || !d.pieces || d.pieces.length !== 3) return null;
    return d;
  } catch (e) { return null; }
}
function loadGame(d) {
  try {
    if (d.pieces.some(p => p.s >= SHAPES.length)) return false;
    G = {
      grid: d.grid.map(r => r.map(v => (v ? { c: v[0], sp: v[1] || null, born: -9 } : null))),
      pieces: d.pieces.map(p => Object.assign({}, p, { spawnT: -9 })),
      score: d.score, shown: d.score, streak: d.streak, miss: d.miss, undo: d.undo, shuf: d.shuf,
      lvl: d.lvl || 1, lvlLines: d.lvlLines || 0, over: false, moved: !!d.moved, hist: [], shake: 0,
      anims: [], parts: [], pops: [], fly: [], later: [], ripples: [], overT: 0,
    };
    updateDead();
    if (G.pieces.every(p => p.used || p.dead)) return false;
    syncUi(true);
    return true;
  } catch (e) { return false; }
}

// ================= Звук =================
let actx = null;
function initAudio() { try { if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)(); else if (actx.state === 'suspended') actx.resume(); } catch (e) {} }
function tone(f, d, type, v, delay, slide) {
  if (!SET.sound || !actx) return;
  try {
    const t0 = actx.currentTime + (delay || 0), o = actx.createOscillator(), g = actx.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t0);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, f * slide), t0 + d);
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(v || 0.07, t0 + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    o.connect(g); g.connect(actx.destination); o.start(t0); o.stop(t0 + d + 0.03);
  } catch (e) {}
}
const SCALE = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24, 26];
const note = i => 261.63 * Math.pow(2, SCALE[Math.min(Math.max(0, i), SCALE.length - 1)] / 12);
function sfx(name, a) {
  switch (name) {
    case 'pick':  tone(520, 0.05, 'sine', 0.04); break;
    case 'land':  tone(130 + (a || 3) * 6, 0.16, 'sine', 0.12, 0, 0.6); tone(note(2 + ((a || 3) % 4)), 0.16, 'triangle', 0.05, 0.02); break;
    case 'bad':   tone(160, 0.1, 'sine', 0.05, 0, 0.75); break;
    case 'clear': for (let i = 0; i < Math.min(8, 3 + (a || 1) * 2); i++) tone(note(i + Math.min(G.streak, 4)), 0.3, 'sine', 0.07, 0.04 + i * 0.065); break;
    case 'bomb':  tone(90, 0.35, 'sine', 0.16, 0, 0.3); break;
    case 'star':  tone(1318, 0.18, 'triangle', 0.045); tone(1760, 0.22, 'triangle', 0.04, 0.07); break;
    case 'stone': tone(110, 0.2, 'sine', 0.1, 0, 0.5); break;
    case 'level': [0, 2, 4, 7, 9, 12].forEach((s, i) => tone(note(s / 2 + i), 0.3, 'triangle', 0.065, i * 0.08)); break;
    case 'perfect': [0, 4, 7, 12, 16, 19, 24].forEach((s, i) => tone(261.63 * Math.pow(2, s / 12), 0.4, 'triangle', 0.065, i * 0.07)); break;
    case 'click': tone(640, 0.05, 'sine', 0.045); break;
    case 'undo':  tone(500, 0.08, 'triangle', 0.05, 0, 0.6); break;
    case 'shuffle': tone(400, 0.06, 'triangle', 0.05); tone(600, 0.06, 'triangle', 0.05, 0.06); tone(900, 0.08, 'triangle', 0.05, 0.12); break;
    case 'over':  [392, 330, 262, 196].forEach((f, i) => tone(f, 0.4, 'sine', 0.07, i * 0.16)); break;
  }
}
function buzz(ms) { try { if (SET.vib && navigator.vibrate) navigator.vibrate(ms); } catch (e) {} }

// ================= Спрайты «мягкого стекла» =================
function rr(c, x, y, w, h, r) {
  c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
}
function newCanvas(n) { const c = document.createElement('canvas'); c.width = c.height = n; return c; }

function makeBlock(h, sat, lit, sp, pad, tot) {
  const cv2 = newCanvas(tot), g = cv2.getContext('2d');
  const x = pad + sp * 0.05, w = sp * 0.9, r = sp * 0.27;
  const col = (l, a, s) => h === null ? `hsla(258,16%,${Math.max(8, l - 36)}%,${a})` : `hsla(${h},${s === undefined ? sat : s}%,${l}%,${a})`;
  g.save(); g.shadowColor = col(lit, 0.4); g.shadowBlur = sp * 0.14; g.fillStyle = col(lit - 6, 0.35); rr(g, x, x, w, w, r); g.fill(); g.restore();
  const body = g.createLinearGradient(0, x, 0, x + w);
  body.addColorStop(0, col(lit + 12, 0.9)); body.addColorStop(0.5, col(lit, 0.82)); body.addColorStop(1, col(lit - 9, 0.82));
  rr(g, x, x, w, w, r); g.fillStyle = body; g.fill();
  g.save(); rr(g, x, x, w, w, r); g.clip();
  const refr = g.createRadialGradient(x + w / 2, x + w * 1.1, 0, x + w / 2, x + w * 1.1, w * 0.85);
  refr.addColorStop(0, col(lit + 16, 0.4)); refr.addColorStop(1, col(lit + 16, 0));
  g.fillStyle = refr; g.fillRect(x, x, w, w);
  const spec = g.createRadialGradient(x + w * 0.3, x + w * 0.22, 0, x + w * 0.3, x + w * 0.22, w * 0.6);
  spec.addColorStop(0, 'rgba(255,255,255,0.55)'); spec.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = spec; g.fillRect(x, x, w, w);
  g.restore();
  rr(g, x + w * 0.16, x + w * 0.07, w * 0.68, w * 0.09, w * 0.045); g.fillStyle = 'rgba(255,255,255,0.28)'; g.fill();
  const edge = g.createLinearGradient(x, x, x + w, x + w);
  edge.addColorStop(0, 'rgba(255,255,255,0.7)'); edge.addColorStop(0.5, 'rgba(255,255,255,0.12)'); edge.addColorStop(1, 'rgba(255,255,255,0.32)');
  rr(g, x + 0.8, x + 0.8, w - 1.6, w - 1.6, r); g.lineWidth = Math.max(1.1, sp * 0.032); g.strokeStyle = edge; g.stroke();
  return cv2;
}

function makeStone(sp, pad, tot) {
  const cv2 = newCanvas(tot), g = cv2.getContext('2d');
  const x = pad + sp * 0.05, w = sp * 0.9, r = sp * 0.27;
  const body = g.createLinearGradient(0, x, 0, x + w);
  body.addColorStop(0, 'rgba(214,218,232,0.62)'); body.addColorStop(1, 'rgba(150,156,178,0.58)');
  rr(g, x, x, w, w, r); g.fillStyle = body; g.fill();
  g.save(); rr(g, x, x, w, w, r); g.clip();
  g.strokeStyle = 'rgba(255,255,255,0.28)'; g.lineWidth = Math.max(1, sp * 0.03);
  g.beginPath(); g.moveTo(x + w * 0.2, x + w * 0.15); g.lineTo(x + w * 0.5, x + w * 0.5); g.lineTo(x + w * 0.42, x + w * 0.85);
  g.moveTo(x + w * 0.5, x + w * 0.5); g.lineTo(x + w * 0.85, x + w * 0.62); g.stroke();
  const spec = g.createRadialGradient(x + w * 0.28, x + w * 0.2, 0, x + w * 0.28, x + w * 0.2, w * 0.55);
  spec.addColorStop(0, 'rgba(255,255,255,0.4)'); spec.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = spec; g.fillRect(x, x, w, w);
  g.restore();
  rr(g, x + 0.8, x + 0.8, w - 1.6, w - 1.6, r); g.lineWidth = Math.max(1.1, sp * 0.032); g.strokeStyle = 'rgba(255,255,255,0.4)'; g.stroke();
  return cv2;
}

function makeStar(sp, tot) {
  const cv2 = newCanvas(tot), g = cv2.getContext('2d');
  const cx = tot / 2, cy = tot / 2, R = sp * 0.29, r = R * 0.46;
  g.save(); g.shadowColor = 'rgba(255,232,160,0.7)'; g.shadowBlur = sp * 0.16;
  g.beginPath();
  for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rad = i % 2 ? r : R; g.lineTo(cx + Math.cos(a) * rad, cy + Math.sin(a) * rad); }
  g.closePath();
  const gr = g.createLinearGradient(0, cy - R, 0, cy + R); gr.addColorStop(0, '#fffdf6'); gr.addColorStop(1, '#f1d385');
  g.fillStyle = gr; g.fill(); g.restore();
  g.lineWidth = Math.max(1, sp * 0.018); g.strokeStyle = 'rgba(255,255,255,0.85)'; g.stroke();
  return cv2;
}

function makeBombIcon(sp, tot) {
  const cv2 = newCanvas(tot), g = cv2.getContext('2d');
  const cx = tot / 2, cy = tot / 2 + sp * 0.04, R = sp * 0.26;
  const gr = g.createRadialGradient(cx - R * 0.35, cy - R * 0.4, R * 0.1, cx, cy, R);
  gr.addColorStop(0, '#8f87b0'); gr.addColorStop(0.5, '#363058'); gr.addColorStop(1, '#16122c');
  g.beginPath(); g.arc(cx, cy, R, 0, TAU); g.fillStyle = gr; g.fill();
  g.lineWidth = Math.max(1, sp * 0.02); g.strokeStyle = 'rgba(255,255,255,0.5)'; g.stroke();
  g.beginPath(); g.arc(cx - R * 0.35, cy - R * 0.38, R * 0.2, 0, TAU); g.fillStyle = 'rgba(255,255,255,0.6)'; g.fill();
  g.beginPath(); g.moveTo(cx + R * 0.45, cy - R * 0.8); g.quadraticCurveTo(cx + R * 0.9, cy - R * 1.3, cx + R * 1.2, cy - R * 1.05);
  g.lineWidth = Math.max(1.5, sp * 0.04); g.strokeStyle = '#e9cf9f'; g.stroke();
  g.beginPath(); g.arc(cx + R * 1.2, cy - R * 1.05, sp * 0.04, 0, TAU); g.fillStyle = '#ffe8b8'; g.fill();
  return cv2;
}

function buildSprites() {
  const th = THEMES[SET.theme];
  const sp = Math.max(8, Math.round(cell * dpr)), pad = Math.round(sp * 0.2), tot = sp + pad * 2;
  const blocks = th.hues.map(h => makeBlock(h, th.sat, th.lit, sp, pad, tot));
  blocks.push(makeBlock(null, 0, 40, sp, pad, tot));
  blocks.push(makeStone(sp, pad, tot));
  SP = { sp, pad, tot, blocks, star: makeStar(sp, tot), bomb: makeBombIcon(sp, tot) };
}

function sprite(img, x, y, w, h, alpha) {
  const kx = w / cell, ky = (h === undefined ? w : h) / cell;
  ctx.globalAlpha = alpha === undefined ? 1 : alpha;
  ctx.drawImage(img, x - SP.pad / dpr * kx, y - SP.pad / dpr * ky, SP.tot / dpr * kx, SP.tot / dpr * ky);
}

// ================= Раскладка =================
function resize() {
  dpr = Math.min(window.devicePixelRatio || 1, 3);
  const w = cv.clientWidth, h = cv.clientHeight;
  if (!w || !h) return;
  W = w; H = h;
  cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
  cell = Math.floor(Math.min(N <= 4 ? 70 : 76, (W - 30) / N, (H - 70) / (N + 3.8)));
  cell = Math.max(22, cell);
  bw = cell * N; bx = Math.round((W - bw) / 2);
  ts = Math.min(cell * 0.62, (W / 3 - 14) / Math.min(5, N));
  const trayH = Math.max(ts * 3.4, 96);
  const free = H - 40 - bw - 26 - trayH;
  by = 40 + Math.max(0, Math.round(free * 0.4));
  ty = by + bw + 26;
  buildSprites();
}
function trayCenter(i) { return { x: (W / 3) * (i + 0.5), y: ty + Math.max((H - ty) / 2, ts * 2.2) }; }

// ================= Эффекты =================
function spark(x, y, hue, n, spd, kind) {
  for (let i = 0; i < n && G.parts.length < 360; i++) {
    const a = Math.random() * TAU, v = spd * (0.35 + Math.random() * 0.9);
    G.parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - spd * 0.2, life: 0.5 + Math.random() * 0.5, max: 1, hue, size: 2 + Math.random() * 3, k: kind === undefined ? (Math.random() < 0.35 ? 1 : 0) : kind });
  }
}
function dust(x, y, n) {
  for (let i = 0; i < n && G.parts.length < 360; i++) {
    const dir = Math.random() < 0.5 ? -1 : 1;
    G.parts.push({ x: x + (Math.random() - 0.5) * 6, y, vx: dir * (20 + Math.random() * 60), vy: -(8 + Math.random() * 26), life: 0.45 + Math.random() * 0.3, max: 0.75, hue: 0, size: 2.5 + Math.random() * 3, k: 2 });
  }
}
function pop(text, x, y, col, big) { G.pops.push({ text, x, y, t: 0, max: big ? 1.5 : 1.1, col: col || '#fff', big: !!big }); }

// ================= Ход =================
function snapshot() {
  G.hist.push({ grid: cloneGrid(G.grid), pieces: clonePieces(G.pieces), score: G.score, streak: G.streak, miss: G.miss, lvl: G.lvl, lvlLines: G.lvlLines });
  if (G.hist.length > 5) G.hist.shift();
}

function linesAfter(m, gx, gy) {
  const occ = G.grid.map(r => r.map(v => !!v));
  for (let r = 0; r < m.length; r++) for (let c = 0; c < m[0].length; c++) if (m[r][c]) occ[gy + r][gx + c] = true;
  const rows = [], cols = [];
  for (let y = 0; y < N; y++) if (occ[y].every(v => v)) rows.push(y);
  for (let x = 0; x < N; x++) if (occ.every(row => row[x])) cols.push(x);
  return { rows, cols };
}

function placePiece(i, gx, gy, from) {
  const g = G, p = g.pieces[i], m = SHAPES[p.s].m;
  if (!canPlace(m, gx, gy)) return false;
  snapshot();
  g.moved = true;
  const dur = from ? 0.15 : 0, Tl = T + dur;
  let ord = 0, cells = 0, cx = 0, cy = 0;
  for (let r = 0; r < m.length; r++) for (let c = 0; c < m[0].length; c++) {
    if (!m[r][c]) continue;
    g.grid[gy + r][gx + c] = { c: p.c, sp: p.bomb ? 'bomb' : (ord === p.star ? 'star' : null), born: Tl };
    ord++; cells++; cx += gx + c + 0.5; cy += gy + r + 0.5;
  }
  cx /= cells; cy /= cells;
  p.used = true;
  if (from) g.fly.push({ p: { s: p.s, c: p.c, star: p.star, bomb: p.bomb }, x0: from.x, y0: from.y, s0: from.size, x1: bx + gx * cell, y1: by + gy * cell, t0: T, dur });
  let pts = cells * 3;

  const rows = [], cols = [];
  for (let y = 0; y < N; y++) if (g.grid[y].every(v => v)) rows.push(y);
  for (let x = 0; x < N; x++) if (g.grid.every(row => row[x])) cols.push(x);
  const n = rows.length + cols.length;
  const clear = new Set();
  rows.forEach(y => { for (let x = 0; x < N; x++) clear.add(y * N + x); });
  cols.forEach(x => { for (let y = 0; y < N; y++) clear.add(y * N + x); });
  let bombCells = 0;
  if (p.bomb) {
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      const x = gx + dx, y = gy + dy;
      if (x >= 0 && y >= 0 && x < N && y < N && g.grid[y][x] && !clear.has(y * N + x)) { clear.add(y * N + x); bombCells++; }
    }
  }

  let mono = 0;
  const lineCells = [];
  rows.forEach(y => lineCells.push(Array.from({ length: N }, (_, x) => g.grid[y][x])));
  cols.forEach(x => lineCells.push(Array.from({ length: N }, (_, y) => g.grid[y][x])));
  for (const L of lineCells) if (L.every(v => v.c === L[0].c && v.c < 7)) mono++;

  let stars = 0;
  for (const k of clear) { const v = g.grid[Math.floor(k / N)][k % N]; if (v && v.sp === 'star') stars++; }

  const hit = n > 0 || p.bomb;
  if (hit) { g.streak++; g.miss = 0; } else { g.miss++; if (g.miss >= 3) g.streak = 0; }
  const mult = Math.min(3, 1 + 0.25 * (Math.min(g.streak, 9) - 1));
  if (n > 0) {
    const base = [0, 60, 170, 340, 560, 850][Math.min(n, 5)];
    pts += Math.round(base * mult) + mono * 60;
  }
  pts += stars * 100 + bombCells * 8;

  // существующие блоки получат «волну» от места посадки
  let hadCells = false;
  for (let y = 0; y < N && !hadCells; y++) for (let x = 0; x < N; x++) { const v = g.grid[y][x]; if (v && v.born < Tl - 0.01) { hadCells = true; break; } }
  if (hadCells) { g.ripples.push({ cx, cy, t0: Tl, amp: Math.min(0.1, 0.045 + cells * 0.012) }); if (g.ripples.length > 3) g.ripples.shift(); }

  for (const k of clear) {
    const y = Math.floor(k / N), x = k % N, v = g.grid[y][x];
    const dist = Math.hypot(x + 0.5 - cx, y + 0.5 - cy);
    g.anims.push({ x, y, c: v.c, sp: v.sp, t: -(dur + 0.06 + dist * 0.05), max: 0.5, fx: false });
    g.grid[y][x] = null;
  }

  const perfect = clear.size > 0 && g.grid.every(r => r.every(v => !v));
  if (perfect) pts += 600;
  g.score += pts;

  // прогресс уровня: линии
  g.lvlLines += n;
  let leveled = 0, stonesMade = 0;
  while (g.lvlLines >= goalOf(g.lvl)) {
    g.lvlLines -= goalOf(g.lvl);
    g.lvl++; leveled++;
    if (g.shuf < 5) g.shuf++;
    if (g.lvl % 2 === 0 && g.undo < 5) g.undo++;
  }
  if (leveled) stonesMade = spawnStones(stonesWanted(g.lvl));

  const mx = bx + cx * cell, my = by + cy * cell;
  const effects = () => {
    sfx('land', cells);
    dust(bx + (gx + m[0].length / 2) * cell, by + (gy + m.length) * cell - 2, 6 + cells);
    buzz(n ? (n >= 3 ? 60 : 30) : 10);
    if (clear.size) {
      sfx('clear', Math.max(1, n));
      g.shake = Math.min(7, 1.5 + n * 1.6);
      if (p.bomb) sfx('bomb');
      if (stars) sfx('star');
      pop('+' + pts, mx, my - cell, '#f6f1e6', n >= 3);
      const words = ['', '', 'Отлично!', 'Супер!', 'Невероятно!', 'Легенда!'];
      if (n >= 2) pop(words[Math.min(n, 5)], W / 2, by + bw * 0.34, '#ffffff', true);
      if (g.streak >= 2) pop('Серия ×' + g.streak, W / 2, by + bw * 0.34 + (n >= 2 ? 42 : 0), THEMES[SET.theme].accent);
      if (mono) pop('Один цвет! +' + mono * 60, W / 2, by + bw * 0.34 + 78, '#f1d6ea');
    } else if (pts) pop('+' + pts, mx, my - cell, '#ffffff');
    if (perfect) {
      sfx('perfect'); g.shake = 8; buzz(120);
      pop('Идеально! +600', W / 2, by + bw * 0.5, THEMES[SET.theme].accent, true);
      if (g.undo < 5) g.undo++;
      if (g.shuf < 5) g.shuf++;
      for (let k = 0; k < 5; k++) spark(bx + Math.random() * bw, by + Math.random() * bw, THEMES[SET.theme].hues[k], 10, 220, 1);
    }
    if (leveled) {
      sfx('level');
      pop('Уровень ' + g.lvl, W / 2, by - 4, THEMES[SET.theme].accent, true);
      pop('+1 новые фигуры', W / 2, by + 28, THEMES[SET.theme].accent);
      if (stonesMade) { setTimeout(() => { try { sfx('stone'); } catch (e) {} }, 380); pop('Появились камни', W / 2, by + bw + 8, '#d7dbe8'); }
    }
    syncUi(false);
  };
  if (dur > 0) g.later.push({ t: Tl, fn: effects }); else effects();

  if (g.pieces.every(q => q.used)) genTray(false); else updateDead();

  if (g.score > bestNow()) { bests[N] = g.score; saveBests(); }

  syncUi(false);
  if (g.pieces.every(q => q.used || q.dead)) { g.over = true; g.overT = 0.9 + dur; save(); sfx('over'); } else save();
  return true;
}

function undo() {
  const g = G;
  if (!g || g.undo <= 0 || !g.hist.length) return;
  const s = g.hist.pop();
  g.undo--; g.over = false; g.overT = 0;
  g.grid = s.grid; g.pieces = s.pieces; g.score = s.score; g.streak = s.streak; g.miss = s.miss; g.lvl = s.lvl; g.lvlLines = s.lvlLines;
  g.anims = []; g.fly = []; g.later = []; g.ripples = [];
  g.pieces.forEach(p => { p.spawnT = -9; });
  hideOver(); updateDead(); sfx('undo'); syncUi(false); save();
}

function shuffleTray() {
  const g = G;
  if (!g || g.over || g.shuf <= 0) return;
  g.shuf--;
  genTray(true);
  for (let i = 0; i < 3; i++) { const c = trayCenter(i); spark(c.x, c.y, 40, 8, 140, 1); }
  sfx('shuffle'); syncUi(false); save();
  if (g.pieces.every(q => q.used || q.dead)) { g.over = true; g.overT = 0.6; sfx('over'); }
}

// ================= Ввод =================
let drag = null;
function pos(e) { const r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
function dragCenter() { return { x: drag.x, y: drag.y - cell * 2.2 }; }
function dragTarget() {
  const m = SHAPES[G.pieces[drag.i].s].m, c = dragCenter();
  const gx = Math.round((c.x - bx) / cell - m[0].length / 2), gy = Math.round((c.y - by) / cell - m.length / 2);
  return { gx, gy, ok: canPlace(m, gx, gy) };
}
cv.addEventListener('pointerdown', e => {
  initAudio();
  if (!G || G.over || drag || !inGame) return;
  const { x, y } = pos(e);
  if (y < ty - cell * 0.6) return;
  const i = Math.min(2, Math.max(0, Math.floor(x / (W / 3))));
  if (G.pieces[i].used || T < G.pieces[i].spawnT) return;
  drag = { i, x, y, id: e.pointerId, t0: T };
  try { cv.setPointerCapture(e.pointerId); } catch (err) {}
  sfx('pick');
  if (e.preventDefault) e.preventDefault();
});
cv.addEventListener('pointermove', e => {
  if (!drag || e.pointerId !== drag.id) return;
  const { x, y } = pos(e); drag.x = x; drag.y = y;
  if (e.preventDefault) e.preventDefault();
});
function endDrag(e, cancel) {
  if (!drag || e.pointerId !== drag.id) return;
  const t = dragTarget(), i = drag.i, m = SHAPES[G.pieces[i].s].m, c = dragCenter();
  const k = easeOut((T - drag.t0) / 0.16), size = lerp(ts, cell, k);
  drag = null;
  if (cancel) return;
  if (t.ok) placePiece(i, t.gx, t.gy, { x: c.x - (m[0].length * size) / 2, y: c.y - (m.length * size) / 2, size });
  else sfx('bad');
}
cv.addEventListener('pointerup', e => endDrag(e, false));
cv.addEventListener('pointercancel', e => endDrag(e, true));

// ================= Интерфейс игры =================
let lastShown = -1;
function syncUi(instant) {
  if (!G) return;
  if (instant) { G.shown = G.score; lastShown = -1; }
  $('best').textContent = bestNow();
  const goal = goalOf(G.lvl);
  $('progT').textContent = 'Уровень ' + G.lvl;
  $('progN').textContent = G.lvlLines + ' / ' + goal;
  $('progF').style.width = Math.round(100 * G.lvlLines / goal) + '%';
  $('undoN').textContent = G.undo; $('shufN').textContent = G.shuf;
  $('undo').disabled = G.undo <= 0 || !G.hist.length;
  $('shuffle').disabled = G.shuf <= 0;
}
function showOver() {
  $('finalScore').textContent = G.score;
  $('finalNote').textContent = G.score >= bestNow() && G.score > 0 ? 'Новый рекорд!' : 'Рекорд: ' + bestNow();
  $('undo2N').textContent = G.undo;
  $('undo2').disabled = G.undo <= 0 || !G.hist.length;
  $('over').classList.remove('hidden');
}
function hideOver() { $('over').classList.add('hidden'); }

$('undo').addEventListener('click', () => { initAudio(); undo(); });
$('undo2').addEventListener('click', () => { initAudio(); undo(); });
$('shuffle').addEventListener('click', () => { initAudio(); shuffleTray(); });
$('restart').addEventListener('click', () => { initAudio(); sfx('click'); newGame(); });
$('again').addEventListener('click', () => { initAudio(); sfx('click'); newGame(); });
$('menu').addEventListener('click', () => { sfx('click'); showStart(); });
$('toMenu').addEventListener('click', () => { sfx('click'); showStart(); });

// ================= Отрисовка =================
function drawPieceCells(p, ox, oy, size, alpha, t) {
  const m = SHAPES[p.s].m;
  let ord = 0;
  for (let r = 0; r < m.length; r++) for (let c = 0; c < m[0].length; c++) {
    if (!m[r][c]) continue;
    const x = ox + c * size, y = oy + r * size;
    sprite(SP.blocks[p.c], x, y, size, size, alpha);
    if (p.bomb) sprite(SP.bomb, x, y, size * (1 + 0.04 * Math.sin(t * 6)), undefined, alpha);
    else if (ord === p.star) sprite(SP.star, x, y, size * (1 + 0.07 * Math.sin(t * 4 + 1)), undefined, alpha);
    ord++;
  }
  ctx.globalAlpha = 1;
}

function render() {
  if (!G || !SP || !inGame) return;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, W, H);
  const g = G;
  const sx = g.shake > 0 ? (Math.random() - 0.5) * g.shake : 0, sy = g.shake > 0 ? (Math.random() - 0.5) * g.shake : 0;
  ctx.translate(sx, sy);
  const th = THEMES[SET.theme];

  // стеклянная панель поля
  const pad = 11;
  const pg = ctx.createLinearGradient(bx, by, bx + bw, by + bw);
  pg.addColorStop(0, 'rgba(255,255,255,0.15)'); pg.addColorStop(1, 'rgba(255,255,255,0.045)');
  rr(ctx, bx - pad, by - pad, bw + pad * 2, bw + pad * 2, 26); ctx.fillStyle = pg; ctx.fill();
  const eg = ctx.createLinearGradient(bx, by, bx + bw, by + bw);
  eg.addColorStop(0, 'rgba(255,255,255,0.5)'); eg.addColorStop(0.5, 'rgba(255,255,255,0.1)'); eg.addColorStop(1, 'rgba(255,255,255,0.24)');
  ctx.lineWidth = 1.5; ctx.strokeStyle = eg; ctx.stroke();

  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const alt = (x + y) & 1;
    rr(ctx, bx + x * cell + 2, by + y * cell + 2, cell - 4, cell - 4, cell * 0.22);
    ctx.fillStyle = alt ? 'rgba(255,255,255,0.085)' : 'rgba(255,255,255,0.05)'; ctx.fill();
    ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,0.09)'; ctx.stroke();
  }

  // подсветка линий
  let target = null;
  if (drag) {
    target = dragTarget();
    if (target.ok) {
      const p = g.pieces[drag.i], m = SHAPES[p.s].m;
      const { rows, cols } = linesAfter(m, target.gx, target.gy);
      const hue = p.bomb ? 30 : th.hues[p.c], a = 0.13 + 0.07 * Math.sin(T * 7);
      ctx.fillStyle = `hsla(${hue},${th.sat + 20}%,76%,${a})`;
      for (const y of rows) { rr(ctx, bx + 1, by + y * cell + 1, bw - 2, cell - 2, cell * 0.25); ctx.fill(); }
      for (const x of cols) { rr(ctx, bx + x * cell + 1, by + 1, cell - 2, bw - 2, cell * 0.25); ctx.fill(); }
      if (p.bomb) { rr(ctx, bx + (target.gx - 1) * cell, by + (target.gy - 1) * cell, cell * 3, cell * 3, cell * 0.3); ctx.fillStyle = 'rgba(255,170,100,0.15)'; ctx.fill(); }
    }
  }

  // занятые клетки: «желейная» посадка + волна
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const v = g.grid[y][x];
    if (!v) continue;
    const age = T - v.born;
    if (age < 0) continue;
    let sxk = 1, syk = 1, oy = 0, al = 1;
    if (v.sp === 'stone' && age < 0.35) { oy = -(1 - easeOut(age / 0.35)) * cell * 1.2; al = clamp01(age / 0.18); }
    if (age < 0.5) { const s = age / 0.5, q = Math.exp(-6.5 * s) * Math.cos(15 * s) * 0.2; sxk = 1 + q * 0.55; syk = 1 - q; }
    for (const r of g.ripples) {
      if (v.born >= r.t0 - 0.01) continue;
      const rt = T - r.t0 - Math.hypot(x + 0.5 - r.cx, y + 0.5 - r.cy) * 0.07;
      if (rt > 0 && rt < 0.42) { const pu = r.amp * Math.sin(Math.PI * rt / 0.42); sxk *= 1 + pu; syk *= 1 + pu; }
    }
    const w = cell * sxk, h = cell * syk, px = bx + x * cell + (cell - w) / 2, py = by + y * cell + (cell - h) + oy;
    sprite(SP.blocks[v.c], px, py, w, h, al);
    if (v.sp === 'bomb') sprite(SP.bomb, px, py, w, h, al);
    else if (v.sp === 'star') sprite(SP.star, px, py, w * (1 + 0.07 * Math.sin(T * 4 + x + y)), h * (1 + 0.07 * Math.sin(T * 4 + x + y)), al);
    if (age < 0.22 && v.sp !== 'stone') {
      rr(ctx, px + 2, py + 2, w - 4, h - 4, cell * 0.22);
      ctx.fillStyle = `rgba(255,255,255,${0.3 * (1 - age / 0.22)})`; ctx.fill();
    }
  }
  ctx.globalAlpha = 1;

  // призрак и «магнит»
  if (drag && target && target.ok) {
    const p = g.pieces[drag.i], m = SHAPES[p.s].m;
    drawPieceCells(p, bx + target.gx * cell, by + target.gy * cell, cell, 0.4, T);
    ctx.lineWidth = 1.6; ctx.strokeStyle = `rgba(255,255,255,${0.35 + 0.2 * Math.sin(T * 8)})`;
    for (let r = 0; r < m.length; r++) for (let c = 0; c < m[0].length; c++) if (m[r][c]) { rr(ctx, bx + (target.gx + c) * cell + 3, by + (target.gy + r) * cell + 3, cell - 6, cell - 6, cell * 0.22); ctx.stroke(); }
  }

  // исчезающие клетки
  for (const a of g.anims) {
    const x = bx + a.x * cell, y = by + a.y * cell;
    if (a.t < 0) { sprite(SP.blocks[a.c], x, y, cell, cell); if (a.sp === 'star') sprite(SP.star, x, y, cell); if (a.sp === 'bomb') sprite(SP.bomb, x, y, cell); continue; }
    const p = a.t / a.max;
    const sc = p < 0.18 ? 1 + 0.16 * (p / 0.18) : Math.max(0, 1 - Math.pow((p - 0.18) / 0.82, 1.6));
    const size = cell * sc, off = (cell - size) / 2;
    if (size > 1) {
      sprite(SP.blocks[a.c], x + off, y + off, size, size, 1 - p * 0.6);
      if (a.sp === 'star') sprite(SP.star, x + off, y + off, size, size, 1 - p * 0.6);
      ctx.globalAlpha = Math.max(0, 0.7 * (1 - p * 1.6));
      rr(ctx, x + off + 2, y + off + 2, size - 4, size - 4, cell * 0.22); ctx.fillStyle = '#fff'; ctx.fill();
      ctx.globalAlpha = 1;
    }
  }

  // фигуры в лотке (появляются «с отскоком»)
  for (let i = 0; i < 3; i++) {
    const p = g.pieces[i];
    if (p.used || (drag && drag.i === i)) continue;
    const k = easeBack((T - p.spawnT) / 0.42);
    if (T < p.spawnT) continue;
    const m = SHAPES[p.s].m, c = trayCenter(i), bob = Math.sin(T * 2 + i * 1.7) * 2, size = ts * Math.max(0.01, k);
    drawPieceCells(p, c.x - (m[0].length * size) / 2, c.y - (m.length * size) / 2 + bob, size, p.dead ? 0.3 : 1, T);
  }

  // летящая на место фигура
  for (const f of g.fly) {
    const k = easeOut((T - f.t0) / f.dur), size = lerp(f.s0, cell, k);
    drawPieceCells(f.p, lerp(f.x0, f.x1, k), lerp(f.y0, f.y1, k), size, 1, T);
  }

  // перетаскиваемая фигура
  if (drag) {
    const p = g.pieces[drag.i], m = SHAPES[p.s].m, k = easeOut((T - drag.t0) / 0.16);
    const from = trayCenter(drag.i), to = dragCenter();
    const cx = lerp(from.x, to.x, k), cy = lerp(from.y, to.y, k), size = lerp(ts, cell, k);
    const ox = cx - (m[0].length * size) / 2, oy = cy - (m.length * size) / 2;
    ctx.fillStyle = 'rgba(8,6,30,0.2)';
    for (let r = 0; r < m.length; r++) for (let c = 0; c < m[0].length; c++) if (m[r][c]) { rr(ctx, ox + c * size + 4, oy + r * size + 10, size - 4, size - 4, size * 0.25); ctx.fill(); }
    drawPieceCells(p, ox, oy - 2 * k, size, 1, T);
  }

  // пыль при посадке
  for (const q of g.parts) {
    if (q.k !== 2) continue;
    const a = clamp01(q.life / q.max);
    ctx.globalAlpha = a * 0.5; ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.beginPath(); ctx.arc(q.x, q.y, q.size * (1.2 - a * 0.5), 0, TAU); ctx.fill();
  }
  // искры
  ctx.globalCompositeOperation = 'lighter';
  for (const q of g.parts) {
    if (q.k === 2) continue;
    const a = clamp01(q.life / q.max);
    ctx.globalAlpha = a * 0.7;
    if (q.k === 1) {
      ctx.strokeStyle = `hsl(${q.hue},${th.sat + 15}%,78%)`; ctx.lineWidth = 1.4;
      const s = q.size * 1.4 * (0.4 + a);
      ctx.beginPath(); ctx.moveTo(q.x - s, q.y); ctx.lineTo(q.x + s, q.y); ctx.moveTo(q.x, q.y - s); ctx.lineTo(q.x, q.y + s); ctx.stroke();
    } else {
      ctx.fillStyle = `hsl(${q.hue},${th.sat + 15}%,76%)`;
      ctx.beginPath(); ctx.arc(q.x, q.y, q.size * (0.4 + a * 0.6), 0, TAU); ctx.fill();
    }
  }
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;

  // серия
  if (g.streak >= 2) {
    const text = 'Серия ×' + g.streak, w = 112, h = 28, x = W / 2 - w / 2, y = by - 40;
    rr(ctx, x, y, w, h, 14);
    const sg = ctx.createLinearGradient(0, y, 0, y + h); sg.addColorStop(0, 'rgba(255,255,255,0.24)'); sg.addColorStop(1, 'rgba(255,255,255,0.07)');
    ctx.fillStyle = sg; ctx.fill(); ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,0.4)'; ctx.stroke();
    ctx.font = '700 13px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#fff'; ctx.fillText(text, W / 2 - 8, y + h / 2 + 0.5);
    for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(W / 2 + 30 + i * 8, y + h / 2, 2.6, 0, TAU); ctx.fillStyle = i < 3 - g.miss ? th.accent : 'rgba(255,255,255,0.25)'; ctx.fill(); }
  }

  if (!g.moved) {
    ctx.globalAlpha = 0.6 + 0.3 * Math.sin(T * 3); ctx.font = '600 14px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#fff'; ctx.fillText('Тяни фигуры на поле', W / 2, ty - 4); ctx.globalAlpha = 1;
  }

  for (const p of g.pops) {
    if (p.t < 0) continue;
    const k = p.t / p.max, sc = easeBack(p.t / 0.28), a = clamp01(Math.min(1, (1 - k) * 3.2));
    const y = p.y - 34 * easeOut(k);
    ctx.save();
    ctx.translate(p.x, y); ctx.scale(sc, sc); ctx.globalAlpha = a;
    ctx.font = (p.big ? '800 21px' : '700 15px') + ' system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    const w = ctx.measureText(p.text).width + 26, h = p.big ? 38 : 29;
    rr(ctx, -w / 2, -h / 2, w, h, h / 2);
    ctx.fillStyle = 'rgba(24,18,52,0.45)'; ctx.fill();
    const pg2 = ctx.createLinearGradient(0, -h / 2, 0, h / 2); pg2.addColorStop(0, 'rgba(255,255,255,0.22)'); pg2.addColorStop(1, 'rgba(255,255,255,0.05)');
    ctx.fillStyle = pg2; ctx.fill();
    ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,0.4)'; ctx.stroke();
    ctx.fillStyle = p.col; ctx.fillText(p.text, 0, 1);
    ctx.restore();
  }
  ctx.globalAlpha = 1;
}

function update(dt) {
  const g = G;
  if (!g) return;
  g.shake = Math.max(0, g.shake - 30 * dt);
  for (let i = g.later.length - 1; i >= 0; i--) {
    if (T >= g.later[i].t) { const f = g.later[i].fn; g.later.splice(i, 1); try { f(); } catch (e) {} }
  }
  g.fly = g.fly.filter(f => T < f.t0 + f.dur);
  g.ripples = g.ripples.filter(r => T < r.t0 + 1.2);
  const th = THEMES[SET.theme];
  for (const a of g.anims) {
    const before = a.t; a.t += dt;
    if (before < 0 && a.t >= 0 && !a.fx) {
      a.fx = true;
      const hue = a.c >= 7 ? 250 : th.hues[a.c], x = bx + (a.x + 0.5) * cell, y = by + (a.y + 0.5) * cell;
      spark(x, y, hue, 5, 170);
      if (a.sp === 'star') spark(x, y, 46, 10, 220, 1);
    }
  }
  g.anims = g.anims.filter(a => a.t < a.max);
  for (const q of g.parts) {
    q.life -= dt; q.x += q.vx * dt; q.y += q.vy * dt;
    if (q.k === 2) { q.vy += 30 * dt; q.vx *= 0.95; } else { q.vy += 340 * dt; q.vx *= 0.985; }
  }
  g.parts = g.parts.filter(q => q.life > 0);
  for (const p of g.pops) p.t += dt;
  g.pops = g.pops.filter(p => p.t < p.max);

  if (g.shown !== g.score) {
    const diff = g.score - g.shown;
    g.shown += Math.sign(diff) * Math.max(1, Math.ceil(Math.abs(diff) * Math.min(1, dt * 7)));
    if (Math.abs(g.score - g.shown) < 1) g.shown = g.score;
  }
  if (g.shown !== lastShown) {
    lastShown = g.shown;
    const el = $('score'); el.textContent = g.shown;
    el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump');
  }
  if (g.over && g.overT > 0) { g.overT -= dt; if (g.overT <= 0) showOver(); }
}

// ================= Тема и фон =================
function applyTheme() {
  const th = THEMES[SET.theme], st = document.documentElement.style;
  st.setProperty('--bg1', th.bg[0]); st.setProperty('--bg2', th.bg[1]);
  th.blobs.forEach((c, i) => st.setProperty('--c' + (i + 1), c));
  st.setProperty('--accent', th.accent);
  const meta = document.querySelector && document.querySelector('meta[name=theme-color]'); if (meta && meta.setAttribute) meta.setAttribute('content', th.bg[0]);
  if (SP || inGame) buildSprites();
  renderLogo();
}
function applyBg() {
  const id = BGS[SET.bg].id, bg = $('bg'), fx = $('fx');
  bg.className = 'bg-' + id;
  let html = '';
  if (id === 'stars') {
    for (let i = 0; i < 70; i++) html += `<s style="left:${(Math.random() * 100).toFixed(1)}%;top:${(Math.random() * 100).toFixed(1)}%;animation-delay:${(Math.random() * 5).toFixed(1)}s;animation-duration:${(3 + Math.random() * 4).toFixed(1)}s;${Math.random() < 0.2 ? 'width:3px;height:3px;' : ''}"></s>`;
  } else if (id === 'bubbles') {
    for (let i = 0; i < 14; i++) { const s = 24 + Math.random() * 70; html += `<u style="left:${(Math.random() * 100).toFixed(1)}%;width:${s.toFixed(0)}px;height:${s.toFixed(0)}px;animation-duration:${(22 + Math.random() * 26).toFixed(0)}s;animation-delay:-${(Math.random() * 30).toFixed(0)}s"></u>`; }
  }
  fx.innerHTML = html;
}

const LOGO = [1, 1, 0, 2, 0, 1, 0, 2, 3, 0, 0, 2, 3, 3, 4, 0];
function renderLogo() {
  const th = THEMES[SET.theme];
  const cols = [null, th.hues[0], th.hues[4], th.hues[3], th.hues[2]];
  $('logo').innerHTML = LOGO.map((v, i) => v ? `<b style="--i:${i};--col:hsl(${cols[v]},${th.sat + 8}%,${th.lit - 4}%)"></b>` : `<b class="e" style="--i:${i}"></b>`).join('');
}

// ================= Стартовый экран =================
function chips(el, items, cur, render) {
  el.innerHTML = items.map((it, i) => `<button class="chip ${i === cur ? 'on' : ''}" data-i="${i}">${render(it, i)}</button>`).join('');
}
function renderStart() {
  chips($('themes'), THEMES, SET.theme, t => `<span class="sw" style="background:linear-gradient(135deg,hsl(${t.hues[0]},${t.sat + 10}%,${t.lit}%),hsl(${t.hues[4]},${t.sat + 10}%,${t.lit}%),hsl(${t.hues[5]},${t.sat + 10}%,${t.lit}%))"></span>${t.name}`);
  chips($('bgs'), BGS, SET.bg, b => b.name);
  chips($('sizes'), SIZES, SIZES.indexOf(SET.size), s => s + '×' + s);
  chips($('diffs'), DIFFS, SET.diff, d => d.name);
  $('tSound').textContent = (SET.sound ? '🔊 Звук: вкл' : '🔇 Звук: выкл'); $('tSound').classList.toggle('on', SET.sound);
  $('tVib').textContent = (SET.vib ? '📳 Вибрация: вкл' : '📴 Вибрация: выкл'); $('tVib').classList.toggle('on', SET.vib);
  $('rec').textContent = 'Рекорд ' + SET.size + '×' + SET.size + ': ' + (bests[SET.size] || 0);
  const sv = readSave();
  $('cont').classList.toggle('hidden', !sv);
  if (sv) $('cont').textContent = 'Продолжить партию (' + sv.n + '×' + sv.n + ', ' + sv.score + ')';
}
function pickHandler(id, fn) {
  $(id).addEventListener('click', e => {
    const b = e.target.closest ? e.target.closest('[data-i]') : null;
    if (!b) return;
    fn(+b.dataset.i); saveSettings(); renderStart(); sfx('click');
  });
}
pickHandler('themes', i => { SET.theme = i; applyTheme(); });
pickHandler('bgs', i => { SET.bg = i; applyBg(); });
pickHandler('sizes', i => { SET.size = SIZES[i]; });
pickHandler('diffs', i => { SET.diff = i; });
$('tSound').addEventListener('click', () => { SET.sound = !SET.sound; saveSettings(); renderStart(); if (SET.sound) { initAudio(); sfx('click'); } });
$('tVib').addEventListener('click', () => { SET.vib = !SET.vib; saveSettings(); renderStart(); buzz(20); });

function showStart() {
  if (G && inGame) save();
  inGame = false; drag = null;
  $('game').classList.add('hidden'); $('start').classList.remove('hidden');
  renderStart(); renderLogo();
}
function startGame(cont) {
  initAudio();
  let sv = cont ? readSave() : null;
  $('start').classList.add('hidden'); $('game').classList.remove('hidden');
  inGame = true; drag = null;
  setN(sv ? sv.n : SET.size);
  if (sv) SET.diff = sv.diff !== undefined ? sv.diff : SET.diff;
  resize();
  if (!(sv && loadGame(sv))) newGame();
  syncUi(true);
}
$('play').addEventListener('click', () => { sfx('click'); startGame(false); });
$('cont').addEventListener('click', () => { sfx('click'); startGame(true); });

document.addEventListener('contextmenu', e => e.preventDefault());
window.addEventListener('resize', () => { if (inGame) resize(); });
window.addEventListener('orientationchange', () => setTimeout(() => { if (inGame) resize(); }, 150));
window.__back = () => {
  if (inGame) { showStart(); return 'handled'; }
  return 'exit';
};

let last = 0;
function frame(now) {
  const dt = Math.min(0.05, Math.max(0, (now - last) / 1000));
  last = now; T += dt;
  if (inGame) { update(dt); render(); }
  requestAnimationFrame(frame);
}

applyTheme();
applyBg();
renderStart();
requestAnimationFrame(t => { last = t; requestAnimationFrame(frame); });

window.__NS = {
  get G() { return G; }, get N() { return N; }, SET, THEMES, BGS, DIFFS, SHAPES,
  start(size, diff, theme) { SET.size = size; if (diff !== undefined) SET.diff = diff; if (theme !== undefined) { SET.theme = theme; applyTheme(); } startGame(false); },
  place: placePiece, canPlace, undo, shuffle: shuffleTray, render, tick(dt) { T += dt; update(dt); },
  goalOf, targetOf, helpOf, mercyOf, stonesWanted, showStart, startGame,
};
})();
